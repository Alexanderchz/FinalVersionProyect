import { Component, OnInit } from "@angular/core";
import {
  NavController,
  ToastController,
  MenuController,
  Events
} from "@ionic/angular";
import { CurrenciesProvider } from "src/providers/currencies";
import { UsersProvider } from "src/providers/users";
import { Router } from "@angular/router";
import * as firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/firestore';
import { AuthService } from "../providers/auth.service";

@Component({
  selector: "app-home-client",
  templateUrl: "./home-client.page.html",
  styleUrls: ["./home-client.page.scss"]
})
export class HomeClientPage implements OnInit {
  autheticated =false;
  menu = [];
  user: any;
  uid: string;
  public isAdmin = false;
  userId = "9gZV69NOKSYFYHtkYVQ2YCJOa1Q2";
  constructor(
    private navCtrl: NavController,
    public currenciesProv: CurrenciesProvider,
    public toastCtrl: ToastController,
    public menuCtrl: MenuController,
    public events: Events,
    public usersProv: UsersProvider,
    private router: Router,
    private authService: AuthService
  ) {

  }

  ngOnInit() {
    var userId = firebase.auth().currentUser;

    this.user== userId;

  }


  ionViewWillLoad()
  {
   
  }

  

  addProduct() {
    this.navCtrl.navigateRoot('/add-product');
  }

  designer() {
    this.navCtrl.navigateRoot('/designer');
  }

  administration() {
    this.navCtrl.navigateRoot('/administration');
  }

  vendorCatalog() {
    this.navCtrl.navigateRoot('/home');
  }

  myOrder() {
    this.navCtrl.navigateRoot('/myorder');
  }

  designOrders() {
    this.navCtrl.navigateRoot('/design-orders');
  }

  logout() {
    this.usersProv.logoutUser().then(() => {
      this.user = null;
      this.router.navigateByUrl('/login');
      this.menuCtrl.enable(false);
    });
  }
}
