import { Component, OnInit } from '@angular/core';
import { ProductsProvider } from 'src/providers/products';
import { NgIf } from '@angular/common';
import { Storage } from '@ionic/storage';
import { FavoritesProvider } from 'src/providers/favorites';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-myproducts',
  templateUrl: './myproducts.page.html',
  styleUrls: ['./myproducts.page.scss'],
})
export class MyproductsPage {

  slidePerViewOpts = {
		speed: 1000,
		spaceBetween: 16,
		loop: true,
		autoplay: {
			delay: 3500,
		},
		slidesPerView: 2,
	};

	slidePerViewOpts2 = {
		speed: 1000,
		spaceBetween: 16,
		loop: true,
		autoplay: {
			delay: 3500,
		},
		slidesPerView: 4,
	};


  list_product: any;
  start: any;
  list_product_new: any;
  list_product_slide: any;
  loading: any;
  id_user: any;
  favo_str: string = '';
  id_favo_str: any;
  list_cart: Array<any>;
  constructor(private productsProv: ProductsProvider,
    private storage: Storage,
    private favoritesProv: FavoritesProvider,
    private loadingCtrl: LoadingController) {

    this.presentLoading();

    this.productsProv.getProduct(null, 4).then(data => {
      this.list_product = data;
      this.start = data[data.length - 1].payload.doc.data().name;
      console.log(this.list_product);
    }, error => {

    });
  }


  loadMore(event) {
    this.productsProv.getProduct(this.start, 2).then(data => {
      this.list_product = this.list_product.concat(data);
      console.log(data);
      if (data.length > 0) {
        this.start = data[data.length - 1].payload.doc.data().name;
      }
      console.log(this.list_product);

      setTimeout(() => {
        event.target.disabled = true;
      }, 1500);
    });
  }


  async presentLoading() {
    this.loading = await this.loadingCtrl.create({
      message: 'Cargando',
      duration: 2000
    });
    return await this.loading.present();
  }

  ionViewWillEnter() {
    this.storage.ready().then(() => {
      this.storage.get('cart_list').then((val) => {
        if (!val || val == null) {
          this.list_cart = new Array();
        } else {
          this.list_cart = val;
        }
        console.log(this.list_cart);
      });

      this.storage.get('user').then((val) => {
        if (val || val != null) {
          this.id_user = val.id_auth;

          console.log(val);

          this.favoritesProv.getByUserId(this.id_user).then(data => {
            if (data.length > 0) {
              this.favo_str = data[0].payload.doc.data().id_product;
              this.id_favo_str = data[0].payload.doc.id;
              console.log(data);
            }
          })

          this.productsProv.getProduct(null, 4).then(data => {
            this.list_product = data;
            this.start = data[data.length - 1].payload.doc.data().name;
            console.log(this.list_product);
          }, error => {

          });

          this.productsProv.getProductBySlide(6).then(data => {
            this.list_product_slide = data;
            console.log(this.list_product_slide);
          }, error => {

          });

          this.productsProv.getProductByCreated(6).then(data => {
            this.loading.dismiss().then(() => {
              this.list_product_new = data;
              console.log(this.list_product_new);
            });
          }, error => {

          });
        }
      });
    })
  }



}
