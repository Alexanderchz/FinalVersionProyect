import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  
  { path: 'list', loadChildren: './list/list.module#ListPageModule' },
  // { path: 'list/:cat', loadChildren: './list/list.module#ListPageModule' },

  { path: 'about', loadChildren: './about/about.module#AboutPageModule' },
  { path: 'blog', loadChildren: './blog/blog.module#BlogPageModule' },
  
  { path: 'checkout', loadChildren: './checkout/checkout.module#CheckoutPageModule' },
  // { path: 'checkout/:pay', loadChildren: './checkout/checkout.module#CheckoutPageModule' },

  { path: 'detail', loadChildren: './detail/detail.module#DetailPageModule' },
  // { path: 'detail/:obj', loadChildren: './detail/detail.module#DetailPageModule' },

  { path: 'favorites', loadChildren: './favorites/favorites.module#FavoritesPageModule' },
  { path: 'forgot', loadChildren: './forgot/forgot.module#ForgotPageModule' },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  
  { path: 'mycart', loadChildren: './mycart/mycart.module#MycartPageModule' },

  { path: 'myorder', loadChildren: './myorder/myorder.module#MyorderPageModule' },
  { path: 'offer', loadChildren: './offer/offer.module#OfferPageModule' },
  
  { path: 'post', loadChildren: './post/post.module#PostPageModule' },
  // { path: 'post/:obj', loadChildren: './post/post.module#PostPageModule' },

  { path: 'profile', loadChildren: './profile/profile.module#ProfilePageModule' },

  { path: 'search', loadChildren: './search/search.module#SearchPageModule' },

  { path: 'setting', loadChildren: './setting/setting.module#SettingPageModule' },
  { path: 'shop', loadChildren: './shop/shop.module#ShopPageModule' },
  { path: 'signup', loadChildren: './signup/signup.module#SignupPageModule' },
  { path: 'home-client', loadChildren: './home-client/home-client.module#HomeClientPageModule' },
  { path: 'administration', loadChildren: './administration/administration.module#AdministrationPageModule' },
  { path: 'designer', loadChildren: './designer/designer.module#DesignerPageModule' },
  { path: 'categories', loadChildren: './categories/categories.module#CategoriesPageModule' },
  { path: 'add-product', loadChildren: './add-product/add-product.module#AddProductPageModule' },
  { path: 'shirt-info', loadChildren: './shirt-info/shirt-info.module#ShirtInfoPageModule' },
  { path: 'suggestions', loadChildren: './suggestions/suggestions.module#SuggestionsPageModule' },
  { path: 'comments', loadChildren: './comments/comments.module#CommentsPageModule' },
  { path: 'design-orders', loadChildren: './design-orders/design-orders.module#DesignOrdersPageModule' },
  { path: 'home-vendor', loadChildren: './home-vendor/home-vendor.module#HomeVendorPageModule' },
  { path: 'myproducts', loadChildren: './myproducts/myproducts.module#MyproductsPageModule' },
  { path: 'orderstoattend', loadChildren: './orderstoattend/orderstoattend.module#OrderstoattendPageModule' },
  { path: 'edit-product', loadChildren: './edit-product/edit-product.module#EditProductPageModule' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
