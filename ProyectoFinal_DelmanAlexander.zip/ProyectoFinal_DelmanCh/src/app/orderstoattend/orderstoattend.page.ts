import { Component, OnInit } from '@angular/core';
import { DesignOrdersProvider } from 'src/providers/designOrders';
import { Storage } from '@ionic/storage';
import { LoadingController } from '@ionic/angular';
import { CurrenciesProvider } from 'src/providers/currencies';

@Component({
  selector: 'app-orderstoattend',
  templateUrl: './orderstoattend.page.html',
  styleUrls: ['./orderstoattend.page.scss'],
})
export class OrderstoattendPage implements OnInit {

  designOrders:any;

  list_orders_success: any = [];
  list_orders_pending: any = [];

  settings: any;

  user_id: any;

  loading: any;
  constructor(public ordersProv: DesignOrdersProvider, public storage: Storage, public loadingCtrl: LoadingController,
    public currenciesProv: CurrenciesProvider) {

    this.presentLoading();

    this.storage.get('setting').then(data => {
      this.settings = data;
    })




  }


  async presentLoading() {
    this.loading = await this.loadingCtrl.create({
      message: 'Cargando',
      duration: 2000
    });
    return await this.loading.present();
  }


  ngOnInit() {
  this.ordersProv.getOrders().subscribe(data=>{

     this.designOrders = data.map(e=> {

        return {
          id: e.payload.doc.id,
          isEdit: false,
          description: e.payload.doc.data()['description'],
          email: e.payload.doc.data()['email'],
          fullName: e.payload.doc.data()['fullName'],
          logo: e.payload.doc.data()['logo'],
          phoneNumber: e.payload.doc.data()['phoneNumber'],
          thumb: e.payload.doc.data()['thumb'],
          vendor: e.payload.doc.data()['vendor']
        }


     });

  });


  }

}
