import { Component, OnInit } from '@angular/core';
import { Events, ToastController, LoadingController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { Storage } from '@ionic/storage';



@Component({
	selector: 'app-categories',
	templateUrl: './categories.page.html',
	styleUrls: ['./categories.page.scss'],
})
export class CategoriesPage {

	id: any;
	productsList: any;
	categoryList: any;
	params: any = {};
	items: any;
	title: any;
	owner_id: any;

	loading: any;

	constructor(

		public loadingCtrl: LoadingController,
		public events: Events,
		public toastCtrl: ToastController,


	) { }


}


