import { Component, OnInit } from '@angular/core';
import { CurrenciesProvider } from 'src/providers/currencies';
import { DesignOrdersProvider } from 'src/providers/designOrders';
import { LoadingController } from '@ionic/angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-design-orders',
  templateUrl: './design-orders.page.html',
  styleUrls: ['./design-orders.page.scss'],
})
export class DesignOrdersPage implements OnInit {

  designOrders:any;


  list_orders_success: any = [];
  list_orders_pending: any = [];

  settings: any;

  user_id: any;

  loading: any;

  constructor(
    public currenciesProv: CurrenciesProvider,
    public ordersProv: DesignOrdersProvider,
    public storage: Storage,
    public loadingCtrl: LoadingController
  ) {
    this.presentLoading();

  

  }

  async presentLoading() {
    this.loading = await this.loadingCtrl.create({
      message: 'Cargando',
      duration: 2000
    });
    return await this.loading.present();
  }

  ionViewWillEnter() {
  }


  ngOnInit() {

    this.ordersProv.getOrders().subscribe(data=>{

      this.designOrders = data.map(e=> {
 
         return {
           id: e.payload.doc.id,
           isEdit: false,
           description: e.payload.doc.data()['description'],
           email: e.payload.doc.data()['email'],
           fullName: e.payload.doc.data()['fullName'],
           logo: e.payload.doc.data()['logo'],
           phoneNumber: e.payload.doc.data()['phoneNumber'],
           thumb: e.payload.doc.data()['thumb'],
           vendor: e.payload.doc.data()['vendor'],
           measure: e.payload.doc.data()['measure']
         }
 
 
      });
 
   });
 

  }
}
