import { Component, OnInit } from '@angular/core';
import { NavController, MenuController, Events } from '@ionic/angular';
import { UsersProvider } from 'src/providers/users';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-home-vendor',
  templateUrl: './home-vendor.page.html',
  styleUrls: ['./home-vendor.page.scss'],
})
export class HomeVendorPage implements OnInit {
  user: any;
  constructor(private router: NavController, 
    private usersProv: UsersProvider, private menuCtrl: MenuController, public events: Events, private storage: Storage) {


  }

  ngOnInit() {

    this.storage.ready().then(() => {
      this.storage.get('user').then((val) => {
        if (val != null) {
          this.user = val;
        }
      })
    })

  }

  addProduct() {
    return this.router.navigateRoot('/add-product');
  }

  ordersToAttend() {
    return this.router.navigateRoot('/orderstoattend');
  }

  myProducts() {
    return this.router.navigateRoot('/myproducts');
  }

  logout() {
    this.usersProv.logoutUser().then(() => {
      this.user = null;
      this.router.navigateForward('/login');
      this.menuCtrl.enable(false);
    });
  }

}
