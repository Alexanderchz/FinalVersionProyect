import { HasRoleDirective } from './has-role.directive';

describe('HasRoleDirective', () => {
  it('should create an instance', () => {
    const directive = new HasRoleDirective();
    expect(directive).toBeTruthy();
  });
});
