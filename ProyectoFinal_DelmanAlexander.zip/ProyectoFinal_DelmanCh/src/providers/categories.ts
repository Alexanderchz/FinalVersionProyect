
//import * as Constants from '../../config/constants';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs-compat/Observable';
import { AngularFirestore } from 'angularfire2/firestore';

@Injectable()
export class CategoriesProvider {

  private snapshotChangesSubscription: any;

  constructor(public afs: AngularFirestore) {}

  getCat(){
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('categories').snapshotChanges()
      .subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })
    });
  }

  getCatParent(){
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('categories', ref => ref.where('id_parent', '==', '')).snapshotChanges()
      .subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })
    });
  }

  getCatChild(id_parent){
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('categories', ref => ref.where('id_parent', '==', id_parent)).snapshotChanges()
      .subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })
    });
  }

  updateCat(value, key = null) {
    return new Promise<any>((resolve, reject) => {
      if(key == null){
        value.active = true;
        value.created = Date();
        this.snapshotChangesSubscription = this.afs.collection('categories').add(value).then(
          res => resolve(res),
          err => reject(err)
        )
      }else{
        value.updated = Date();
        this.snapshotChangesSubscription = this.afs.collection('categories').doc(key).update(value).then(
          res => resolve(res),
          err => reject(err)
        )
      }
    })
  }

  activeCat(val, key, where) {
    return new Promise<any>((resolve, reject) => {
      this.afs.collection('categories').doc(key).update({
        active: val,
        created: Date()
      }).then(
        res => {
          this.afs.collection('categories', ref => ref.where('name', '==', where)).snapshotChanges()
            .subscribe(snapshots => {
              resolve(snapshots);
              this.snapshotChangesSubscription.unsubscribe();
            })
        },
        err => reject(err)
      )
    })
  }

  deleteCat(key) {
    return new Promise<any>((resolve, reject) => {
      this.snapshotChangesSubscription = this.afs.collection('categories').doc(key).delete()
        .then(
          res => resolve(res),
          err => reject(err)
        )
    })
  }

  getCatSpec(active = null, name = null, id_parent = null, start = null, jump = null, order = null) {
    return new Promise<any>((resolve, reject) => {

      let query = function (ref) {
        if(jump != null){
          ref = ref.limit(jump);
        }
        if (active != null) {
          ref = ref.where('active', '==', active);
        }
        if (name != null){
          ref = ref.where('name', '==', name);
        }
        if(id_parent != null){
          ref = ref.where('id_parent', '==', id_parent);
        }
        if(start != null){
          ref = ref.startAt(start);
        }
        if(order) {
          ref = ref.orderBy(order);
        }
        return ref;
      }

      this.snapshotChangesSubscription = this.afs.collection('categories', query).snapshotChanges().subscribe(snapshots => {
        resolve(snapshots);
        this.snapshotChangesSubscription.unsubscribe();
      })

    })
  }



}
