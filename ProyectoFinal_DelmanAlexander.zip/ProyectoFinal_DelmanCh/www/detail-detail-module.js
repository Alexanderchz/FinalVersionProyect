(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["detail-detail-module"],{

/***/ "./src/app/detail/detail.module.ts":
/*!*****************************************!*\
  !*** ./src/app/detail/detail.module.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var detail_page_1 = __webpack_require__(/*! ./detail.page */ "./src/app/detail/detail.page.ts");
var routes = [
    {
        path: '',
        component: detail_page_1.DetailPage
    }
];
var DetailPageModule = /** @class */ (function () {
    function DetailPageModule() {
    }
    DetailPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [detail_page_1.DetailPage]
        })
    ], DetailPageModule);
    return DetailPageModule;
}());
exports.DetailPageModule = DetailPageModule;


/***/ }),

/***/ "./src/app/detail/detail.page.html":
/*!*****************************************!*\
  !*** ./src/app/detail/detail.page.html ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon  color=\"light\" name=\"arrow-round-forward\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t<ion-buttons slot=\"end\">\n\t\t\t\n\t\t\t<ion-button fill=\"clear\" class=\"shadow-0 txt-light\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n\t\t\t\t<ion-icon name=\"cart\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title color=\"light\">Detalle de la prenda</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"obj != null\">\n\t<div class=\"top-slide\">\n\t\t<div class=\"wrap-slide\">\n\t\t\t<ion-slides>\n\t\t\t\t<ion-slide *ngIf=\"obj.payload.doc.data().thumb && obj.payload.doc.data().thumb != null && obj.payload.doc.data().thumb != ''\">\n\t\t\t\t\t<div class=\"thumb flex-ali-center flex-jus-center ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{obj.payload.doc.data().thumb}}\">\n\t\t\t\t\t</div>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide *ngIf=\"obj.payload.doc.data().thumb1 && obj.payload.doc.data().thumb1 != null && obj.payload.doc.data().thumb1 != ''\">\n\t\t\t\t\t<div class=\"thumb flex-ali-center flex-jus-center ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{obj.payload.doc.data().thumb1}}\">\n\t\t\t\t\t</div>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide *ngIf=\"obj.payload.doc.data().thumb2 && obj.payload.doc.data().thumb2 != null && obj.payload.doc.data().thumb2 != ''\">\n\t\t\t\t\t<div class=\"thumb flex-ali-center flex-jus-center ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{obj.payload.doc.data().thumb2}}\">\n\t\t\t\t\t</div>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide *ngIf=\"obj.payload.doc.data().thumb3 && obj.payload.doc.data().thumb3 != null && obj.payload.doc.data().thumb3 != ''\">\n\t\t\t\t\t<div class=\"thumb flex-ali-center flex-jus-center ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{obj.payload.doc.data().thumb3}}\">\n\t\t\t\t\t</div>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide *ngIf=\"obj.payload.doc.data().thumb4 && obj.payload.doc.data().thumb4 != null && obj.payload.doc.data().thumb4 != ''\">\n\t\t\t\t\t<div class=\"thumb flex-ali-center flex-jus-center ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{obj.payload.doc.data().thumb4}}\">\n\t\t\t\t\t</div>\n\t\t\t\t</ion-slide>\n\t\t\t</ion-slides>\n\t\t</div>\n\t\t<div class=\"title\" padding>\n\t\t\t<div class=\"wrap-txt\">\n\t\t\t\t<h3 class=\"txt-dark fs-22 spacing-1 fw-600\">{{obj.payload.doc.data().name}}</h3>\n\t\t\t</div>\n\t\t\t<ion-button fill=\"clear\" class=\"favo-btn\" *ngIf=\"favo_str.search(obj.payload.doc.id) > -1\" (click)=\"favorites()\">\n              <ion-icon class=\"txt-danger\" name=\"ios-bookmark\"></ion-icon>\n            </ion-button>\n            <ion-button fill=\"clear\" class=\"favo-btn\" *ngIf=\"favo_str.search(obj.payload.doc.id) < 0\" (click)=\"favorites()\">\n              <ion-icon class=\"txt-light\" name=\"ios-bookmark\"></ion-icon>\n            </ion-button>\n\t\t</div>\n\t</div>\n\n\t<div class=\"fact pdl-25 pdr-25 pdb-15 pdt-10\">\n\t\t<div text-left class=\"\">\n\t\t\t<p class=\"txt3 uppercase spacing-1 fs-12\">Puntos</p>\n\t\t\t<span class=\"fw-600\">\n\t\t\t\t<ion-icon class=\"mgr-5\" name=\"star\"></ion-icon>\n\t\t\t\t{{obj.payload.doc.data().vote}}\n\t\t\t</span>\n\t\t\t<p class=\"txt3\">Este producto se subio en {{obj.payload.doc.data().created.substring(4, 15)}}</p>\n\t\t</div>\n\t\t<div text-right class=\"price\">\n\t\t\t<p class=\"txt3 spacing-1 uppercase fs-12\">Precio</p>\n\t\t\t<i class=\"fw-600 line-through pdl-5 pdr-5 mgr-15 txt3 inline-block\" *ngIf=\"currenciesProv && obj.payload.doc.data().discount > 0\">\n\t\t\t\t{{(obj.payload.doc.data().price)}} Lps\n\t\t\t</i>\n\t\t\t<span class=\"fw-600\" *ngIf=\"currenciesProv && obj.payload.doc.data().discount > 0\">\n\t\t\t\t{{(obj.payload.doc.data().price - obj.payload.doc.data().price*obj.payload.doc.data().discount/100)}} Lps \n\t\t\t</span>\n\t\t\t<span class=\"fw-600\" *ngIf=\"currenciesProv && obj.payload.doc.data().discount <= 0\">\n\t\t\t\t{{(obj.payload.doc.data().price)}} Lps\n\t\t\t</span>\n\t\t</div>\n\t</div>\n\n\n\t<br>\n\t<div class=\"description pdl-25 pdr-25\">\n\t\t<h5 class=\"uppercase fs-12 spacing-1 txt1\">Descripcion del producto</h5>\n\t\t<p class=\"txt3\">{{obj.payload.doc.data().description}}</p>\n\t\t<br>\n\t</div>\n\t<br>\n\t<br>\n\t<br>\n\t\n\t<ion-list no-border>\n\t\t<ion-list-header>\n\t\t  <ion-text color=\"dark\">\n\t\t\t<h5>Seccion de personalizacion de prenda</h5>\n\t\t  </ion-text>\n\t\t</ion-list-header>\n\t\t<ion-item>\n\t\t  <ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t  <ion-label color=\"primary\">Color de la prenda</ion-label>\n\t\t  <ion-select>\n\t\t\t<ion-select-option  [value]=\"rojo\">roja</ion-select-option>\n\t\t\t<ion-select-option  [value]=\"negro\">negra</ion-select-option>\n\t\t\t<ion-select-option  [value]=\"negro\">blanca</ion-select-option>\n\t\t\t<ion-select-option  [value]=\"negro\">azul</ion-select-option>\n\t\t\t<ion-select-option  [value]=\"negro\">amarilla</ion-select-option>\n\t\t\t<ion-select-option  [value]=\"negro\">verde</ion-select-option>\n\t\t  </ion-select>\n\t\t</ion-item>\n\t\t<ion-item>\n\t\t\t<ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t<ion-label color=\"primary\">Color de la manga</ion-label>\n\t\t\t<ion-select>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Manga roja</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Manga negra</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Manga blanca</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Manga azul</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Manga amarilla</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Manga verde</ion-select-option>\n\t\t\t</ion-select>\n\t\t  </ion-item>\n\t\t<ion-item>\n\t\t  <ion-icon name=\"notifications\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t  <ion-label class=\"label\" color=\"primary\">Colocar bolsa derecha </ion-label>\n\t\t  <ion-toggle ></ion-toggle>\n\t\t</ion-item>\n\t\t<ion-item>\n\t\t\t<ion-icon name=\"notifications\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t<ion-label class=\"label\" color=\"primary\">Colocar bolsa Izquierda </ion-label>\n\t\t\t<ion-toggle ></ion-toggle>\n\t\t  </ion-item>\n\t\t  <ion-item>\n\t\t\t<ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t<ion-label color=\"primary\">Tipo de cuello</ion-label>\n\t\t\t<ion-select>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Cuello forma V</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Cuello circular</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Cuello tipo polo</ion-select-option>\n\t\t\t  <ion-select-option  [value]=\"rojo\">Cuello chino</ion-select-option>\n\t\t\t</ion-select>\n\t\t\t</ion-item>\n\t\t\t<ion-item>\n\t\t\t\t<ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t\t<ion-label color=\"primary\">Color de las decoraciones</ion-label>\n\t\t\t\t<ion-select>\n\t\t\t\t  <ion-select-option  [value]=\"roja\">Decoracion roja</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"negra\">Decoracion negra</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"blanca\">Decoracion blanca</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"azul\">Decoracion azul</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"amarilla\">Decoracion amarilla</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"verde\">Decoracion verde</ion-select-option>\n\t\t\t\t</ion-select>\n\t\t\t</ion-item>\n\t\t\t\t<ion-item>\n\t\t\t\t\t<ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t\t\t<ion-label color=\"primary\">Color del cuello</ion-label>\n\t\t\t\t\t<ion-select>\n\t\t\t\t\t  <ion-select-option  [value]=\"roja\">Cuello rojo</ion-select-option>\n\t\t\t\t\t  <ion-select-option  [value]=\"negra\">Cuello negro</ion-select-option>\n\t\t\t\t\t  <ion-select-option  [value]=\"blanca\">Cuello blanco</ion-select-option>\n\t\t\t\t\t  <ion-select-option  [value]=\"azul\">Cuello azul</ion-select-option>\n\t\t\t\t\t  <ion-select-option  [value]=\"amarilla\">Cuello amarillo</ion-select-option>\n\t\t\t\t\t  <ion-select-option  [value]=\"verde\">Cuello verde</ion-select-option>\n\t\t\t\t\t</ion-select>\n\t\t\t\t</ion-item>\n\n\t\t\t\t<ion-item>\n\t\t\t\t\t\t<ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t\t\n\n\t\t\t\t\t<div *ngIf=\"downloadURL != null\">\n\t\t\t\t\t\t\t<ion-label color=\"primary\">Puedes agregar un logo si deseas</ion-label>\n\t\t\t\t\t\t<img src=\"{{downloadURL}}\">\n\t\t\t\t\t\n\t\t\t\t\t</div>\n\t\t\t\t\t <ion-item>\n\t\t\t\t\n\t\t\t\t   <input type=\"file\" name=\"select Image\" [(ngModel)]=\"downloadURL\" (change)=\"onChange($event)\" >\n\t\t\t  </ion-item>\n\t\t\t</ion-item>\n\t\t\t \n\t\t\t  <ion-item>\n\t\t\t\t<ion-icon name=\"settings\" slot=\"start\" color=\"primary\"></ion-icon>\n\t\t\t\t<ion-label color=\"primary\">Posicion del logo</ion-label>\n\t\t\t\t<ion-select multiple>\n\t\t\t\t  <ion-select-option  [value]=\"roja\">Manga derecha</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"negra\">Manga izquierda</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"blanca\">Lateral derecho</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"azul\">Lateral izquierdo</ion-select-option>\n\t\t\t\t  <ion-select-option  [value]=\"amarilla\">Logo grande central</ion-select-option>\n\t\n\t\t\t\t</ion-select>\n\t\t\t</ion-item>\n\t\t  \n\t  </ion-list>\n\n\t  <ion-button (click)=\"addCart()\" shape=\"round\" class=\"uppercase spacing-1 fs-12 fw-600 bg-third\">Agregar al carrito</ion-button>\n\n\n\t<br>\n\t<br>\n\t<br>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/detail/detail.page.scss":
/*!*****************************************!*\
  !*** ./src/app/detail/detail.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".top-slide {\n  position: relative; }\n  .top-slide .wrap-slide {\n    z-index: 10;\n    position: relative; }\n  .top-slide .wrap-slide .slide-zoom {\n      height: 100%; }\n  .top-slide .wrap-slide .thumb {\n      height: 300px;\n      width: 100%; }\n  .top-slide .wrap-slide .thumb img {\n        height: 100%;\n        min-width: 100%; }\n  .top-slide .title {\n    z-index: 100;\n    position: absolute;\n    bottom: 0px;\n    left: 0;\n    right: 0;\n    display: flex;\n    align-items: flex-end;\n    /*background-image: linear-gradient(0deg, rgba(0,0,0,0.7), rgba(0,0,0,0));*/ }\n  .top-slide .title .wrap-txt {\n      flex: 1; }\n  .fact {\n  display: flex;\n  border-bottom: 1px solid #ebebeb; }\n  .fact > div {\n    overflow: auto;\n    flex: 1; }\n  .wrap-quantity {\n  display: flex; }\n  .wrap-quantity .quantity {\n    flex: 1;\n    display: flex; }\n  .wrap-quantity ion-input {\n    height: 100%; }\n  .social {\n  display: flex;\n  border-bottom: 1px solid #ebebeb; }\n  .social button {\n    flex: 1; }\n  .wrap-related {\n  width: 130%; }\n  .wrap-related ion-slides {\n    width: 100%; }\n  .wrap-related .slide-zoom {\n    height: 100%; }\n  .wrap-related .thumb {\n    height: 150px; }\n  .wrap-related img {\n    width: 100%;\n    min-height: 100%;\n    max-height: unset; }\n  .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV0YWlsL0M6XFxVc2Vyc1xcZGNoaW5jaGlsbGFcXERlc2t0b3BcXEVudHJlZ2FibGVcXHByb3llY3RvRGVsbWFuQ2hpbmNoaWxsYS9zcmNcXGFwcFxcZGV0YWlsXFxkZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Msa0JBQWtCLEVBQUE7RUFEbkI7SUFHRSxXQUFXO0lBQ1gsa0JBQWtCLEVBQUE7RUFKcEI7TUFNRyxZQUFZLEVBQUE7RUFOZjtNQVNHLGFBQWE7TUFDYixXQUFXLEVBQUE7RUFWZDtRQVlJLFlBQVk7UUFDWixlQUFlLEVBQUE7RUFibkI7SUFrQkUsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsT0FBTztJQUNQLFFBQVE7SUFDUixhQUFhO0lBQ2IscUJBQXFCO0lBQ3JCLDJFQUFBLEVBQTRFO0VBekI5RTtNQTJCRyxPQUFPLEVBQUE7RUFNVjtFQUNDLGFBQVk7RUFDWixnQ0FBZ0MsRUFBQTtFQUZqQztJQUlFLGNBQWM7SUFDZCxPQUFPLEVBQUE7RUFHVDtFQUNDLGFBQWEsRUFBQTtFQURkO0lBR0UsT0FBTztJQUNQLGFBQWEsRUFBQTtFQUpmO0lBT0UsWUFBWSxFQUFBO0VBR2Q7RUFDQyxhQUFhO0VBQ2IsZ0NBQWdDLEVBQUE7RUFGakM7SUFJRSxPQUFPLEVBQUE7RUFJVDtFQUNDLFdBQVcsRUFBQTtFQURaO0lBR0UsV0FBVyxFQUFBO0VBSGI7SUFNRSxZQUFZLEVBQUE7RUFOZDtJQVNFLGFBQWEsRUFBQTtFQVRmO0lBWUUsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixpQkFBaUIsRUFBQTtFQUluQjtFQUVJLHNGQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9kZXRhaWwvZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3Atc2xpZGV7XG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0LndyYXAtc2xpZGV7XG5cdFx0ei1pbmRleDogMTA7XG5cdFx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRcdC5zbGlkZS16b29te1xuXHRcdFx0aGVpZ2h0OiAxMDAlO1xuXHRcdH1cblx0XHQudGh1bWJ7XG5cdFx0XHRoZWlnaHQ6IDMwMHB4O1xuXHRcdFx0d2lkdGg6IDEwMCU7XG5cdFx0XHRpbWd7XG5cdFx0XHRcdGhlaWdodDogMTAwJTtcblx0XHRcdFx0bWluLXdpZHRoOiAxMDAlO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHQudGl0bGV7XG5cdFx0ei1pbmRleDogMTAwO1xuXHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHRib3R0b206IDBweDtcblx0XHRsZWZ0OiAwO1xuXHRcdHJpZ2h0OiAwO1xuXHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0YWxpZ24taXRlbXM6IGZsZXgtZW5kO1xuXHRcdC8qYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KDBkZWcsIHJnYmEoMCwwLDAsMC43KSwgcmdiYSgwLDAsMCwwKSk7Ki9cblx0XHQud3JhcC10eHR7XG5cdFx0XHRmbGV4OiAxO1xuXHRcdH1cblx0fVxufVxuXG5cbi5mYWN0e1xuXHRkaXNwbGF5OmZsZXg7XG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWJlYmViO1xuXHQ+ZGl2e1xuXHRcdG92ZXJmbG93OiBhdXRvO1xuXHRcdGZsZXg6IDE7XG5cdH1cbn1cbi53cmFwLXF1YW50aXR5e1xuXHRkaXNwbGF5OiBmbGV4O1xuXHQucXVhbnRpdHl7XG5cdFx0ZmxleDogMTtcblx0XHRkaXNwbGF5OiBmbGV4O1xuXHR9XG5cdGlvbi1pbnB1dHtcblx0XHRoZWlnaHQ6IDEwMCU7XG5cdH1cbn1cbi5zb2NpYWx7XG5cdGRpc3BsYXk6IGZsZXg7XG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWJlYmViO1xuXHRidXR0b257XG5cdFx0ZmxleDogMTtcblx0fVxufVxuXG4ud3JhcC1yZWxhdGVke1xuXHR3aWR0aDogMTMwJTtcblx0aW9uLXNsaWRlc3tcblx0XHR3aWR0aDogMTAwJTtcblx0fVxuXHQuc2xpZGUtem9vbXtcblx0XHRoZWlnaHQ6IDEwMCU7XG5cdH1cblx0LnRodW1ie1xuXHRcdGhlaWdodDogMTUwcHg7XG5cdH1cblx0aW1ne1xuXHRcdHdpZHRoOiAxMDAlO1xuXHRcdG1pbi1oZWlnaHQ6IDEwMCU7XG5cdFx0bWF4LWhlaWdodDogdW5zZXQ7XG5cdH1cbn1cblxuLnRvb2xiYXIge1xuICAgXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XG4gICAgICAgIFxuICB9Il19 */"

/***/ }),

/***/ "./src/app/detail/detail.page.ts":
/*!***************************************!*\
  !*** ./src/app/detail/detail.page.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var products_1 = __webpack_require__(/*! ../../providers/products */ "./src/providers/products.ts");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var favorites_1 = __webpack_require__(/*! ../../providers/favorites */ "./src/providers/favorites.ts");
var ngx_1 = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
var firebase = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
var DetailPage = /** @class */ (function () {
    function DetailPage(currenciesProv, loadingCtrl, productsProv, route, events, toastCtrl, storage, socialSharing, favoritesProv) {
        var _this = this;
        this.currenciesProv = currenciesProv;
        this.loadingCtrl = loadingCtrl;
        this.productsProv = productsProv;
        this.route = route;
        this.events = events;
        this.toastCtrl = toastCtrl;
        this.storage = storage;
        this.socialSharing = socialSharing;
        this.favoritesProv = favoritesProv;
        this.obj = null;
        this.slidePerViewOpts = {
            speed: 1000,
            spaceBetween: 16,
            loop: true,
            autoplay: {
                delay: 3500,
            },
            slidesPerView: 3,
        };
        this.quantityIp = 1;
        this.favo_str = '';
        this.success = false;
        this.disableSubmit = false;
        this.presentLoading();
        this.route.params.subscribe(function (params) {
            _this.id_obj = params.id_item;
            _this.productsProv.getProductById(_this.id_obj).then(function (data) {
                _this.obj = data[0];
                console.log(_this.obj);
                _this.productsProv.getProductByRelated(_this.obj.payload.doc.data().tag).then(function (dataRelated) {
                    _this.loading.dismiss().then(function () {
                        _this.list_related = dataRelated;
                        console.log(_this.list_related);
                        console.log(_this.obj);
                        console.log(_this.obj.payload.doc.data().tag);
                    });
                });
            });
        });
        this.storage.get('user').then(function (val) {
            _this.id_user = val['id_auth'];
            _this.favoritesProv.getByUserId(_this.id_user).then(function (data) {
                if (data.length > 0) {
                    _this.favo_str = data[0].payload.doc.data().id_product;
                    _this.id_favo_str = data[0].payload.doc.id;
                    console.log(data);
                }
            });
        });
        this.storage.get('cart_list').then(function (val) {
            if (!val || val == null) {
                _this.list_cart = new Array();
            }
            else {
                _this.list_cart = val;
            }
            console.log(_this.list_cart);
        });
        this.events.subscribe('cart_list: change', function (lst) {
            _this.list_cart = lst;
        });
    }
    DetailPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    DetailPage.prototype.ionViewDidLoad = function () {
        console.log('ionViewDidLoad DetailPage');
    };
    DetailPage.prototype.favorites = function () {
        var _this = this;
        console.log(this.obj.payload.doc.id);
        var check = this.favo_str.indexOf(this.obj.payload.doc.id);
        if (check == -1) {
            this.favo_str = this.favo_str + this.obj.payload.doc.id + ' ';
        }
        else {
            this.favo_str = this.favo_str.replace(this.obj.payload.doc.id + ' ', '');
        }
        this.favoritesProv.favoritesAdd(this.favo_str, this.id_user, this.id_favo_str).then(function (data) {
            if (!_this.id_favo_str || _this.id_favo_str == null) {
                _this.favoritesProv.getByUserId(_this.id_user).then(function (newFavo) {
                    _this.id_favo_str = newFavo[0].payload.doc.id;
                });
            }
        });
    };
    DetailPage.prototype.quantity = function (qtt) {
        this.quantityIp = this.quantityIp + parseInt(qtt);
        if (this.quantityIp > 99) {
            this.quantityIp = 99;
        }
        if (this.quantityIp < 1) {
            this.quantityIp = 1;
        }
    };
    DetailPage.prototype.enterQuantity = function (qtt) {
        this.quantityIp = parseInt(qtt);
        if (this.quantityIp > 99) {
            this.quantityIp = 99;
        }
        if (this.quantityIp < 1 || this.quantityIp == null || isNaN(this.quantityIp)) {
            this.quantityIp = 1;
        }
        console.log(qtt);
        console.log(this.quantityIp);
    };
    DetailPage.prototype.addCart = function () {
        var _this = this;
        var itemCv = {
            id: this.obj.payload.doc.id,
            name: this.obj.payload.doc.data().name,
            price: this.obj.payload.doc.data().price,
            discount: this.obj.payload.doc.data().discount,
            description: this.obj.payload.doc.data().description,
            vote: this.obj.payload.doc.data().vote,
            created: this.obj.payload.doc.data().created,
            id_cat: this.obj.payload.doc.data().id_cat,
            tag: this.obj.payload.doc.data().tag,
            thumb: this.obj.payload.doc.data().thumb,
            thumb1: this.obj.payload.doc.data().thumb1,
            thumb2: this.obj.payload.doc.data().thumb2,
            thumb3: this.obj.payload.doc.data().thumb3,
            thumb4: this.obj.payload.doc.data().thumb4,
            designPrice: this.obj.payload.doc.data().designPrice,
            quantity: this.quantityIp
        };
        var temp = this.list_cart.filter(function (element) {
            if (element.id == itemCv.id) {
                element.quantity = _this.quantityIp + element.quantity;
                return true;
            }
        });
        console.log(temp);
        if (temp.length == 0) {
            this.list_cart = this.list_cart.concat(itemCv);
        }
        this.presentToast();
        // this.list_cart = new Array();
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
        console.log(this.list_cart);
    };
    DetailPage.prototype.share = function (item) {
        this.socialSharing.share(this.obj.payload.doc.data().name, this.obj.payload.doc.data().description, null, 'post?id=' + this.obj.payload.doc.id);
    };
    DetailPage.prototype.presentToast = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Se agrego con exito',
                            duration: 2000,
                            position: 'bottom'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    DetailPage.prototype.ngOnInit = function () {
    };
    DetailPage.prototype.onChange = function (event) {
        this.selectedFile = event.target.files[0];
        this.disableSubmit = true;
        this.upLoad();
    };
    DetailPage.prototype.upLoad = function () {
        var _this = this;
        var fileName = this.selectedFile.name;
        var storageRef = firebase.storage().ref('products products/' + fileName);
        var metadata = { contentType: 'image/jpeg' };
        var uploadTask = storageRef.put(this.selectedFile, metadata);
        uploadTask.on('state_changed', function (snapshot) {
            console.log(snapshot);
            var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100;
            console.log('upload' + progress + '% done');
            switch (uploadTask.snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or Paused
                    console.log('upLoad is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // OR Running
                    console.log('upload is running');
                    break;
            }
        }, function (error) {
            console.log(error);
        }, function () {
            _this.disableSubmit = false;
            storageRef.getDownloadURL().then(function (ref) {
                console.log(ref);
                _this.downloadURL = ref;
            });
            console.log(_this.downloadURL);
            console.log('success');
            _this.success = true;
        });
    };
    DetailPage = __decorate([
        core_1.Component({
            selector: 'app-detail',
            template: __webpack_require__(/*! ./detail.page.html */ "./src/app/detail/detail.page.html"),
            styles: [__webpack_require__(/*! ./detail.page.scss */ "./src/app/detail/detail.page.scss")]
        }),
        __metadata("design:paramtypes", [currencies_1.CurrenciesProvider,
            angular_1.LoadingController,
            products_1.ProductsProvider,
            router_1.ActivatedRoute,
            angular_1.Events,
            angular_1.ToastController,
            storage_1.Storage,
            ngx_1.SocialSharing,
            favorites_1.FavoritesProvider])
    ], DetailPage);
    return DetailPage;
}());
exports.DetailPage = DetailPage;


/***/ })

}]);
//# sourceMappingURL=detail-detail-module.js.map