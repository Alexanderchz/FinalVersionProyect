(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-client-home-client-module"],{

/***/ "./src/app/controls/popmenu/popmenu.component.html":
/*!*********************************************************!*\
  !*** ./src/app/controls/popmenu/popmenu.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\" class=\"animated fadeInDown\">\n    <ion-fab-button (click)=\"togglePopupMenu()\">\n      <ion-ripple-effect></ion-ripple-effect>\n      <ion-icon name=\"apps\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  \n  <div class=\"popup-menu\">\n    <div class=\"popup-menu-overlay\" [ngClass]=\"{'in': openMenu}\"></div>\n    <div class=\"popup-menu-panel\" [ngClass]=\"{'in': openMenu}\">\n      <div class=\"popup-menu-item\">\n        <ion-icon name=\"shirt\" slot=\"middle\" size=\"large\" (click)=\"garmentTypes()\"></ion-icon>\n        <span>Tipos de prenda</span>\n      </div>\n      <div class=\"popup-menu-item\">\n        <ion-icon name=\"chatboxes\" slot=\"middle\" size=\"large\" (click)=\"suggestions()\"></ion-icon>\n        <span>Recomendaciones</span>\n      </div>\n      <div class=\"popup-menu-item\">\n        <ion-icon name=\"book\" slot=\"middle\" size=\"large\" (click)=\"comments()\"></ion-icon>\n        <span>Comentarios</span>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/controls/popmenu/popmenu.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/controls/popmenu/popmenu.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".popup-menu-overlay {\n  position: fixed;\n  top: 30;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  z-index: 100;\n  opacity: 0;\n  visibility: hidden;\n  transition: all 0.15s ease-in-out;\n  background-image: linear-gradient(rgba(49, 44, 59, 0.85) 0%, rgba(50, 45, 63, 0.65) 50%); }\n  .popup-menu-overlay.in {\n    opacity: 1;\n    visibility: visible; }\n  .popup-menu-toggle {\n  position: fixed;\n  width: 40px;\n  height: 40px;\n  bottom: 10px;\n  left: 50%;\n  margin-left: -20px;\n  background-color: var(--ion-color-primary);\n  border-radius: 50%;\n  z-index: 101;\n  transition: all .25s ease-in-out; }\n  .popup-menu-toggle.out {\n    opacity: 0;\n    visibility: hidden;\n    transform: scale(0);\n    transition: all .15s ease-in-out; }\n  .popup-menu-toggle.out:before {\n      transition: all .15s ease-in-out;\n      transform: scale(0); }\n  .popup-menu-panel {\n  position: fixed;\n  width: 300px;\n  border-radius: 5%;\n  bottom: 80px;\n  left: 50%;\n  margin-left: -150px;\n  padding: 20px;\n  background-color: var(--ion-color-primary);\n  z-index: 102;\n  transition: all .25s ease-in-out;\n  transition-delay: .15s;\n  transform-origin: 50% 100%;\n  transform: scale(0);\n  display: -moz-flex;\n  display: flex;\n  flex-wrap: wrap; }\n  .popup-menu-panel .popup-menu-item {\n    margin: auto;\n    -moz-flex: 1 0 30%;\n    flex: 1 0 30%;\n    display: -moz-flex;\n    display: flex;\n    -moz-flex-direction: column;\n    flex-direction: column;\n    transform: scale(0);\n    opacity: 0;\n    transition: all .25s ease-in-out; }\n  .popup-menu-panel .popup-menu-item ion-icon {\n      margin: 0 auto;\n      text-align: center;\n      color: #fff; }\n  .popup-menu-panel .popup-menu-item span {\n      padding: 0;\n      margin: 0 0 auto 0;\n      color: #fff;\n      text-align: center;\n      font-size: 12px;\n      text-transform: uppercase;\n      font-weight: 500;\n      line-height: 18px; }\n  .popup-menu-panel .popup-menu-item:active i {\n      color: #dd4135;\n      transition: all 0.15s; }\n  .popup-menu-panel .popup-menu-item:active span {\n      color: #dd4135;\n      transition: all .15s; }\n  .popup-menu-panel.in {\n    transform: scale(1);\n    transition-delay: 0s; }\n  .popup-menu-panel.in .popup-menu-item {\n      transform: scale(1);\n      opacity: 1;\n      transition-delay: .15s; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29udHJvbHMvcG9wbWVudS9DOlxcVXNlcnNcXGRjaGluY2hpbGxhXFxEZXNrdG9wXFxFbnRyZWdhYmxlXFxwcm95ZWN0b0RlbG1hbkNoaW5jaGlsbGEvc3JjXFxhcHBcXGNvbnRyb2xzXFxwb3BtZW51XFxwb3BtZW51LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZUFBZTtFQUNmLE9BQU87RUFDUCxPQUFPO0VBQ1AsUUFBUTtFQUNSLFNBQVM7RUFDVCxZQUFZO0VBQ1osVUFBVTtFQUNWLGtCQUFrQjtFQUVsQixpQ0FBaUM7RUFFakMsd0ZBQXdGLEVBQUE7RUFaNUY7SUFjUSxVQUFVO0lBQ1YsbUJBQW1CLEVBQUE7RUFJM0I7RUFDSSxlQUFlO0VBQ2YsV0FBVztFQUNYLFlBQVk7RUFDWixZQUFZO0VBQ1osU0FBUztFQUNULGtCQUFrQjtFQUNsQiwwQ0FBMEM7RUFDMUMsa0JBQWtCO0VBQ2xCLFlBQVk7RUFFWixnQ0FBZ0MsRUFBQTtFQVhwQztJQWFRLFVBQVU7SUFDVixrQkFBa0I7SUFFbEIsbUJBQW1CO0lBRW5CLGdDQUFnQyxFQUFBO0VBbEJ4QztNQXFCWSxnQ0FBZ0M7TUFFaEMsbUJBQW1CLEVBQUE7RUFLL0I7RUFDSSxlQUFlO0VBQ2YsWUFBWTtFQUVaLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osU0FBUztFQUNULG1CQUFtQjtFQUNuQixhQUFhO0VBQ2IsMENBQTBDO0VBQzFDLFlBQVk7RUFFWixnQ0FBZ0M7RUFFaEMsc0JBQXNCO0VBRXRCLDBCQUEwQjtFQUUxQixtQkFBbUI7RUFJbkIsa0JBQWtCO0VBRWxCLGFBQWE7RUFJYixlQUFlLEVBQUE7RUE1Qm5CO0lBOEJRLFlBQVk7SUFJWixrQkFBa0I7SUFFbEIsYUFBYTtJQUliLGtCQUFrQjtJQUVsQixhQUFhO0lBSWIsMkJBQTJCO0lBRTNCLHNCQUFzQjtJQUV0QixtQkFBbUI7SUFDbkIsVUFBVTtJQUVWLGdDQUFnQyxFQUFBO0VBckR4QztNQXVEWSxjQUFjO01BQ2Qsa0JBQWtCO01BQ2xCLFdBQVcsRUFBQTtFQXpEdkI7TUE0RFksVUFBVTtNQUNWLGtCQUFrQjtNQUNsQixXQUFXO01BQ1gsa0JBQWtCO01BQ2xCLGVBQWU7TUFDZix5QkFBeUI7TUFDekIsZ0JBQWdCO01BQ2hCLGlCQUFpQixFQUFBO0VBbkU3QjtNQXVFZ0IsY0FBcUI7TUFFckIscUJBQXFCLEVBQUE7RUF6RXJDO01BNEVnQixjQUFxQjtNQUVyQixvQkFBb0IsRUFBQTtFQTlFcEM7SUFvRlEsbUJBQW1CO0lBRW5CLG9CQUFvQixFQUFBO0VBdEY1QjtNQXlGWSxtQkFBbUI7TUFDbkIsVUFBVTtNQUVWLHNCQUFzQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvY29udHJvbHMvcG9wbWVudS9wb3BtZW51LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gUG9wdXAgTWVudSAvL1xyXG4ucG9wdXAtbWVudS1vdmVybGF5IHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHRvcDogMzA7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB6LWluZGV4OiAxMDA7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4xNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4xNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudChyZ2JhKDY5LCA2NSwgNzcsIDAuODUpIDAlLCByZ2JhKDU5LCA1NCwgNjgsIDAuNjUpIDUwJSk7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQocmdiYSg0OSwgNDQsIDU5LCAwLjg1KSAwJSwgcmdiYSg1MCwgNDUsIDYzLCAwLjY1KSA1MCUpO1xyXG4gICAgJi5pbiB7XHJcbiAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gICAgfVxyXG59XHJcblxyXG4ucG9wdXAtbWVudS10b2dnbGUge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBib3R0b206IDEwcHg7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogLTIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB6LWluZGV4OiAxMDE7XHJcbiAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMjVzIGVhc2UtaW4tb3V0O1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIC4yNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICAmLm91dCB7XHJcbiAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjE1cyBlYXNlLWluLW91dDtcclxuICAgICAgICB0cmFuc2l0aW9uOiBhbGwgLjE1cyBlYXNlLWluLW91dDtcclxuICAgICAgICAmOmJlZm9yZSB7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4xNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAuMTVzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4ucG9wdXAtbWVudS1wYW5lbCB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcblxyXG4gICAgYm9yZGVyLXJhZGl1czogNSU7XHJcbiAgICBib3R0b206IDgwcHg7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogLTE1MHB4O1xyXG4gICAgcGFkZGluZzogMjBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIHotaW5kZXg6IDEwMjtcclxuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4yNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjI1cyBlYXNlLWluLW91dDtcclxuICAgIC13ZWJraXQtdHJhbnNpdGlvbi1kZWxheTogLjE1cztcclxuICAgIHRyYW5zaXRpb24tZGVsYXk6IC4xNXM7XHJcbiAgICAtd2Via2l0LXRyYW5zZm9ybS1vcmlnaW46IDUwJSAxMDAlO1xyXG4gICAgdHJhbnNmb3JtLW9yaWdpbjogNTAlIDEwMCU7XHJcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMCk7XHJcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XHJcbiAgICBkaXNwbGF5OiAtbW96LWJveDtcclxuICAgIGRpc3BsYXk6IC13ZWJraXQtZmxleDtcclxuICAgIGRpc3BsYXk6IC1tb3otZmxleDtcclxuICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIC13ZWJraXQtZmxleC13cmFwOiB3cmFwO1xyXG4gICAgLW1vei1mbGV4LXdyYXA6IHdyYXA7XHJcbiAgICAtbXMtZmxleC13cmFwOiB3cmFwO1xyXG4gICAgZmxleC13cmFwOiB3cmFwO1xyXG4gICAgLnBvcHVwLW1lbnUtaXRlbSB7XHJcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICAgIC13ZWJraXQtYm94LWZsZXg6IDEgMCAzMCU7XHJcbiAgICAgICAgLXdlYmtpdC1mbGV4OiAxIDAgMzAlO1xyXG4gICAgICAgIC1tb3otYm94LWZsZXg6IDEgMCAzMCU7XHJcbiAgICAgICAgLW1vei1mbGV4OiAxIDAgMzAlO1xyXG4gICAgICAgIC1tcy1mbGV4OiAxIDAgMzAlO1xyXG4gICAgICAgIGZsZXg6IDEgMCAzMCU7XHJcbiAgICAgICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XHJcbiAgICAgICAgZGlzcGxheTogLW1vei1ib3g7XHJcbiAgICAgICAgZGlzcGxheTogLXdlYmtpdC1mbGV4O1xyXG4gICAgICAgIGRpc3BsYXk6IC1tb3otZmxleDtcclxuICAgICAgICBkaXNwbGF5OiAtbXMtZmxleGJveDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIC13ZWJraXQtYm94LWRpcmVjdGlvbjogbm9ybWFsO1xyXG4gICAgICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XHJcbiAgICAgICAgLXdlYmtpdC1mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIC1tb3otZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAtbXMtZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjI1cyBlYXNlLWluLW91dDtcclxuICAgICAgICB0cmFuc2l0aW9uOiBhbGwgLjI1cyBlYXNlLWluLW91dDtcclxuICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzcGFuIHtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIDAgYXV0byAwO1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxOHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAmOmFjdGl2ZSB7XHJcbiAgICAgICAgICAgIGkge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHJnYigyMjEsNjUsNTMpO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjE1cztcclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjE1cztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzcGFuIHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiByZ2IoMjIxLDY1LDUzKTtcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4xNXM7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBhbGwgLjE1cztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgICYuaW4ge1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbi1kZWxheTogMHM7XHJcbiAgICAgICAgdHJhbnNpdGlvbi1kZWxheTogMHM7XHJcbiAgICAgICAgLnBvcHVwLW1lbnUtaXRlbSB7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uLWRlbGF5OiAuMTVzO1xyXG4gICAgICAgICAgICB0cmFuc2l0aW9uLWRlbGF5OiAuMTVzO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/controls/popmenu/popmenu.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/controls/popmenu/popmenu.component.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var PopmenuComponent = /** @class */ (function () {
    function PopmenuComponent() {
        this.openMenu = false;
    }
    PopmenuComponent.prototype.ngOnInit = function () {
    };
    PopmenuComponent.prototype.togglePopupMenu = function () {
        return this.openMenu = !this.openMenu;
    };
    PopmenuComponent = __decorate([
        core_1.Component({
            selector: 'popmenu',
            template: __webpack_require__(/*! ./popmenu.component.html */ "./src/app/controls/popmenu/popmenu.component.html"),
            styles: [__webpack_require__(/*! ./popmenu.component.scss */ "./src/app/controls/popmenu/popmenu.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], PopmenuComponent);
    return PopmenuComponent;
}());
exports.PopmenuComponent = PopmenuComponent;


/***/ }),

/***/ "./src/app/home-client/home-client.module.ts":
/*!***************************************************!*\
  !*** ./src/app/home-client/home-client.module.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var home_client_page_1 = __webpack_require__(/*! ./home-client.page */ "./src/app/home-client/home-client.page.ts");
var popmenu_component_1 = __webpack_require__(/*! ../controls/popmenu/popmenu.component */ "./src/app/controls/popmenu/popmenu.component.ts");
var routes = [
    {
        path: '',
        component: home_client_page_1.HomeClientPage
    }
];
var HomeClientPageModule = /** @class */ (function () {
    function HomeClientPageModule() {
    }
    HomeClientPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [home_client_page_1.HomeClientPage, popmenu_component_1.PopmenuComponent]
        })
    ], HomeClientPageModule);
    return HomeClientPageModule;
}());
exports.HomeClientPageModule = HomeClientPageModule;


/***/ }),

/***/ "./src/app/home-client/home-client.page.html":
/*!***************************************************!*\
  !*** ./src/app/home-client/home-client.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"secondary\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n        <ion-text color=\"light\">\n          <ion-text color=\"light\" class=\"fw700\">Apparel Designer</ion-text>\n        </ion-text>\n    </ion-title>\n    <ion-buttons slot=\"end\">\n    \t<ion-buttons slot=\"end\">\n\t\t\t\n        <ion-button fill=\"clear\" class=\"shadow-0 txt-light\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n          <ion-icon name=\"cart\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n    </ion-buttons>\n  </ion-toolbar>\n\n</ion-header>\n\n\n<div class=\"logoContainer\">\n   <img src=\"https://www.seekclipart.com/clipng/middle/28-280784_hand-sewing-needles-thread-hypodermic-needle-black-needle.png\" class=\"logo\">\n</div>\n<ion-content>\n  \n  <ion-button  margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"designer()\">\n    Diseñador \n  </ion-button>\n  \n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"vendorCatalog()\">\n    Catalogo de  productos \n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"myOrder()\">\n    Mis pedidos\n  </ion-button>\n\n  <ion-button margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"addProduct()\">\n    Agregar producto\n  </ion-button>\n  \n  <ion-button  *ngIf=\"isAdmin==false\" margin shape=\"round\" expand=\"full\" color=\"secondary\" (click)=\"logout()\">\n    Salir\n  </ion-button>\n\n\n  <popmenu></popmenu>\n\n</ion-content>\n  "

/***/ }),

/***/ "./src/app/home-client/home-client.page.scss":
/*!***************************************************!*\
  !*** ./src/app/home-client/home-client.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-content {\n  --background: var(--ion-color-light); }\n\n:host ion-item {\n  border-radius: 0;\n  border-bottom: 1px dotted var(--ion-color-medium); }\n\n:host ion-card.no-radius {\n  border-radius: 0; }\n\n:host .logoContainer {\n  background-color: var(--ion-color-light); }\n\n:host .logoContainer .logo {\n    width: 100px;\n    height: 100px;\n    margin: 10px auto 8px;\n    background-size: 50%;\n    margin-left: 35%; }\n\n:host .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS1jbGllbnQvQzpcXFVzZXJzXFxkY2hpbmNoaWxsYVxcRGVza3RvcFxcRW50cmVnYWJsZVxccHJveWVjdG9EZWxtYW5DaGluY2hpbGxhL3NyY1xcYXBwXFxob21lLWNsaWVudFxcaG9tZS1jbGllbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRVEsb0NBQWEsRUFBQTs7QUFGckI7RUFNUSxnQkFBZ0I7RUFDaEIsaURBQWlELEVBQUE7O0FBUHpEO0VBWVksZ0JBQWdCLEVBQUE7O0FBWjVCO0VBd0JPLHdDQUF3QyxFQUFBOztBQXhCL0M7SUFpQlEsWUFBWTtJQUNaLGFBQWE7SUFDYixxQkFBcUI7SUFDckIsb0JBQW9CO0lBQ3JCLGdCQUFnQixFQUFBOztBQXJCdkI7RUE4Qkksc0ZBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2hvbWUtY2xpZW50L2hvbWUtY2xpZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAgIGlvbi1jb250ZW50IHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IGRvdHRlZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgIH1cclxuXHJcbiAgICBpb24tY2FyZCB7XHJcbiAgICAgICAgJi5uby1yYWRpdXMge1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuLmxvZ29Db250YWluZXJ7XHJcbiAgICAubG9nbyB7XHJcbiAgICAgICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4IGF1dG8gOHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogNTAlO1xyXG4gICAgICAgbWFyZ2luLWxlZnQ6IDM1JTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgIFxyXG59XHJcblxyXG4udG9vbGJhciB7XHJcbiAgIFxyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XHJcbiAgICAgICAgXHJcbiAgfVxyXG4gICBcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/home-client/home-client.page.ts":
/*!*************************************************!*\
  !*** ./src/app/home-client/home-client.page.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var currencies_1 = __webpack_require__(/*! src/providers/currencies */ "./src/providers/currencies.ts");
var users_1 = __webpack_require__(/*! src/providers/users */ "./src/providers/users.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var HomeClientPage = /** @class */ (function () {
    function HomeClientPage(navCtrl, currenciesProv, toastCtrl, menuCtrl, events, usersProv, router) {
        this.navCtrl = navCtrl;
        this.currenciesProv = currenciesProv;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.events = events;
        this.usersProv = usersProv;
        this.router = router;
        this.menu = [];
        this.isAdmin = false;
    }
    HomeClientPage.prototype.ngOnInit = function () { };
    HomeClientPage.prototype.addProduct = function () {
        this.navCtrl.navigateRoot('/add-product');
    };
    HomeClientPage.prototype.designer = function () {
        this.navCtrl.navigateRoot('/designer');
    };
    HomeClientPage.prototype.administration = function () {
        this.navCtrl.navigateRoot('/administration');
    };
    HomeClientPage.prototype.vendorCatalog = function () {
        this.navCtrl.navigateRoot('/home');
    };
    HomeClientPage.prototype.myOrder = function () {
        this.navCtrl.navigateRoot('/myorder');
    };
    HomeClientPage.prototype.logout = function () {
        var _this = this;
        this.usersProv.logoutUser().then(function () {
            _this.user = null;
            _this.router.navigateByUrl('/login');
            _this.menuCtrl.enable(false);
        });
    };
    HomeClientPage = __decorate([
        core_1.Component({
            selector: "app-home-client",
            template: __webpack_require__(/*! ./home-client.page.html */ "./src/app/home-client/home-client.page.html"),
            styles: [__webpack_require__(/*! ./home-client.page.scss */ "./src/app/home-client/home-client.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.NavController,
            currencies_1.CurrenciesProvider,
            angular_1.ToastController,
            angular_1.MenuController,
            angular_1.Events,
            users_1.UsersProvider,
            router_1.Router])
    ], HomeClientPage);
    return HomeClientPage;
}());
exports.HomeClientPage = HomeClientPage;


/***/ })

}]);
//# sourceMappingURL=home-client-home-client-module.js.map