(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["post-post-module"],{

/***/ "./src/app/post/post.module.ts":
/*!*************************************!*\
  !*** ./src/app/post/post.module.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var post_page_1 = __webpack_require__(/*! ./post.page */ "./src/app/post/post.page.ts");
var routes = [
    {
        path: '',
        component: post_page_1.PostPage
    }
];
var PostPageModule = /** @class */ (function () {
    function PostPageModule() {
    }
    PostPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [post_page_1.PostPage]
        })
    ], PostPageModule);
    return PostPageModule;
}());
exports.PostPageModule = PostPageModule;


/***/ }),

/***/ "./src/app/post/post.page.html":
/*!*************************************!*\
  !*** ./src/app/post/post.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n     <ion-buttons slot=\"start\">\n      <ion-back-button class=\"fs-24 txt1\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Post</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\t<div class=\"\">\n\t\t<img src=\"{{obj.thumb}}\">\n\t</div>\n\t<br>\n\t<div padding class=\"\">\n\t\t<h2 class=\"txt1 fw-600 spacing1\">{{obj.name}}</h2>\n\t\t<p class=\"txt-b3\">Posted {{obj.created.substring(4, 15)}}</p>\n\t\t<p class=\"txt-b2\">{{obj.content}}</p>\n\t</div>\n\n\t<div padding class=\"social-share\">\n\t\t<h4 class=\"mg-0 uppercase fs-14 spacing-1\">share with:</h4>\n\t\t<div class=\"btn-social\" text-right>\n\t\t\t<ion-button fill=\"clear\" size=\"small\" (click)=\"share(obj.link_share)\" class=\"txt1\">\n\t\t\t\t<ion-icon name=\"logo-facebook\"></ion-icon>\n\t\t\t</ion-button>\n\t\t\t<ion-button fill=\"clear\" size=\"small\" (click)=\"share(obj.link_share)\" class=\"txt1\">\n\t\t\t\t<ion-icon name=\"logo-twitter\"></ion-icon>\n\t\t\t</ion-button>\n\t\t\t<ion-button fill=\"clear\" size=\"small\" (click)=\"share(obj.link_share)\" class=\"txt1\">\n\t\t\t\t<ion-icon name=\"logo-google\"></ion-icon>\n\t\t\t</ion-button>\n\t\t\t<ion-button fill=\"clear\" size=\"small\" (click)=\"share(obj.link_share)\" class=\"txt1\">\n\t\t\t\t<ion-icon name=\"logo-instagram\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</div>\n\t</div>\n\n\t<br/>\n\t<br/>\n\n\t<div padding class=\"\" *ngIf=\"list_related.length > 0\">\n\t\t<h2 class=\"uppercase fs-14 spacing-1\">related articles</h2>\n\t\t<br>\n\t\t<div class=\"item-related mgb-20\" *ngFor=\"let item of list_related\" [routerLink]=\"['/post', item]\">\n\t\t\t<div class=\"thumb ovfl-hidden\">\n\t\t\t\t<img src=\"{{item.thumb}}\">\t\n\t\t\t</div>\n\t\t\t<div class=\"description ovfl-hidden pdl-10\">\n\t\t\t\t<h4 class=\"ellipsis fs-16 mgb-0\">{{item.name}}</h4>\n\t\t\t\t<p class=\"fs-12 txt-b3 mg-0\">{{item.created.substring(4, 15)}}</p>\n\t\t\t\t<p class=\"ellipsis txt-b2 mg-0\">{{item.description}}</p>\n\t\t\t</div>\n\t\t</div>\n\t\t<br>\n\t</div>\n\n\t<br>\n\t<br>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/post/post.page.scss":
/*!*************************************!*\
  !*** ./src/app/post/post.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item-related {\n  display: flex;\n  align-items: center; }\n  .item-related .thumb {\n    width: 80px;\n    height: 70px; }\n  .item-related .description {\n    flex: 1; }\n  .social-share {\n  display: flex;\n  align-items: center; }\n  .social-share .btn-social {\n    flex: 1; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcG9zdC9DOlxcVXNlcnNcXGRjaGluY2hpbGxhXFxEZXNrdG9wXFxFbnRyZWdhYmxlXFxwcm95ZWN0b0RlbG1hbkNoaW5jaGlsbGEvc3JjXFxhcHBcXHBvc3RcXHBvc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsYUFBYTtFQUNiLG1CQUFtQixFQUFBO0VBRnBCO0lBSUUsV0FBVztJQUNYLFlBQVksRUFBQTtFQUxkO0lBUUUsT0FBTyxFQUFBO0VBR1Q7RUFDQyxhQUFhO0VBQ2IsbUJBQW1CLEVBQUE7RUFGcEI7SUFJRSxPQUFPLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wb3N0L3Bvc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0tcmVsYXRlZHtcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0LnRodW1ie1xuXHRcdHdpZHRoOiA4MHB4O1xuXHRcdGhlaWdodDogNzBweDtcblx0fVxuXHQuZGVzY3JpcHRpb257XG5cdFx0ZmxleDogMTtcblx0fVxufVxuLnNvY2lhbC1zaGFyZXtcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0LmJ0bi1zb2NpYWx7XG5cdFx0ZmxleDogMTtcblx0fVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/post/post.page.ts":
/*!***********************************!*\
  !*** ./src/app/post/post.page.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var posts_1 = __webpack_require__(/*! ../../providers/posts */ "./src/providers/posts.ts");
var ngx_1 = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
var PostPage = /** @class */ (function () {
    function PostPage(loadingCtrl, postsProv, route, socialSharing) {
        // this.presentLoading();
        var _this = this;
        this.loadingCtrl = loadingCtrl;
        this.postsProv = postsProv;
        this.route = route;
        this.socialSharing = socialSharing;
        this.list_related = [];
        this.route.params.subscribe(function (params) {
            _this.obj = params;
            _this.postsProv.getPostByRelated(_this.obj.tag, _this.obj.name).then(function (data) {
                // this.loading.dismiss().then(() => {
                _this.list_related = data;
                console.log(_this.list_related);
                // });
            });
        });
        console.log(this.obj);
    }
    PostPage.prototype.ionViewWillEnter = function () {
    };
    PostPage.prototype.share = function (link) {
        this.socialSharing.share(this.obj.name, this.obj.description, null, link);
    };
    PostPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    PostPage.prototype.ngOnInit = function () {
    };
    PostPage = __decorate([
        core_1.Component({
            selector: 'app-post',
            template: __webpack_require__(/*! ./post.page.html */ "./src/app/post/post.page.html"),
            styles: [__webpack_require__(/*! ./post.page.scss */ "./src/app/post/post.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.LoadingController,
            posts_1.PostsProvider,
            router_1.ActivatedRoute,
            ngx_1.SocialSharing])
    ], PostPage);
    return PostPage;
}());
exports.PostPage = PostPage;


/***/ })

}]);
//# sourceMappingURL=post-post-module.js.map