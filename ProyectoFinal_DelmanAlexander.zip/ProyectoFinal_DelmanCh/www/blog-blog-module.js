(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["blog-blog-module"],{

/***/ "./src/app/blog/blog.module.ts":
/*!*************************************!*\
  !*** ./src/app/blog/blog.module.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var blog_page_1 = __webpack_require__(/*! ./blog.page */ "./src/app/blog/blog.page.ts");
var routes = [
    {
        path: '',
        component: blog_page_1.BlogPage
    }
];
var BlogPageModule = /** @class */ (function () {
    function BlogPageModule() {
    }
    BlogPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [blog_page_1.BlogPage]
        })
    ], BlogPageModule);
    return BlogPageModule;
}());
exports.BlogPageModule = BlogPageModule;


/***/ }),

/***/ "./src/app/blog/blog.page.html":
/*!*************************************!*\
  !*** ./src/app/blog/blog.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar>\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon class=\"fs-24 txt1\" name=\"ios-arrow-round-forward\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title>Blog</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\t<h2 class=\"uppercase spacing-1 pdr-50\" padding>Our articles, invite you to follow</h2>\n\n\t<div class=\"wrap-top-slide\" *ngIf=\"list_post_star\">\n\t\t<ion-slides spaceBetween=\"10\" slidesPerView=\"2\" loop=\"true\">\n\t\t\t<ion-slide *ngFor=\"let item of list_post_star\" [routerLink]=\"['/post', item]\">\n\t\t\t\t<div text-left class=\"item-slide\">\n\t\t\t\t\t<div class=\"thumb ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{item.thumb}}\">\n\t\t\t\t\t</div>\n\t\t\t\t\t<p class=\"pdl-15 pdr-15 ellipsis txt3 mgb-0 fs-14\">{{item.name}}</p>\n\t\t\t\t\t<h4 class=\"pdl-15 pdr-15 fw-500 fs-18 txt1 mgt-0 ellipsis\">{{item.description}}</h4>\n\t\t\t\t</div>\n\t\t\t</ion-slide>\n\t\t</ion-slides>\n\t</div>\n\n\t<h2 class=\"uppercase spacing-1 pdr-50\" padding>New post</h2>\n\n\t<div class=\"wrap-new-slide\" *ngIf=\"list_post_new\">\n\t\t<ion-slides spaceBetween=\"10\" slidesPerView=\"2\" loop=\"true\">\n\t\t\t<ion-slide *ngFor=\"let item of list_post_new\" [routerLink]=\"['/post', item]\">\n\t\t\t\t<div text-left class=\"item-slide flex-row\">\n\t\t\t\t\t<div class=\"thumb ovfl-hidden flex-1\">\n\t\t\t\t\t\t<img src=\"{{item.thumb}}\">\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"description ovfl-hidden flex-2\">\n\t\t\t\t\t\t<h4 class=\"pdl-15 pdr-15 fw-500 fs-16 txt1 mgt-10 mgb-0 ellipsis\">{{item.name}}</h4>\n\t\t\t\t\t\t<span class=\"pdl-15 fs-12 txt3\">{{item.created.substring(4, 15)}}</span>\n\t\t\t\t\t\t<p class=\"pdl-15 pdr-15 ellipsis txt3 mg-0 fs-12\">{{item.description}}</p>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</ion-slide>\n\t\t</ion-slides>\n\t</div>\n\n\t<br>\n\t<br>\n\n\t<h2 class=\"uppercase spacing-1 pdr-50\" padding>All our posts</h2>\n\n\t<div class=\"\">\n\t\t<ion-row>\n\t\t\t<ion-col size=\"6\" *ngFor=\"let item of list_post\" [routerLink]=\"['/post', item]\">\n\t\t\t\t<div class=\"item-post mgb-30\">\n\t\t\t\t\t<div class=\"thumb ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{item.thumb}}\">\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"description\">\n\t\t\t\t\t\t<h3 class=\"fs-14 txt1 fw-600 mgt-10\">{{item.name}}</h3>\n\t\t\t\t\t\t<span class=\"fs-12 txt3\">{{item.created.substring(4, 15)}}</span>\n\t\t\t\t\t\t<p class=\"fs-12 txt3\">{{item.description}}</p>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</div>\n\n\t<br>\n\n\t<ion-infinite-scroll (ionInfinite)=\"loadMore($event)\">\n\t\t<ion-infinite-scroll-content></ion-infinite-scroll-content>\n\t</ion-infinite-scroll>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/blog/blog.page.scss":
/*!*************************************!*\
  !*** ./src/app/blog/blog.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".wrap-top-slide {\n  width: 105%; }\n  .wrap-top-slide .thumb {\n    height: 130px; }\n  .wrap-new-slide {\n  width: 100%; }\n  .wrap-new-slide .item-slide {\n    display: flex; }\n  .wrap-new-slide .description {\n    flex: 2; }\n  .wrap-new-slide .thumb {\n    flex: 1;\n    height: 70px; }\n  .item-post .thumb {\n  height: 90px; }\n  .item-post .description h3 {\n  height: 32px;\n  overflow: hidden; }\n  .item-post .description p {\n  height: 42px;\n  overflow: hidden; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYmxvZy9DOlxcVXNlcnNcXGRjaGluY2hpbGxhXFxEZXNrdG9wXFxFbnRyZWdhYmxlXFxwcm95ZWN0b0RlbG1hbkNoaW5jaGlsbGEvc3JjXFxhcHBcXGJsb2dcXGJsb2cucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsV0FBVyxFQUFBO0VBRFo7SUFHRSxhQUFhLEVBQUE7RUFHZjtFQUNDLFdBQVcsRUFBQTtFQURaO0lBR0UsYUFBYSxFQUFBO0VBSGY7SUFNRSxPQUFPLEVBQUE7RUFOVDtJQVNFLE9BQU87SUFDUCxZQUFZLEVBQUE7RUFHZDtFQUVFLFlBQVksRUFBQTtFQUZkO0VBTUcsWUFBWTtFQUNaLGdCQUFnQixFQUFBO0VBUG5CO0VBVUcsWUFBWTtFQUNaLGdCQUFnQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvYmxvZy9ibG9nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwLXRvcC1zbGlkZXtcblx0d2lkdGg6IDEwNSU7XG5cdC50aHVtYntcblx0XHRoZWlnaHQ6IDEzMHB4O1xuXHR9XG59XG4ud3JhcC1uZXctc2xpZGV7XG5cdHdpZHRoOiAxMDAlO1xuXHQuaXRlbS1zbGlkZXtcblx0XHRkaXNwbGF5OiBmbGV4O1xuXHR9XG5cdC5kZXNjcmlwdGlvbntcblx0XHRmbGV4OiAyO1xuXHR9XG5cdC50aHVtYntcblx0XHRmbGV4OiAxO1xuXHRcdGhlaWdodDogNzBweDtcblx0fVxufVxuLml0ZW0tcG9zdHtcblx0LnRodW1ie1xuXHRcdGhlaWdodDogOTBweDtcblx0fVxuXHQuZGVzY3JpcHRpb257XG5cdFx0aDN7XG5cdFx0XHRoZWlnaHQ6IDMycHg7XG5cdFx0XHRvdmVyZmxvdzogaGlkZGVuO1xuXHRcdH1cblx0XHRwe1xuXHRcdFx0aGVpZ2h0OiA0MnB4O1xuXHRcdFx0b3ZlcmZsb3c6IGhpZGRlbjtcblx0XHR9XG5cdH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/blog/blog.page.ts":
/*!***********************************!*\
  !*** ./src/app/blog/blog.page.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var posts_1 = __webpack_require__(/*! ../../providers/posts */ "./src/providers/posts.ts");
var BlogPage = /** @class */ (function () {
    function BlogPage(loadingCtrl, postsProv) {
        var _this = this;
        this.loadingCtrl = loadingCtrl;
        this.postsProv = postsProv;
        this.presentLoading();
        this.postsProv.getPostByStar().then(function (data) {
            _this.list_post_star = data;
            console.log(_this.list_post_star);
        }, function (error) {
        });
        this.postsProv.getPostByNew().then(function (data) {
            _this.list_post_new = data;
            console.log(_this.list_post_new);
        }, function (error) {
        });
        this.postsProv.getPost(null, 2).then(function (data) {
            _this.loading.dismiss().then(function () {
                _this.list_post = data;
                _this.start = data[data.length - 1].name;
                console.log(_this.list_post);
            });
        }, function (error) {
        });
    }
    BlogPage.prototype.loadMore = function (event) {
        var _this = this;
        this.postsProv.getPost(this.start, 2).then(function (data) {
            _this.loading.dismiss().then(function () {
                _this.list_post = _this.list_post.concat(data);
                console.log(data);
                if (data.length > 0) {
                    _this.start = data[data.length - 1].name;
                }
                console.log(_this.list_post);
                setTimeout(function () {
                    event.target.disabled = true;
                }, 1500);
            });
        });
    };
    BlogPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    BlogPage.prototype.ngOnInit = function () {
    };
    BlogPage = __decorate([
        core_1.Component({
            selector: 'app-blog',
            template: __webpack_require__(/*! ./blog.page.html */ "./src/app/blog/blog.page.html"),
            styles: [__webpack_require__(/*! ./blog.page.scss */ "./src/app/blog/blog.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.LoadingController,
            posts_1.PostsProvider])
    ], BlogPage);
    return BlogPage;
}());
exports.BlogPage = BlogPage;


/***/ })

}]);
//# sourceMappingURL=blog-blog-module.js.map