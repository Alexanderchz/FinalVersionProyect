(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["administration-administration-module"],{

/***/ "./src/app/administration/administration.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/administration/administration.module.ts ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var administration_page_1 = __webpack_require__(/*! ./administration.page */ "./src/app/administration/administration.page.ts");
var routes = [
    {
        path: '',
        component: administration_page_1.AdministrationPage
    }
];
var AdministrationPageModule = /** @class */ (function () {
    function AdministrationPageModule() {
    }
    AdministrationPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [administration_page_1.AdministrationPage]
        })
    ], AdministrationPageModule);
    return AdministrationPageModule;
}());
exports.AdministrationPageModule = AdministrationPageModule;


/***/ }),

/***/ "./src/app/administration/administration.page.html":
/*!*********************************************************!*\
  !*** ./src/app/administration/administration.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-client\"></ion-back-button>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\n\n\t\t<ion-title color=\"light\">Administracion</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n    \n<ion-content>\n     <ion-button color=\"primary\" (click)=\"categories()\">Agregar negocio</ion-button>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/administration/administration.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/administration/administration.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRtaW5pc3RyYXRpb24vQzpcXFVzZXJzXFxkY2hpbmNoaWxsYVxcRGVza3RvcFxcRW50cmVnYWJsZVxccHJveWVjdG9EZWxtYW5DaGluY2hpbGxhL3NyY1xcYXBwXFxhZG1pbmlzdHJhdGlvblxcYWRtaW5pc3RyYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksc0ZBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2FkbWluaXN0cmF0aW9uL2FkbWluaXN0cmF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyIHtcclxuICAgXHJcbiAgICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcclxuICAgICAgICBcclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/administration/administration.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/administration/administration.page.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var AdministrationPage = /** @class */ (function () {
    function AdministrationPage(navCtrl) {
        this.navCtrl = navCtrl;
    }
    AdministrationPage.prototype.ngOnInit = function () {
    };
    AdministrationPage.prototype.categories = function () {
        this.navCtrl.navigateRoot('/categories');
    };
    AdministrationPage = __decorate([
        core_1.Component({
            selector: 'app-administration',
            template: __webpack_require__(/*! ./administration.page.html */ "./src/app/administration/administration.page.html"),
            styles: [__webpack_require__(/*! ./administration.page.scss */ "./src/app/administration/administration.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.NavController])
    ], AdministrationPage);
    return AdministrationPage;
}());
exports.AdministrationPage = AdministrationPage;


/***/ })

}]);
//# sourceMappingURL=administration-administration-module.js.map