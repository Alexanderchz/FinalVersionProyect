(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["about-about-module"],{

/***/ "./src/app/about/about.module.ts":
/*!***************************************!*\
  !*** ./src/app/about/about.module.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var forms_2 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var about_page_1 = __webpack_require__(/*! ./about.page */ "./src/app/about/about.page.ts");
var routes = [
    {
        path: '',
        component: about_page_1.AboutPage
    }
];
var AboutPageModule = /** @class */ (function () {
    function AboutPageModule() {
    }
    AboutPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                forms_2.ReactiveFormsModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [about_page_1.AboutPage]
        })
    ], AboutPageModule);
    return AboutPageModule;
}());
exports.AboutPageModule = AboutPageModule;


/***/ }),

/***/ "./src/app/about/about.page.html":
/*!***************************************!*\
  !*** ./src/app/about/about.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar>\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon class=\"fs-24 txt1\" name=\"ios-arrow-round-forward\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title>About</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\t<br>\n\t<h2 class=\"uppercase fw-600 spacing2 pdr-50 txt1\">Beautiful and outstanding image about us</h2>\n\t<br>\n\t<div text-right *ngIf=\"about\" class=\"social flex-row flex-jus-end pdl-25 pdr-25\">\n\t\t<span *ngIf=\"about.facebook != null && about.facebook != '' \">\n\t\t\t<ion-button fill=\"clear\" (click)=\"social(about.facebook)\" class=\"flex-1 fs-16 txt3\">\n\t\t\t\t<ion-icon name=\"logo-facebook\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</span>\n\t\t<span *ngIf=\"about.twitter != null && about.twitter != '' \">\n\t\t\t<ion-button fill=\"clear\" (click)=\"social(about.twitter)\" class=\"flex-1 fs-16 txt4\">\n\t\t\t\t<ion-icon name=\"logo-twitter\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</span>\n\t\t<span *ngIf=\"about.google_plus != null && about.google_plus != '' \">\n\t\t\t<ion-button fill=\"clear\" (click)=\"social(about.google_plus)\" class=\"flex-1 fs-16 txt4\">\n\t\t\t\t<ion-icon name=\"logo-google\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</span>\n\t\t<span *ngIf=\"about.instagram != null && about.instagram != '' \">\n\t\t\t<ion-button fill=\"clear\" (click)=\"social(about.instagram)\" class=\"flex-1 fs-16 txt4\">\n\t\t\t\t<ion-icon name=\"logo-instagram\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</span>\n\t\t<span *ngIf=\"about.pinterest != null && about.pinterest != '' \">\n\t\t\t<ion-button fill=\"clear\" (click)=\"social(about.pinterest)\" class=\"flex-1 fs-16 txt4\">\n\t\t\t\t<ion-icon name=\"logo-pinterest\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</span>\n\t\t<span *ngIf=\"about.youtube != null && about.youtube != '' \">\n\t\t\t<ion-button fill=\"clear\" (click)=\"social(about.youtube)\" class=\"flex-1 fs-16 txt4\">\n\t\t\t\t<ion-icon name=\"logo-youtube\"></ion-icon>\n\t\t\t</ion-button>\n\t\t</span>\n\t</div>\n\t<br>\n\t<br>\n\t<div class=\"wrap-top-slide\" *ngIf=\"preview.length > 0\">\n\t\t<ion-slides loop=\"true\">\n\t\t\t<ion-slide *ngFor=\"let item of preview\">\n\t\t\t\t<div text-left class=\"item-slide\">\n\t\t\t\t\t<div class=\"thumb flex-row flex-jus-center flex-ali-center ovfl-hidden\">\n\t\t\t\t\t\t<img src=\"{{item}}\">\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</ion-slide>\n\t\t</ion-slides>\n\t</div>\n\n\t<br>\n\n\t<div padding class=\"\" *ngIf=\"about\">\n\t\t<h2 class=\"uppercase fs-16 fw-600 spacing2 txt1\">find us</h2>\n\t\t<br>\n\t\t<div class=\"mgt-20\">\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.email1 != null && about.email1 != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-mail\"></ion-icon>\n\t\t\t\t<span>\n\t\t\t\t\t<p class=\"fs-12 mg-0 txt3\">Email 1</p>\n\t\t\t\t\t<p class=\"fs-14 fw-600 mgt-5 mgb-0 txt1\">{{about.email1}}</p>\n\t\t\t\t</span>\n\t\t\t</h5>\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.email2 != null && about.email2 != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-mail\"></ion-icon>\n\t\t\t\t<span>\n\t\t\t\t\t<p class=\"fs-12 mg-0 txt3\">Email 2</p>\n\t\t\t\t\t<p class=\"fs-14 fw-600 mgt-5 mgb-0 txt1\">{{about.email2}}</p>\n\t\t\t\t</span>\n\t\t\t</h5>\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.phone1 != null && about.phone1 != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-call\"></ion-icon>\n\t\t\t\t<span class=\"flex-1\">\n\t\t\t\t\t<p class=\"fs-12 mg-0 txt3\">Phone 1</p>\n\t\t\t\t\t<p class=\"fs-14 fw-600 mgt-5 mgb-0 txt1\">{{about.phone1}}</p>\n\t\t\t\t</span>\n\t\t\t\t<ion-button size=\"small\" shape=\"round\" class=\"fs-12\" (click)=\"call(about.phone1)\">\n\t\t\t\t\t<ion-icon name=\"call\"></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t</h5>\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.phone2 != null && about.phone2 != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-call\"></ion-icon>\n\t\t\t\t<span class=\"flex-1\">\n\t\t\t\t\t<p class=\"fs-12 mg-0 txt3\">Phone 2</p>\n\t\t\t\t\t<p class=\"fs-14 fw-600 mgt-5 mgb-0 txt1\">{{about.phone2}}</p>\n\t\t\t\t</span>\n\t\t\t\t<ion-button size=\"small\" shape=\"round\" class=\"fs-12\" (click)=\"call(about.phone2)\">\n\t\t\t\t\t<ion-icon name=\"call\"></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t</h5>\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.address != null && about.address != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-pin\"></ion-icon>\n\t\t\t\t<span>\n\t\t\t\t\t<p class=\"fs-12 mg-0 txt3\">Address</p>\n\t\t\t\t\t<p class=\"fs-14 fw-600 mgt-5 mgb-0 txt1\">{{about.address}}</p>\n\t\t\t\t</span>\n\t\t\t</h5>\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.website != null && about.website != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-globe\"></ion-icon>\n\t\t\t\t<span>\n\t\t\t\t\t<p class=\"fs-12 mg-0 txt3\">Website</p>\n\t\t\t\t\t<p class=\"fs-14 fw-600 mgt-5 mgb-0 txt1\">{{about.website}}</p>\n\t\t\t\t</span>\n\t\t\t</h5>\n\t\t\t<h5 class=\"flex-row flex-ali-start\" *ngIf=\"about.time_work != null && about.time_work != '' \">\n\t\t\t\t<ion-icon class=\"mgr-15 fs-20 txt4\" name=\"md-time\"></ion-icon>\n\t\t\t\t<span>\n\t\t\t\t\t<p class=\"fs-12 mg-0 fs-14 txt3\">Time work</p>\n\t\t\t\t\t<p class=\"fw-600 mgt-5 txt1\">{{about.time_work}}</p>\n\t\t\t\t</span>\n\t\t\t</h5>\n\t\t</div>\n\t</div>\n\n\t<br>\n\t\n\t<div class=\"pdl-50\" *ngIf=\"about && about.map != null && about.map != '' \">\n\t\t<div [innerHtml]=\"about.map\"></div>\n\t</div>\n\n\t<br>\n\t<br>\n\n\t<div padding>\n\t\t<form (ngSubmit)=\"submitForm()\" [formGroup]=\"dataForm\">\n\t\t\t<label class=\"txt-3 fs-12 mgt-10\">Full name</label>\n\t\t\t<ion-item>\n\t\t\t\t<ion-input type=\"text\" class=\"form-control fs-14\" formControlName=\"fullname\"></ion-input>\n\t\t\t</ion-item>\n\t\t\t<p class=\"fs-12 mgt-5 txt-danger\" *ngIf=\"!dataForm.controls.fullname.valid && dataForm.controls.fullname.dirty\">\n\t\t\t\tPlease enter a valid fullname.\n\t\t\t</p>\n\n\n\t\t\t<br>\n\t\t\t<label class=\"txt-3 fs-12 mgt-10\">Email</label>\n\t\t\t<ion-item>\n\t\t\t\t<ion-input type=\"text\" class=\"form-control fs-14\" formControlName=\"email\"></ion-input>\n\t\t\t</ion-item>\n\t\t\t<p class=\"fs-12 mgt-5 txt-danger\" *ngIf=\"!dataForm.controls.email.valid && dataForm.controls.email.dirty\">\n\t\t\t\tPlease enter a valid email.\n\t\t\t</p>\n\n\t\t\t<br>\n\t\t\t<label class=\"txt-3 fs-12 mgt-10\">Message</label>\n\t\t\t<ion-item>\n\t\t\t\t<ion-input type=\"email\" class=\"form-control fs-14\" formControlName=\"message\"></ion-input>\n\t\t\t</ion-item>\n\t\t\t<p class=\"fs-12 mgt-5 txt-danger\" *ngIf=\"!dataForm.controls.message.valid && dataForm.controls.message.dirty\">\n\t\t\t\tPlease enter a valid message.\n\t\t\t</p>\n\n\t\t\t<div class=\"mgt-30\" text-right>\n\t\t\t\t<ion-button shape=\"round\" type=\"submit\" class=\"btn btn-sm mg-5 btn-success\">\n\t\t\t\t\t<ion-icon slot=\"start\" name=\"ios-send\"></ion-icon> Send\n\t\t\t\t</ion-button>\n\t\t\t</div>\n\t\t</form>\n\t</div>\n\n\t<br>\n\t<br>\n\n\t<div padding class=\"pdr-50\">\n\t\t<h2 class=\"uppercase fs-16 fw-600 spacing2\">provision</h2>\n\t\t<p class=\"fs-13 txt2 pdl-15 pdr-30\" *ngIf=\"about\">\n\t\t\t{{about.provision}}\n\t\t</p>\n\t</div>\n\t<br>\n\t<br>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/about/about.page.scss":
/*!***************************************!*\
  !*** ./src/app/about/about.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".wrap-top-slide .thumb {\n  height: 150px; }\n\n.social {\n  border-bottom: 1px solid #ebebeb; }\n\niframe {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWJvdXQvQzpcXFVzZXJzXFxkY2hpbmNoaWxsYVxcRGVza3RvcFxcRW50cmVnYWJsZVxccHJveWVjdG9EZWxtYW5DaGluY2hpbGxhL3NyY1xcYXBwXFxhYm91dFxcYWJvdXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsYUFBYSxFQUFBOztBQUdmO0VBQ0MsZ0NBQWdDLEVBQUE7O0FBRWpDO0VBQ0MsV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvYWJvdXQvYWJvdXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXAtdG9wLXNsaWRle1xuXHQudGh1bWJ7XG5cdFx0aGVpZ2h0OiAxNTBweDtcblx0fVxufVxuLnNvY2lhbHtcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlYmViZWI7XG59XG5pZnJhbWV7XG5cdHdpZHRoOiAxMDAlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/about/about.page.ts":
/*!*************************************!*\
  !*** ./src/app/about/about.page.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var AboutPage = /** @class */ (function () {
    function AboutPage() {
    }
    AboutPage = __decorate([
        core_1.Component({
            selector: 'app-about',
            template: __webpack_require__(/*! ./about.page.html */ "./src/app/about/about.page.html"),
            styles: [__webpack_require__(/*! ./about.page.scss */ "./src/app/about/about.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], AboutPage);
    return AboutPage;
}());
exports.AboutPage = AboutPage;


/***/ })

}]);
//# sourceMappingURL=about-about-module.js.map