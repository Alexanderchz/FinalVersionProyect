(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forgot-forgot-module"],{

/***/ "./src/app/forgot/forgot.module.ts":
/*!*****************************************!*\
  !*** ./src/app/forgot/forgot.module.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var forms_2 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var forgot_page_1 = __webpack_require__(/*! ./forgot.page */ "./src/app/forgot/forgot.page.ts");
var routes = [
    {
        path: '',
        component: forgot_page_1.ForgotPage
    }
];
var ForgotPageModule = /** @class */ (function () {
    function ForgotPageModule() {
    }
    ForgotPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                forms_2.ReactiveFormsModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [forgot_page_1.ForgotPage]
        })
    ], ForgotPageModule);
    return ForgotPageModule;
}());
exports.ForgotPageModule = ForgotPageModule;


/***/ }),

/***/ "./src/app/forgot/forgot.page.html":
/*!*****************************************!*\
  !*** ./src/app/forgot/forgot.page.html ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button class=\"fs-24 txt-light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title color=\"light\">Reseteo de contraseña</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\t<div class=\"wrapp-pst\" padding>\n\t\t<div padding class=\"mgt-70\">\n\t\t\t<h1 class=\"uppercase fw-900 fs-30 spacing-3 mgb-0\">Apparel Designer</h1>\n\t\t\t<h3 class=\"uppercase fw-600 fs-20 spacing-2 mgl-20 pdt-0\">Olvide mi contraseña</h3>\n\t\t\t<p class=\"pdl-20 fs-12\">.</p>\n\t\t</div>\n\n\n\t\t<div class=\"wrapp-form mgt-50\" padding>\n\t\t\t<form [formGroup]=\"resetPasswordForm\" (submit)=\"resetPassword()\" novalidate>\n\t\t\t\t<ion-label stacked class=\"mgb-5 pdl-10\">Correo</ion-label>\n\t\t\t\t<ion-list class=\"ani-bottom-to-top mgb-0\">\n\t\t\t\t\t<ion-item class=\"white-opct bdra-30\">\n\t\t\t\t\t\t<ion-input #email formControlName=\"email\" type=\"email\" placeholder=\"Your email address\" [class.invalid]=\"!resetPasswordForm.controls.email.valid && resetPasswordForm.controls.email.dirty\" class=\"\"></ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t</ion-list>\n\n\t\t\t\t<div class=\"error-message\" *ngIf=\"!resetPasswordForm.controls.email.valid && resetPasswordForm.controls.email.dirty\">\n\t\t\t\t\t<p class=\"fs-11 mgt-5\">Porfavor ingresa un correo valido.</p>\n\t\t\t\t</div>\n\t\t\t\t\n\t\t\t\t<div padding class=\"\">\n\t\t\t\t\t<ion-button expand=\"block\" shape=\"round\" class=\"mgt-20 uppercase fw-600 spacing1 ani-bottom-to-top\" type=\"submit\">\n\t\t\t\t\t\tResetear la contraseña\n\t\t\t\t\t</ion-button>\n\t\t\t\t</div>\n\t\t\t</form>\n\t\t</div>\n\t</div>\n</ion-content>"

/***/ }),

/***/ "./src/app/forgot/forgot.page.scss":
/*!*****************************************!*\
  !*** ./src/app/forgot/forgot.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9yZ290L0M6XFxVc2Vyc1xcZGNoaW5jaGlsbGFcXERlc2t0b3BcXEVudHJlZ2FibGVcXHByb3llY3RvRGVsbWFuQ2hpbmNoaWxsYS9zcmNcXGFwcFxcZm9yZ290XFxmb3Jnb3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBRUksc0ZBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2ZvcmdvdC9mb3Jnb3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbi50b29sYmFyIHtcbiAgIFxuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgdmFyKC0taW9uLWNvbG9yLWRhcmspLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkpO1xuICAgICAgICBcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/forgot/forgot.page.ts":
/*!***************************************!*\
  !*** ./src/app/forgot/forgot.page.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var email_1 = __webpack_require__(/*! ../../validators/email */ "./src/validators/email.ts");
var users_1 = __webpack_require__(/*! ../../providers/users */ "./src/providers/users.ts");
var ForgotPage = /** @class */ (function () {
    function ForgotPage(usersProv, alertCtrl, formBuilder) {
        this.usersProv = usersProv;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.resetPasswordForm = formBuilder.group({
            email: ['', forms_1.Validators.compose([forms_1.Validators.required, email_1.EmailValidator.isValid])],
        });
    }
    ForgotPage.prototype.resetPassword = function () {
        var _this = this;
        if (!this.resetPasswordForm.valid) {
            console.log(this.resetPasswordForm.value);
        }
        else {
            this.usersProv.resetPassword(this.resetPasswordForm.value.email).then(function (user) {
                _this.presentAlertErr('Acabamos de mandar un link de reseteo de contraseña a tu correo!');
            }, function (error) {
                _this.presentAlertErr(error.message);
            });
        }
    };
    ForgotPage.prototype.presentAlertErr = function (err) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: err,
                            buttons: [{
                                    text: "Ok",
                                    role: 'cancelar'
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ForgotPage.prototype.ngOnInit = function () {
    };
    ForgotPage = __decorate([
        core_1.Component({
            selector: 'app-forgot',
            template: __webpack_require__(/*! ./forgot.page.html */ "./src/app/forgot/forgot.page.html"),
            styles: [__webpack_require__(/*! ./forgot.page.scss */ "./src/app/forgot/forgot.page.scss")]
        }),
        __metadata("design:paramtypes", [users_1.UsersProvider,
            angular_1.AlertController,
            forms_1.FormBuilder])
    ], ForgotPage);
    return ForgotPage;
}());
exports.ForgotPage = ForgotPage;


/***/ })

}]);
//# sourceMappingURL=forgot-forgot-module.js.map