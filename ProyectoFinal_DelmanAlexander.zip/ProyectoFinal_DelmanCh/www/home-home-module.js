(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var home_page_1 = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");
var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild([
                    {
                        path: '',
                        component: home_page_1.HomePage
                    }
                ])
            ],
            declarations: [home_page_1.HomePage]
        })
    ], HomePageModule);
    return HomePageModule;
}());
exports.HomePageModule = HomePageModule;


/***/ }),

/***/ "./src/app/home/home.page.html":
/*!*************************************!*\
  !*** ./src/app/home/home.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-header>\n  <ion-toolbar class=\"toolbar\" >\n    <ion-buttons slot=\"start\">\n      <ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-client\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" class=\"shadow-0 txt1\" [routerLink]=\"'/search'\" routerDirection=\"forward\">\n        <ion-icon class=\"mgb-5  txt-light\" name=\"search\"></ion-icon>\n      </ion-button>\n      <ion-button fill=\"clear\" class=\"mgb-5  txt-light\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n        <ion-icon name=\"cart\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title class=\"mgb-5 fs-13 txt-light\">Catalogo de productos</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n\n  <div class=\"wrap-top-slide\" *ngIf=\"list_product_slide\">\n    <ion-slides [options]=\"slidePerViewOpts\">\n      <ion-slide *ngFor=\"let item of list_product_slide\">\n        <div text-left class=\"item-slide\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n          <div class=\"thumb ovfl-hidden flex-row flex-jus-center flex-ali-center\">\n            <img src=\"{{item.payload.doc.data().thumb}}\">\n          </div>\n          <p class=\"pdl-15 pdr-15 ellipsis txt3 mgb-5 fs-14\">{{item.payload.doc.data().id_cat.name}}</p>\n          <h4 class=\"pdl-15 pdr-15 fw-500 fs-16 txt1 mgt-0 ellipsis\">{{item.payload.doc.data().name}}</h4>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n\n\n  <div padding class=\"wrap-news\" *ngIf=\"list_product_new\">\n    <h5 class=\"uppercase fs-16 fw-600 spacing-1 txt1\">Nuevo post</h5>\n    <ion-slides [options]=\"slidePerViewOpts2\">\n      <ion-slide *ngFor=\"let item of list_product_new\">\n        <div text-left class=\"item-slide\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n          <div class=\"thumb ovfl-hidden flex-row flex-jus-center flex-ali-center\">\n            <img src=\"{{item.payload.doc.data().thumb}}\">\n          </div>\n          <h4 class=\"fw-500 fs-14 txt1 mgb-0 ellipsis\">{{item.payload.doc.data().name}}</h4>\n          <p class=\"txt4 mgt-0 fs-11\">{{(item.payload.doc.data().created).substring(4, 15)}}</p>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n\n\n  <div padding class=\"\">\n    <h5 class=\"uppercase fs-16 fw-600 spacing-1 txt1 mgt-0\">Productos</h5>\n    <ion-row>\n      <ion-col size=\"6\" *ngFor=\"let item of list_product\">\n        <div class=\"item-prd mgb-30\">\n          <div class=\"thumb ovfl-hidden flex-row flex-jus-center flex-ali-center\">\n            <div class=\"discount fw-600 pdt-5 fs-12 shadow-3 white\" *ngIf=\"item.payload.doc.data().discount > 0\">\n              - {{item.payload.doc.data().discount}}%\n            </div>\n            <img src=\"{{item.payload.doc.data().thumb}}\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n            <ion-button size=\"small\" color=\"primary\" class=\"fs-11 bdra-0 favo-btn\" *ngIf=\"favo_str.search(item.payload.doc.id) > -1\" (click)=\"favorites(item)\">\n              <ion-icon name=\"ios-heart\"></ion-icon>\n            </ion-button>\n            <ion-button size=\"small\" color=\"dark\" class=\"fs-11 bdra-0 favo-btn\" *ngIf=\"favo_str.search(item.payload.doc.id) < 0\" (click)=\"favorites(item)\">\n              <ion-icon name=\"ios-heart\"></ion-icon>\n            </ion-button>\n          </div>\n\n          <div class=\"ovfl-hidden\" [routerLink]=\"['/detail', {id_item: item.payload.doc.id}]\">\n            <h4 class=\"fs-16 fw-600 ellipsis mgb-0 mgt-10\">{{item.payload.doc.data().name}}</h4>\n            <p class=\"mgt-5 mgb-0\">\n              <span class=\"ellipsis fs-14 txt3 mg-0 line-through mgr-10 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n                <i *ngIf=\"currenciesProv\">{{(item.payload.doc.data().price)}} Lps</i>\n              </span>\n              <span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount > 0\">\n                {{(item.payload.doc.data().price - item.payload.doc.data().price*item.payload.doc.data().discount/100)}} Lps\n              </span>\n              <span class=\"ellipsis fs-14 txt1 mg-0 fw-600\" *ngIf=\"currenciesProv && item.payload.doc.data().discount == 0\">\n                {{(item.payload.doc.data().price)}} Lps\n              </span>\n            </p>\n          </div>\n          <div class=\"mgt-10\">\n            <ion-button size=\"small\" color=\"dark\" (click)=\"addCart(item)\" class=\"uppercase fs-11 bdra-0 fw-600\">\n              <ion-icon slot=\"start\" name=\"ios-cart\"></ion-icon>\n              Agregar al carrito\n            </ion-button>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n  </div>\n\n  <br>\n  \n\n  <ion-infinite-scroll (ionInfinite)=\"loadMore($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading\"></ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n.can-go-back ion-menu-button {\n  display: block !important; }\n\n.wrap-top-slide {\n  width: 170%; }\n\n.wrap-top-slide .thumb {\n    height: 150px; }\n\n.wrap-top-slide .thumb img {\n      min-height: 100%;\n      width: 100%; }\n\n.wrap-news {\n  width: 120%; }\n\n.wrap-news .thumb {\n    height: 80px; }\n\n.wrap-news .thumb img {\n      height: 100%;\n      min-width: 100%; }\n\n.item-prd .thumb {\n  position: relative;\n  height: 150px; }\n\n.item-prd .thumb img {\n    height: 100%;\n    min-width: 100%; }\n\n.item-prd .thumb .discount {\n    z-index: 100;\n    position: absolute;\n    top: 10px;\n    left: 0px;\n    height: 25px;\n    width: 80px;\n    overflow: hidden; }\n\n.item-prd .thumb .discount:before {\n      content: \"\";\n      background: var(--ion-background-color);\n      display: block;\n      height: 200%;\n      width: 180%;\n      margin-left: -100px;\n      transform: rotate(-15deg);\n      position: absolute;\n      z-index: -1; }\n\n.item-prd .thumb .favo-btn {\n    z-index: 10;\n    position: absolute;\n    right: 10px;\n    bottom: 5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcVXNlcnNcXGRjaGluY2hpbGxhXFxEZXNrdG9wXFxFbnRyZWdhYmxlXFxwcm95ZWN0b0RlbG1hbkNoaW5jaGlsbGEvc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsc0ZBQWEsRUFBQTs7QUFLZjtFQUVFLHlCQUF5QixFQUFBOztBQUkzQjtFQUNDLFdBQVcsRUFBQTs7QUFEWjtJQUdFLGFBQWEsRUFBQTs7QUFIZjtNQUtHLGdCQUFnQjtNQUNoQixXQUFXLEVBQUE7O0FBSWQ7RUFDQyxXQUFXLEVBQUE7O0FBRFo7SUFHRSxZQUFZLEVBQUE7O0FBSGQ7TUFLRyxZQUFZO01BQ1osZUFBZSxFQUFBOztBQUlsQjtFQUVFLGtCQUFrQjtFQUNsQixhQUFhLEVBQUE7O0FBSGY7SUFLRyxZQUFZO0lBQ1osZUFBZSxFQUFBOztBQU5sQjtJQVNHLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsU0FBUztJQUNULFNBQVM7SUFDVCxZQUFZO0lBQ1osV0FBVztJQUNYLGdCQUFnQixFQUFBOztBQWZuQjtNQWlCSSxXQUFXO01BQ1gsdUNBQXVDO01BQ3ZDLGNBQWM7TUFDZCxZQUFZO01BQ1osV0FBVztNQUNYLG1CQUFtQjtNQUNuQix5QkFBeUI7TUFDekIsa0JBQWtCO01BQ2xCLFdBQVcsRUFBQTs7QUF6QmY7SUE2QkcsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyIHtcbiAgIFxuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWlvbi1jb2xvci1kYXJrKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpKTtcbiAgICAgIFxufVxuXG5cbi5jYW4tZ28tYmFjayB7XG5cdGlvbi1tZW51LWJ1dHRvbiB7XG5cdFx0ZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcblx0fVxufVxuXG4ud3JhcC10b3Atc2xpZGV7XG5cdHdpZHRoOiAxNzAlO1xuXHQudGh1bWJ7XG5cdFx0aGVpZ2h0OiAxNTBweDtcblx0XHRpbWd7XG5cdFx0XHRtaW4taGVpZ2h0OiAxMDAlO1xuXHRcdFx0d2lkdGg6IDEwMCU7XG5cdFx0fVxuXHR9XG59XG4ud3JhcC1uZXdze1xuXHR3aWR0aDogMTIwJTtcblx0LnRodW1ie1xuXHRcdGhlaWdodDogODBweDtcblx0XHRpbWd7XG5cdFx0XHRoZWlnaHQ6IDEwMCU7XG5cdFx0XHRtaW4td2lkdGg6IDEwMCU7XG5cdFx0fVxuXHR9XG59XG4uaXRlbS1wcmR7XG5cdC50aHVtYntcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdFx0aGVpZ2h0OiAxNTBweDtcblx0XHRpbWd7XG5cdFx0XHRoZWlnaHQ6IDEwMCU7XG5cdFx0XHRtaW4td2lkdGg6IDEwMCU7XG5cdFx0fVxuXHRcdC5kaXNjb3VudHtcblx0XHRcdHotaW5kZXg6IDEwMDtcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHRcdHRvcDogMTBweDtcblx0XHRcdGxlZnQ6IDBweDtcblx0XHRcdGhlaWdodDogMjVweDtcblx0XHRcdHdpZHRoOiA4MHB4O1xuXHRcdFx0b3ZlcmZsb3c6IGhpZGRlbjtcblx0XHRcdCY6YmVmb3Jle1xuXHRcdFx0XHRjb250ZW50OiBcIlwiO1xuXHRcdFx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvcik7XG5cdFx0XHRcdGRpc3BsYXk6IGJsb2NrO1xuXHRcdFx0XHRoZWlnaHQ6IDIwMCU7XG5cdFx0XHRcdHdpZHRoOiAxODAlO1xuXHRcdFx0XHRtYXJnaW4tbGVmdDogLTEwMHB4O1xuXHRcdFx0XHR0cmFuc2Zvcm06IHJvdGF0ZSgtMTVkZWcpO1xuXHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdFx0XHRcdHotaW5kZXg6IC0xO1xuXHRcdFx0fVxuXHRcdH1cblx0XHQuZmF2by1idG57XG5cdFx0XHR6LWluZGV4OiAxMDtcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHRcdHJpZ2h0OiAxMHB4O1xuXHRcdFx0Ym90dG9tOiA1cHg7XG5cdFx0fVxuXHR9XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var products_1 = __webpack_require__(/*! ../../providers/products */ "./src/providers/products.ts");
var currencies_1 = __webpack_require__(/*! ../../providers/currencies */ "./src/providers/currencies.ts");
var favorites_1 = __webpack_require__(/*! ../../providers/favorites */ "./src/providers/favorites.ts");
var ngx_1 = __webpack_require__(/*! @ionic-native/admob-free/ngx */ "./node_modules/@ionic-native/admob-free/ngx/index.js");
var HomePage = /** @class */ (function () {
    function HomePage(events, toastCtrl, favoritesProv, storage, currenciesProv, loadingCtrl, productsProv, navCtrl, admobFree) {
        var _this = this;
        this.events = events;
        this.toastCtrl = toastCtrl;
        this.favoritesProv = favoritesProv;
        this.storage = storage;
        this.currenciesProv = currenciesProv;
        this.loadingCtrl = loadingCtrl;
        this.productsProv = productsProv;
        this.navCtrl = navCtrl;
        this.admobFree = admobFree;
        this.slidePerViewOpts = {
            speed: 1000,
            spaceBetween: 16,
            loop: true,
            autoplay: {
                delay: 3500,
            },
            slidesPerView: 2,
        };
        this.slidePerViewOpts2 = {
            speed: 1000,
            spaceBetween: 16,
            loop: true,
            autoplay: {
                delay: 3500,
            },
            slidesPerView: 4,
        };
        this.favo_str = '';
        this.presentLoading();
        // const bannerConfig: AdMobFreeBannerConfig = {
        // 	id: 'ca-app-pub-1610982520322923~2132734290',
        // 	isTesting: true,
        // 	autoShow: true
        // };
        // this.admobFree.banner.config(bannerConfig);
        // this.admobFree.banner.prepare().then(() => {
        // 	// banner Ad is ready
        // 	// if we set autoShow to false, then we will need to call the show method here
        // }).catch(e => console.log(e));
        this.events.subscribe('cart_list: change', function (lst) {
            _this.list_cart = lst;
        });
        this.events.subscribe('user: change', function (user) {
            if (user || user != null) {
                console.log(user);
                _this.id_user = user.id_auth;
                _this.favoritesProv.getByUserId(_this.id_user).then(function (data) {
                    if (data.length > 0) {
                        _this.favo_str = data[0].payload.doc.data().id_product;
                        _this.id_favo_str = data[0].payload.doc.id;
                        console.log(data);
                    }
                });
                _this.productsProv.getProduct(null, 4).then(function (data) {
                    _this.list_product = data;
                    _this.start = data[data.length - 1].payload.doc.data().name;
                    console.log(_this.list_product);
                }, function (error) {
                });
                _this.productsProv.getProductBySlide(6).then(function (data) {
                    _this.list_product_slide = data;
                    console.log(_this.list_product_slide);
                }, function (error) {
                });
                _this.productsProv.getProductByCreated(6).then(function (data) {
                    _this.loading.dismiss().then(function () {
                        _this.list_product_new = data;
                        console.log(_this.list_product_new);
                    });
                }, function (error) {
                });
            }
        });
    }
    HomePage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.storage.ready().then(function () {
            _this.storage.get('cart_list').then(function (val) {
                if (!val || val == null) {
                    _this.list_cart = new Array();
                }
                else {
                    _this.list_cart = val;
                }
                console.log(_this.list_cart);
            });
            _this.storage.get('user').then(function (val) {
                if (val || val != null) {
                    _this.id_user = val.id_auth;
                    console.log(val);
                    _this.favoritesProv.getByUserId(_this.id_user).then(function (data) {
                        if (data.length > 0) {
                            _this.favo_str = data[0].payload.doc.data().id_product;
                            _this.id_favo_str = data[0].payload.doc.id;
                            console.log(data);
                        }
                    });
                    _this.productsProv.getProduct(null, 4).then(function (data) {
                        _this.list_product = data;
                        _this.start = data[data.length - 1].payload.doc.data().name;
                        console.log(_this.list_product);
                    }, function (error) {
                    });
                    _this.productsProv.getProductBySlide(6).then(function (data) {
                        _this.list_product_slide = data;
                        console.log(_this.list_product_slide);
                    }, function (error) {
                    });
                    _this.productsProv.getProductByCreated(6).then(function (data) {
                        _this.loading.dismiss().then(function () {
                            _this.list_product_new = data;
                            console.log(_this.list_product_new);
                        });
                    }, function (error) {
                    });
                }
            });
        });
    };
    HomePage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    HomePage.prototype.loadMore = function (event) {
        var _this = this;
        this.productsProv.getProduct(this.start, 2).then(function (data) {
            _this.list_product = _this.list_product.concat(data);
            console.log(data);
            if (data.length > 0) {
                _this.start = data[data.length - 1].payload.doc.data().name;
            }
            console.log(_this.list_product);
            setTimeout(function () {
                event.target.disabled = true;
            }, 1500);
        });
    };
    HomePage.prototype.favorites = function (item) {
        var _this = this;
        console.log(item.payload.doc.id);
        var check = this.favo_str.indexOf(item.payload.doc.id);
        if (check == -1) {
            this.favo_str = this.favo_str + item.payload.doc.id + ' ';
        }
        else {
            this.favo_str = this.favo_str.replace(item.payload.doc.id + ' ', '');
        }
        this.favoritesProv.favoritesAdd(this.favo_str, this.id_user, this.id_favo_str).then(function (data) {
            if (!_this.id_favo_str || _this.id_favo_str == null) {
                _this.favoritesProv.getByUserId(_this.id_user).then(function (newFavo) {
                    _this.id_favo_str = newFavo[0].payload.doc.id;
                });
            }
        });
    };
    HomePage.prototype.addCart = function (item) {
        console.log(item);
        var itemCv = {
            id: item.payload.doc.id,
            name: item.payload.doc.data().name,
            price: item.payload.doc.data().price,
            discount: item.payload.doc.data().discount,
            description: item.payload.doc.data().description,
            vote: item.payload.doc.data().vote,
            created: item.payload.doc.data().created,
            id_cat: item.payload.doc.data().id_cat,
            tag: item.payload.doc.data().tag,
            thumb: item.payload.doc.data().thumb,
            thumb1: item.payload.doc.data().thumb1,
            thumb2: item.payload.doc.data().thumb2,
            thumb3: item.payload.doc.data().thumb3,
            thumb4: item.payload.doc.data().thumb4,
            quantity: 1
        };
        var temp = this.list_cart.filter(function (element) {
            if (element.id == itemCv.id) {
                element.quantity = 1 + element.quantity;
                return true;
            }
        });
        console.log(temp);
        if (temp.length == 0) {
            this.list_cart = this.list_cart.concat(itemCv);
        }
        this.presentToast();
        // this.list_cart = new Array();
        this.events.publish('cart_list: change', this.list_cart);
        this.storage.set('cart_list', this.list_cart);
        console.log(this.list_cart);
    };
    HomePage.prototype.presentToast = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Se agrego con exito',
                            duration: 2000,
                            position: 'bottom'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage = __decorate([
        core_1.Component({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.Events,
            angular_1.ToastController,
            favorites_1.FavoritesProvider,
            storage_1.Storage,
            currencies_1.CurrenciesProvider,
            angular_1.LoadingController,
            products_1.ProductsProvider,
            angular_1.NavController,
            ngx_1.AdMobFree])
    ], HomePage);
    return HomePage;
}());
exports.HomePage = HomePage;


/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map