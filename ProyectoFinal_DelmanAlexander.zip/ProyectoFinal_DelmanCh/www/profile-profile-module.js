(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"],{

/***/ "./src/app/profile/profile.module.ts":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var forms_2 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var profile_page_1 = __webpack_require__(/*! ./profile.page */ "./src/app/profile/profile.page.ts");
var routes = [
    {
        path: '',
        component: profile_page_1.ProfilePage
    }
];
var ProfilePageModule = /** @class */ (function () {
    function ProfilePageModule() {
    }
    ProfilePageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                forms_2.ReactiveFormsModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [profile_page_1.ProfilePage]
        })
    ], ProfilePageModule);
    return ProfilePageModule;
}());
exports.ProfilePageModule = ProfilePageModule;


/***/ }),

/***/ "./src/app/profile/profile.page.html":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon color=\"light\" name=\"ios-arrow-round-forward\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t<ion-title color=\"light\">Perfil</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n\t<div text-center class=\"top-profile\">\n\t\t<div text-right>\n\t\t\t<ion-button fill=\"clear\" class=\"fs-16\" (click)=\"logout()\">\n\t\t\t\t<ion-icon name=\"md-log-out\"></ion-icon>Cerrar sesion\n\t\t\t</ion-button>\n\t\t</div>\n\t\t<br>\n\t\t<br>\n\t\t<div class=\"thumb-avt flex-row flex-ali-center flex-jus-center\" *ngIf=\"user != null || user\">\n\t\t\t<img src=\"{{(user.avt != '' && user.avt != null)? user.avt : 'assets/imgs/no-avt.png' }}\">\n\t\t</div>\n\t\t<ion-button size=\"small\" (click)=\"pickImage()\" class=\"bdra-30 btn-edit mgt--15 mgl-50 shadow-3\">\n\t\t\t<ion-icon name=\"create\"></ion-icon>\n\t\t</ion-button>\n\t\t<h2 class=\"spacing-1 fs-20 fw-600\" *ngIf=\"user != null || user\">{{user.username}}</h2>\n\t</div>\n\n\t<br>\n\t<br>\n\t\n\t<form padding (ngSubmit)=\"updateAddress()\" [formGroup]=\"addressForm\" *ngIf=\"user || user != null\">\n\t\t<ion-label class=\"pdl-15 txt-b3\">Correo</ion-label>\n\t\t<ion-item>\n\t\t\t<ion-input disabled value={{user.email}} type=\"text\"></ion-input>\n\t\t</ion-item>\n\n\t\t<br>\n\n\t\t<ion-label class=\"pdl-15 txt-b3\">Nombre de usuario</ion-label>\n\t\t<ion-item>\n\t\t\t<ion-input formControlName=\"username\" type=\"text\"></ion-input>\n\t\t</ion-item>\n\n\t\t<br>\n\n\t\t<ion-label class=\"pdl-15 txt-b3\">Nombre completo</ion-label>\n\t\t<ion-item>\n\t\t\t<ion-input formControlName=\"fullname\" type=\"text\"></ion-input>\n\t\t</ion-item>\n\n\t\t<br>\n\n\t\t<ion-label class=\"pdl-15 txt-b3\">Lugar donde reside</ion-label>\n\t\t<ion-item>\n\t\t\t<ion-input formControlName=\"address\" type=\"text\"></ion-input>\n\t\t</ion-item>\n\n\t\t<br>\n\n\t\t<ion-label class=\"pdl-15 txt-b3\">Numero de telefono</ion-label>\n\t\t<ion-item>\n\t\t\t<ion-input formControlName=\"phone\" type=\"numbber\"></ion-input>\n\t\t</ion-item>\n\n\t\t<br>\n\t\t<br>\n\n\t\t<div class=\"\" text-center>\n\t\t\t<ion-button shape=\"round\" type=\"submit\" class=\"\">\n\t\t\t\tGuardar cambios \n\t\t\t</ion-button>\n\t\t</div>\n\n\t\t<br>\n\t\t<br>\n\t\t<br>\n\t</form>\n\n\n\t<div class=\"\" text-center>\n\t\t<ion-button fill=\"clear\" [routerLink]=\"'/forgot'\" class=\"\">\n\t\t\tResetear clave \n\t\t</ion-button>\n\t</div>\n\n\t<br>\n\t<br>\n\t<br>\n\t<br>\n\t<br>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/profile/profile.page.scss":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".thumb-avt {\n  z-index: 100;\n  margin: 0px auto;\n  border-radius: 50%;\n  height: 120px;\n  width: 120px;\n  overflow: hidden;\n  position: relative;\n  border: 3px solid var(--ion-color-light); }\n  .thumb-avt img {\n    height: 100%;\n    min-width: 100%;\n    max-width: auto; }\n  .btn-edit {\n  position: relative;\n  z-index: 110; }\n  .toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9DOlxcVXNlcnNcXGRjaGluY2hpbGxhXFxEZXNrdG9wXFxFbnRyZWdhYmxlXFxwcm95ZWN0b0RlbG1hbkNoaW5jaGlsbGEvc3JjXFxhcHBcXHByb2ZpbGVcXHByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0MsWUFBWTtFQUNaLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLHdDQUF3QyxFQUFBO0VBUnpDO0lBVUUsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlLEVBQUE7RUFJakI7RUFDQyxrQkFBa0I7RUFDbEIsWUFBWSxFQUFBO0VBR2I7RUFFSSxzRkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3AtcHJvZmlsZXtcblxufVxuLnRodW1iLWF2dHtcblx0ei1pbmRleDogMTAwO1xuXHRtYXJnaW46IDBweCBhdXRvO1xuXHRib3JkZXItcmFkaXVzOiA1MCU7XG5cdGhlaWdodDogMTIwcHg7XG5cdHdpZHRoOiAxMjBweDtcblx0b3ZlcmZsb3c6IGhpZGRlbjtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRib3JkZXI6IDNweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuXHRpbWd7XG5cdFx0aGVpZ2h0OiAxMDAlO1xuXHRcdG1pbi13aWR0aDogMTAwJTtcblx0XHRtYXgtd2lkdGg6IGF1dG87XG5cdH1cbn1cblxuLmJ0bi1lZGl0e1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdHotaW5kZXg6IDExMDtcbn1cblxuLnRvb2xiYXIge1xuICAgXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XG4gICAgICAgIFxuICB9Il19 */"

/***/ }),

/***/ "./src/app/profile/profile.page.ts":
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var users_1 = __webpack_require__(/*! ../../providers/users */ "./src/providers/users.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var firebase = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
var ngx_2 = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
var ProfilePage = /** @class */ (function () {
    function ProfilePage(menuCtrl, events, alertCtrl, storage, loadingCtrl, usersProv, formBuilder, router, camera, file, 
    // public filePath: FilePath,
    // public transfer: FileTransfer,
    platform) {
        this.menuCtrl = menuCtrl;
        this.events = events;
        this.alertCtrl = alertCtrl;
        this.storage = storage;
        this.loadingCtrl = loadingCtrl;
        this.usersProv = usersProv;
        this.formBuilder = formBuilder;
        this.router = router;
        this.camera = camera;
        this.file = file;
        this.platform = platform;
    }
    ProfilePage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.storage.ready().then(function () {
            _this.storage.get('user').then(function (val) {
                console.log(val);
                _this.user = val;
                _this.addressForm = _this.formBuilder.group({
                    username: [val.username],
                    fullname: [val.fullname],
                    address: [val.address],
                    phone: [val.phone]
                });
            });
        });
    };
    // =============== up avt =======================
    ProfilePage.prototype.pickImage = function () {
        return __awaiter(this, void 0, void 0, function () {
            var options, cameraInfo, blobInfo, uploadInfo, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        options = {
                            quality: 80,
                            destinationType: this.camera.DestinationType.FILE_URI,
                            encodingType: this.camera.EncodingType.JPEG,
                            mediaType: this.camera.MediaType.PICTURE
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 5, , 6]);
                        return [4 /*yield*/, this.camera.getPicture(options)];
                    case 2:
                        cameraInfo = _a.sent();
                        return [4 /*yield*/, this.makeFileIntoBlob(cameraInfo)];
                    case 3:
                        blobInfo = _a.sent();
                        return [4 /*yield*/, this.uploadToFirebase(blobInfo)];
                    case 4:
                        uploadInfo = _a.sent();
                        alert("File Upload Success " + uploadInfo.fileName);
                        return [3 /*break*/, 6];
                    case 5:
                        e_1 = _a.sent();
                        console.log(e_1.message);
                        alert("File Upload Error " + e_1.message);
                        return [3 /*break*/, 6];
                    case 6: return [2 /*return*/];
                }
            });
        });
    };
    // -------------------
    ProfilePage.prototype.makeFileIntoBlob = function (_imagePath) {
        var _this = this;
        // INSTALL PLUGIN - cordova plugin add cordova-plugin-file
        return new Promise(function (resolve, reject) {
            var fileName = "";
            _this.file
                .resolveLocalFilesystemUrl(_imagePath)
                .then(function (fileEntry) {
                var name = fileEntry.name, nativeURL = fileEntry.nativeURL;
                // get the path..
                var path = nativeURL.substring(0, nativeURL.lastIndexOf("/"));
                console.log("path", path);
                console.log("fileName", name);
                fileName = name;
                // we are provided the name, so now read the file into
                // a buffer
                return _this.file.readAsArrayBuffer(path, name);
            })
                .then(function (buffer) {
                // get the buffer and make a blob to be saved
                var imgBlob = new Blob([buffer], {
                    type: "image/jpeg"
                });
                console.log(imgBlob.type, imgBlob.size);
                resolve({
                    fileName: fileName,
                    imgBlob: imgBlob
                });
            })
                .catch(function (e) { return reject(e); });
        });
    };
    // ------------------------
    ProfilePage.prototype.uploadToFirebase = function (_imageBlobInfo) {
        console.log("uploadToFirebase");
        return new Promise(function (resolve, reject) {
            var fileRef = firebase.storage().ref("users/" + _imageBlobInfo.fileName);
            var uploadTask = fileRef.put(_imageBlobInfo.imgBlob);
            uploadTask.on("state_changed", function (_snapshot) {
                console.log("snapshot progess " +
                    (_snapshot.bytesTransferred / _snapshot.totalBytes) * 100);
            }, function (_error) {
                console.log(_error);
                reject(_error);
            }, function () {
                // completion...
                resolve(uploadTask.snapshot);
            });
        });
    };
    // =============== end up avt =======================
    ProfilePage.prototype.updateAddress = function () {
        var _this = this;
        this.usersProv.updateUser(this.user.id, this.addressForm.value).then(function (data) {
            _this.loading.dismiss().then(function () {
                console.log(data);
                _this.user.username = _this.addressForm.value.username;
                _this.user.fullname = _this.addressForm.value.fullname;
                _this.user.address = _this.addressForm.value.address;
                _this.user.phone = _this.addressForm.value.phone;
                _this.storage.set('user', _this.user);
                _this.events.publish('user: change', _this.user);
            });
        }, function (error) {
            _this.loading.dismiss().then(function () {
                _this.presentAlertErr(error);
            });
        });
        this.presentLoading();
    };
    ProfilePage.prototype.logout = function () {
        var _this = this;
        this.usersProv.logoutUser().then(function () {
            _this.storage.remove('user');
            _this.user = null;
            _this.router.navigateByUrl('/login');
            _this.menuCtrl.enable(false);
        });
    };
    ProfilePage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    ProfilePage.prototype.presentAlertErr = function (err) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: err.message,
                            buttons: [{
                                    text: "Ok",
                                    role: 'cancel'
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilePage.prototype.ngOnInit = function () {
    };
    ProfilePage = __decorate([
        core_1.Component({
            selector: 'app-profile',
            template: __webpack_require__(/*! ./profile.page.html */ "./src/app/profile/profile.page.html"),
            styles: [__webpack_require__(/*! ./profile.page.scss */ "./src/app/profile/profile.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.MenuController,
            angular_1.Events,
            angular_1.AlertController,
            storage_1.Storage,
            angular_1.LoadingController,
            users_1.UsersProvider,
            forms_1.FormBuilder,
            router_1.Router,
            ngx_1.Camera,
            ngx_2.File,
            angular_1.Platform])
    ], ProfilePage);
    return ProfilePage;
}());
exports.ProfilePage = ProfilePage;


/***/ })

}]);
//# sourceMappingURL=profile-profile-module.js.map