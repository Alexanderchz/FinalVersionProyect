(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var forms_2 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var login_page_1 = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");
var routes = [
    {
        path: '',
        component: login_page_1.LoginPage
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = __decorate([
        core_1.NgModule({
            imports: [
                angular_1.IonicModule,
                common_1.CommonModule,
                forms_1.FormsModule,
                forms_2.ReactiveFormsModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [login_page_1.LoginPage]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());
exports.LoginPageModule = LoginPageModule;


 }),
 "./src/app/login/login.page.html":

 (function(module, exports) {

module.exports = "\n\n<ion-content>\n\t<div class=\"pst-wrap-form pdl-30 pdr-30\">\n\t\t<div class=\"wrapper-form pdl-30 pdr-30\">\n\t\t\t<div class=\"mgt-30 mgb-20\">\n\t\t\t\t<br>\n\t\t\t\t<!-- <h1 class=\"uppercase txt-light fw-900 spacing3 fs-30 spacing-3 mgb-0\">Apparel</h1> -->\n\t\t\t\t<img class=\"brand-logo\" src=\"assets/imgs/knitting.png\">\n\t\t\t\t<h3 class=\"uppercase txt-light fw-600 fs-20 spacing-2 mgl-20 pdt-0\">Apparel Designer</h3>\n\t\t\t\t<p class=\"pdl-20 fs-12 txt-warning\">Si puedes imaginarlo puedes diseñarlo</p>\n\t\t\t</div>\n\t\t\t<div text-right class=\"mgr--10\">\n\t\t\t\t<ion-button size=\"small\" fill=\"clear\" shape=\"round\" (click)=\"login_fb()\" class=\"txt-light fs-16 capitalize\">\n\t\t\t\t\tUnete\n\t\t\t\t\t<ion-icon slot=\"end\" name=\"logo-facebook\"></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t</div>\n\n\t\t\t<br>\n\n\t\t\t<form [formGroup]=\"loginForm\" (submit)=\"loginUser()\" novalidate>\n\t\t\t\t<ion-label stacked class=\"mgb-5 fs-13 txt-light\">Correo</ion-label>\n\t\t\t\t<ion-list class=\"ani-bottom-to-top mgb-0 mgt-5\">\n\t\t\t\t\t<ion-item class=\"white-opct bdra-30\">\n\t\t\t\t\t\t<ion-input #email formControlName=\"email\" type=\"email\" placeholder=\"Ingresa tu correo electronico\" [class.invalid]=\"!loginForm.controls.email.valid && loginForm.controls.email.dirty\" class=\"\"></ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t</ion-list>\n\t\t\t\t\n\t\t\t\t<div class=\"error-message\" *ngIf=\"!loginForm.controls.email.valid  && loginForm.controls.email.dirty\">\n\t\t\t\t\t<p class=\"fs-11 mgt-5 txt-warning\">Porfavor ingresa un correo valido</p>\n\t\t\t\t</div>\n\n\t\t\t\t<br>\n\t\t\t\t\n\t\t\t\t<ion-label stacked class=\"mgb-5 fs-13 txt-light\">Contraseña</ion-label>\n\t\t\t\t<ion-list class=\"ani-bottom-to-top mgb-0 mgt-5\">\n\t\t\t\t\t<ion-item class=\"white-opct bdra-30\">\n\t\t\t\t\t\t<ion-input #password formControlName=\"password\" type=\"password\" placeholder=\"Ingresa tu contraseña\" \n\t\t\t\t\t\t[class.invalid]=\"!loginForm.controls.password.valid && loginForm.controls.password.dirty\" class=\"\"></ion-input>\n\t\t\t\t\t</ion-item>\n\t\t\t\t</ion-list>\n\n\t\t\t\t<div class=\"error-message\" *ngIf=\"!loginForm.controls.password.valid && loginForm.controls.password.dirty\">\n\t\t\t\t\t<p class=\"fs-11 mgt-5 mgb-0 txt-warning\">Tu contraseña debe ser almenos de 6 caracteres</p>\n\t\t\t\t</div>\n\n\t\t\t\t<div text-right class=\"mgb-10 ovfl-auto\">\n\t\t\t\t\t<ion-button fill=\"clear\" size=\"small\" class=\"capitalize txt-light fs-12 txt3 pull-right pdr-0 fw-300\" [routerLink]=\"'/forgot'\">\n\t\t\t\t\t\tolvide mi contraseña\n\t\t\t\t\t</ion-button>\n\t\t\t\t</div>\n\n\t\t\t\t<ion-button expand=\"block\" shape=\"round\" color=\"primary\" class=\"mgt-30 uppercase fw-600 spacing1 ani-bottom-to-top shadow-0\" type=\"submit\">\n\t\t\t\t\tIngresar\n\t\t\t\t</ion-button>\n\n\t\t\t\t<br>\n\n\t\t\t\t<div class=\"text-center\">\n\t\t\t\t\t<ion-button fill=\"clear\" expand=\"block\" text-center size=\"small\" class=\"fs-12 txt-light capitalize fw-300 mgt-0\" [routerLink]=\"'/signup'\">\n\t\t\t\t\t\tAun no formas parte?, registrate!\n\t\t\t\t\t</ion-button>\n\t\t\t\t</div>\n\n\t\t\t\t<br>\n\n\t\t\t</form>\n\t\t</div>\n\t</div>\n\n</ion-content>\n"

 }),

 "./src/app/login/login.page.scss":

 (function(module, exports) {

module.exports = ":host ion-content {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n.pst-wrap-form {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-height: 100%;\n  position: relative;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.4); }\n\n.brand-logo {\n  width: 100px;\n  height: 100px;\n  margin: 8px auto 8px;\n  background-size: 50%;\n  margin-left: 30%; }\n\n.img-bg {\n  position: fixed;\n  z-index: 10;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0; }\n\n.img-bg img {\n    height: 100%;\n    min-width: auto;\n    max-width: unset; }\n\nion-list {\n  background: transparent; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vQzpcXFVzZXJzXFxkY2hpbmNoaWxsYVxcRGVza3RvcFxcRW50cmVnYWJsZVxccHJveWVjdG9EZWxtYW5DaGluY2hpbGxhL3NyY1xcYXBwXFxsb2dpblxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRVEsc0ZBQWEsRUFBQTs7QUFJckI7RUFDQyxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHVCQUF1QjtFQUN2QixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLFlBQVk7RUFDWiw4QkFBMkIsRUFBQTs7QUFFNUI7RUFFUSxZQUFZO0VBQ1osYUFBYTtFQUNiLG9CQUFvQjtFQUNwQixvQkFBb0I7RUFDckIsZ0JBQWdCLEVBQUE7O0FBR3ZCO0VBQ0MsZUFBZTtFQUNmLFdBQVc7RUFDWCxNQUFNO0VBQ04sU0FBUztFQUNULE9BQU87RUFDUCxRQUFRLEVBQUE7O0FBTlQ7SUFRRSxZQUFZO0lBQ1osZUFBZTtJQUNmLGdCQUFnQixFQUFBOztBQUlsQjtFQUNDLHVCQUF1QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICAgIGlvbi1jb250ZW50IHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XG4gICAgfVxufVxuXG4ucHN0LXdyYXAtZm9ybXtcblx0ZGlzcGxheTogZmxleDtcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcblx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5cdG1pbi1oZWlnaHQ6IDEwMCU7XG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0ei1pbmRleDogMTAwO1xuXHRiYWNrZ3JvdW5kOiByZ2JhKDAsMCwwLDAuNCk7XG59XG4uYnJhbmQtbG9nb3tcblxuICAgICAgICB3aWR0aDogMTAwcHg7XG4gICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgIG1hcmdpbjogOHB4IGF1dG8gOHB4O1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDUwJTtcbiAgICAgICBtYXJnaW4tbGVmdDogMzAlO1xuICAgICAgICBcbn1cbi5pbWctYmd7XG5cdHBvc2l0aW9uOiBmaXhlZDtcblx0ei1pbmRleDogMTA7XG5cdHRvcDogMDtcblx0Ym90dG9tOiAwO1xuXHRsZWZ0OiAwO1xuXHRyaWdodDogMDtcblx0aW1ne1xuXHRcdGhlaWdodDogMTAwJTtcblx0XHRtaW4td2lkdGg6IGF1dG87XG5cdFx0bWF4LXdpZHRoOiB1bnNldDtcblx0fVxufVxuXG5pb24tbGlzdHtcblx0YmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59Il19 */"

 }),

 "./src/app/login/login.page.ts":

 (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var email_1 = __webpack_require__(/*! ../../validators/email */ "./src/validators/email.ts");
var users_1 = __webpack_require__(/*! ../../providers/users */ "./src/providers/users.ts");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
var LoginPage = /** @class */ (function () {
    function LoginPage(events, storage, loadingCtrl, usersProv, alertCtrl, formBuilder, router, fb) {
        this.events = events;
        this.storage = storage;
        this.loadingCtrl = loadingCtrl;
        this.usersProv = usersProv;
        this.alertCtrl = alertCtrl;
        this.formBuilder = formBuilder;
        this.router = router;
        this.fb = fb;
        this.loginForm = formBuilder.group({
            email: ['', forms_1.Validators.compose([forms_1.Validators.required, email_1.EmailValidator.isValid])],
            password: ['', forms_1.Validators.compose([forms_1.Validators.minLength(6), forms_1.Validators.required])]
        });
    }
    LoginPage.prototype.presentAlert = function () {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: 'Alert',
                            subHeader: 'Subtitle',
                            message: 'This is an alert message.',
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentAlertErr = function () {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: 'Usuario o contraseña incorrecta!',
                            buttons: [{
                                    text: "Ok",
                                    role: 'cancel'
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentLoading = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingCtrl.create({
                                message: 'Cargando',
                                duration: 2000
                            })];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2: return [2 /*return*/, _b.sent()];
                }
            });
        });
    };
    LoginPage.prototype.loginUser = function () {
        var _this = this;
        if (!this.loginForm.valid) {
            console.log(this.loginForm.value);
        }
        else {
            this.usersProv.loginUser(this.loginForm.value.email, this.loginForm.value.password).then(function (authData) {
                console.log(authData);
                _this.usersProv.getUser(authData.user.uid).then(function (data) {
                    var user = {
                        avt: data[0].payload.doc.data().avt,
                        username: data[0].payload.doc.data().username,
                        fullname: data[0].payload.doc.data().fullname,
                        email: data[0].payload.doc.data().email,
                        address: data[0].payload.doc.data().address,
                        phone: data[0].payload.doc.data().phone,
                        id: data[0].payload.doc.id,
                        id_auth: data[0].payload.doc.data().id_auth
                    };
                    console.log(user);
                    _this.storage.set('user', user).then(function () {
                        _this.loading.dismiss().then(function () {
                            _this.events.publish('user: change', user);
                            _this.router.navigateByUrl('home-client');
                        });
                    });
                });
            }, function (error) {
                _this.loading.dismiss().then(function () {
                    _this.presentAlertErr();
                });
            });
            this.presentLoading();
        }
    };
    LoginPage.prototype.login_fb = function () {
        var _this = this;
        this.usersProv.facebookLogin().then(function (authData) {
            console.log(authData);
            _this.usersProv.getUser(authData.uid).then(function (data) {
                var user = {
                    avt: data[0].payload.doc.data().avt,
                    username: data[0].payload.doc.data().username,
                    fullname: data[0].payload.doc.data().fullname,
                    email: data[0].payload.doc.data().email,
                    address: data[0].payload.doc.data().address,
                    phone: data[0].payload.doc.data().phone,
                    id: data[0].payload.doc.id,
                    id_auth: data[0].payload.doc.data().id_auth
                };
                _this.storage.set('user', user).then(function () {
                    _this.loading.dismiss().then(function () {
                        _this.events.publish('user: change', user);
                        _this.router.navigateByUrl('home');
                    });
                });
            });
        }, function (error) {
            _this.loading.dismiss().then(function () {
                _this.presentAlertErr();
            });
        });
        this.presentLoading();
    };
    LoginPage.prototype.ngOnInit = function () {
    };
    LoginPage = __decorate([
        core_1.Component({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.Events,
            storage_1.Storage,
            angular_1.LoadingController,
            users_1.UsersProvider,
            angular_1.AlertController,
            forms_1.FormBuilder,
            router_1.Router,
            ngx_1.Facebook])
    ], LoginPage);
    return LoginPage;
}());
exports.LoginPage = LoginPage;


/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map