(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["categories-categories-module"],{

/***/ "./src/app/categories/categories.module.ts":
/*!*************************************************!*\
  !*** ./src/app/categories/categories.module.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var categories_page_1 = __webpack_require__(/*! ./categories.page */ "./src/app/categories/categories.page.ts");
var routes = [
    {
        path: '',
        component: categories_page_1.CategoriesPage
    }
];
var CategoriesPageModule = /** @class */ (function () {
    function CategoriesPageModule() {
    }
    CategoriesPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [categories_page_1.CategoriesPage]
        })
    ], CategoriesPageModule);
    return CategoriesPageModule;
}());
exports.CategoriesPageModule = CategoriesPageModule;


/***/ }),

/***/ "./src/app/categories/categories.page.html":
/*!*************************************************!*\
  !*** ./src/app/categories/categories.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar color=\"ion-color-primary-rgb\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button class=\"fs-24 txt1\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t<ion-menu-button>\n\t\t\t\t<ion-icon class=\"fs-24 txt1\" name=\"menu\"></ion-icon>\n\t\t\t</ion-menu-button>\n\t\t</ion-buttons>\n\n\t\t   <ion-buttons slot=\"end\">\n     \n      <ion-button fill=\"clear\" class=\"shadow-0 txt1\" [routerLink]=\"'/mycart'\" routerDirection=\"forward\">\n        <ion-icon name=\"cart\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n\t\t<ion-title style=\"color:white;\">Categories</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n\n\n<ion-searchbar (ionInput)=\"searchItem($event)\" placeholder=\"Search category here...\">\n    </ion-searchbar>\n\n\t <div class=\"movies-flex\" *ngIf=\"categoryList\">\n    <div class=\"movie\" *ngFor=\"let cats of categoryList\" [routerLink]=\"['/products', {id: id, title: title , owner_id: owner_id , cat_id: cats.id}]\">\n      <div class=\"poster\">\n       \n\t\t<img  class=\"poster-effect\" [src]=\"cats.image\">\n      </div>\n      <div class=\"title\">{{cats.title }}</div>\n      <div class=\"year\"><ion-icon name=\"star\"></ion-icon>{{ cats.title}}</div>\n      \n    </div>\n  </div>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/categories/categories.page.scss":
/*!*************************************************!*\
  !*** ./src/app/categories/categories.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header ion-icon {\n  font-size: 24px; }\n\nion-toolbar .tabs {\n  display: flex;\n  justify-content: center; }\n\nion-toolbar .tabs .tab {\n    text-align: center;\n    width: calc(100% / 3);\n    color: #8c8c8c; }\n\nion-toolbar .tabs .tab.active {\n      color: #488aff; }\n\nion-toolbar .tabs .tab ion-icon {\n      font-size: 30px; }\n\nion-toolbar .tabs .tab .label {\n      font-size: 10px;\n      margin-top: -2px; }\n\nh1 {\n  font-weight: 800;\n  letter-spacing: -0.03em;\n  font-size: 32px;\n  line-height: 32px;\n  margin: 8px 0 16px 16px; }\n\n.movies-flex {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: space-around; }\n\n.movies-flex .movie {\n    flex: 0 170px;\n    padding: 15px 8px;\n    display: flex;\n    flex-wrap: wrap;\n    justify-content: flex-start;\n    align-items: flex-start;\n    align-content: flex-start;\n    cursor: pointer; }\n\n.movies-flex .movie div.poster {\n      position: relative;\n      width: 100%;\n      height: 230px;\n      background: #eee;\n      border-radius: 6px; }\n\n.movies-flex .movie div.poster img.poster, .movies-flex .movie div.poster img.poster-effect {\n        width: 100%;\n        height: 230px;\n        -o-object-fit: cover;\n           object-fit: cover;\n        border-radius: 6px;\n        z-index: 9999;\n        position: relative;\n        margin-bottom: -215px;\n        -webkit-transform: translateZ(0);\n        -webkit-perspective: 1000;\n        -webkit-backface-visibility: hidden; }\n\n.movies-flex .movie div.poster img.poster.poster-effect, .movies-flex .movie div.poster img.poster-effect.poster-effect {\n          z-index: 999;\n          transform: scale(0.95) translateZ(0); }\n\n.movies-flex .movie .title {\n      width: 100%;\n      font-weight: 800;\n      letter-spacing: -0.05em;\n      font-size: 15px;\n      line-height: 15px;\n      padding: 20px 0 5px 0; }\n\n.movies-flex .movie .year {\n      width: 50%;\n      color: #aaa;\n      font-size: 12px; }\n\n.movies-flex .movie .vote {\n      width: 50%;\n      text-align: right;\n      color: #aaa;\n      font-size: 12px; }\n\n.movies-flex .movie .vote b {\n        font-weight: 800;\n        color: #000; }\n\n.movies-flex .movie .vote ion-icon {\n        color: #fbcd00;\n        line-height: 0px;\n        position: absolute;\n        margin: 1px 0 0 -14px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2F0ZWdvcmllcy9DOlxcVXNlcnNcXGRjaGluY2hpbGxhXFxEZXNrdG9wXFxFbnRyZWdhYmxlXFxwcm95ZWN0b0RlbG1hbkNoaW5jaGlsbGEvc3JjXFxhcHBcXGNhdGVnb3JpZXNcXGNhdGVnb3JpZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBZSxFQUFBOztBQUVqQjtFQUNFLGFBQWE7RUFDYix1QkFBdUIsRUFBQTs7QUFGekI7SUFJSSxrQkFBa0I7SUFDbEIscUJBQXFCO0lBQ3JCLGNBQWMsRUFBQTs7QUFObEI7TUFRTSxjQUFjLEVBQUE7O0FBUnBCO01BV00sZUFBZSxFQUFBOztBQVhyQjtNQWNNLGVBQWU7TUFDZixnQkFBZ0IsRUFBQTs7QUFJdEI7RUFDRSxnQkFBZ0I7RUFDaEIsdUJBQXVCO0VBQ3ZCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsdUJBQXVCLEVBQUE7O0FBRXpCO0VBQ0UsYUFBYTtFQUNiLGVBQWU7RUFDZiw2QkFBNkIsRUFBQTs7QUFIL0I7SUFLSSxhQUFhO0lBQ2IsaUJBQWlCO0lBQ2pCLGFBQWE7SUFDYixlQUFlO0lBQ2YsMkJBQTJCO0lBQzNCLHVCQUF1QjtJQUN2Qix5QkFBeUI7SUFDekIsZUFBZSxFQUFBOztBQVpuQjtNQWNNLGtCQUFrQjtNQUNsQixXQUFXO01BQ1gsYUFBYTtNQUNiLGdCQUFnQjtNQUNoQixrQkFBa0IsRUFBQTs7QUFsQnhCO1FBb0JRLFdBQVc7UUFDWCxhQUFhO1FBQ2Isb0JBQWlCO1dBQWpCLGlCQUFpQjtRQUNqQixrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLGtCQUFrQjtRQUNsQixxQkFBcUI7UUFDckIsZ0NBQWdDO1FBQ2hDLHlCQUF5QjtRQUN6QixtQ0FBbUMsRUFBQTs7QUE3QjNDO1VBK0JVLFlBQVk7VUFFWixvQ0FBb0MsRUFBQTs7QUFqQzlDO01BdUNNLFdBQVc7TUFDWCxnQkFBZ0I7TUFDaEIsdUJBQXVCO01BQ3ZCLGVBQWU7TUFDZixpQkFBaUI7TUFDakIscUJBQXFCLEVBQUE7O0FBNUMzQjtNQStDTSxVQUFVO01BQ1YsV0FBVztNQUNYLGVBQWUsRUFBQTs7QUFqRHJCO01Bb0RNLFVBQVU7TUFDVixpQkFBaUI7TUFDakIsV0FBVztNQUNYLGVBQWUsRUFBQTs7QUF2RHJCO1FBeURRLGdCQUFnQjtRQUNoQixXQUFXLEVBQUE7O0FBMURuQjtRQTZEUSxjQUFjO1FBQ2QsZ0JBQWdCO1FBQ2hCLGtCQUFrQjtRQUNsQixxQkFBcUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NhdGVnb3JpZXMvY2F0ZWdvcmllcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIGlvbi1pY29uIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbn1cclxuaW9uLXRvb2xiYXIgLnRhYnMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgLnRhYiB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB3aWR0aDogY2FsYygxMDAlIC8gMyk7XHJcbiAgICBjb2xvcjogIzhjOGM4YztcclxuICAgICYuYWN0aXZlIHtcclxuICAgICAgY29sb3I6ICM0ODhhZmY7XHJcbiAgICB9XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIH1cclxuICAgIC5sYWJlbCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgbWFyZ2luLXRvcDogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaDEge1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgbGV0dGVyLXNwYWNpbmc6IC0wLjAzZW07XHJcbiAgZm9udC1zaXplOiAzMnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xyXG4gIG1hcmdpbjogOHB4IDAgMTZweCAxNnB4O1xyXG59XHJcbi5tb3ZpZXMtZmxleCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgLm1vdmllIHtcclxuICAgIGZsZXg6IDAgMTcwcHg7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDhweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBkaXYucG9zdGVyIHtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgaGVpZ2h0OiAyMzBweDtcclxuICAgICAgYmFja2dyb3VuZDogI2VlZTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgICBpbWcucG9zdGVyLCBpbWcucG9zdGVyLWVmZmVjdCB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAyMzBweDtcclxuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgICAgei1pbmRleDogOTk5OTtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogLTIxNXB4O1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVaKDApO1xyXG4gICAgICAgIC13ZWJraXQtcGVyc3BlY3RpdmU6IDEwMDA7XHJcbiAgICAgICAgLXdlYmtpdC1iYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAgICAgJi5wb3N0ZXItZWZmZWN0IHtcclxuICAgICAgICAgIHotaW5kZXg6IDk5OTtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjk1KSB0cmFuc2xhdGVaKDApO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAudGl0bGUge1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICAgICAgbGV0dGVyLXNwYWNpbmc6IC0wLjA1ZW07XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDE1cHg7XHJcbiAgICAgIHBhZGRpbmc6IDIwcHggMCA1cHggMDtcclxuICAgIH1cclxuICAgIC55ZWFyIHtcclxuICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgY29sb3I6ICNhYWE7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIH1cclxuICAgIC52b3RlIHtcclxuICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgIGNvbG9yOiAjYWFhO1xyXG4gICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgIGIge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICAgICAgY29sb3I6ICMwMDA7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIGNvbG9yOiAjZmJjZDAwO1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAwcHg7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIG1hcmdpbjogMXB4IDAgMCAtMTRweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/categories/categories.page.ts":
/*!***********************************************!*\
  !*** ./src/app/categories/categories.page.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var CategoriesPage = /** @class */ (function () {
    function CategoriesPage(loadingCtrl, events, toastCtrl) {
        this.loadingCtrl = loadingCtrl;
        this.events = events;
        this.toastCtrl = toastCtrl;
        this.params = {};
    }
    CategoriesPage = __decorate([
        core_1.Component({
            selector: 'app-categories',
            template: __webpack_require__(/*! ./categories.page.html */ "./src/app/categories/categories.page.html"),
            styles: [__webpack_require__(/*! ./categories.page.scss */ "./src/app/categories/categories.page.scss")]
        }),
        __metadata("design:paramtypes", [angular_1.LoadingController,
            angular_1.Events,
            angular_1.ToastController])
    ], CategoriesPage);
    return CategoriesPage;
}());
exports.CategoriesPage = CategoriesPage;


/***/ })

}]);
//# sourceMappingURL=categories-categories-module.js.map