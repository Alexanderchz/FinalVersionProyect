(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0l1xih4f.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0l1xih4f.entry.js",
		"common",
		57
	],
	"./0l1xih4f.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0l1xih4f.sc.entry.js",
		"common",
		58
	],
	"./2vnnvwad.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2vnnvwad.entry.js",
		"common",
		9
	],
	"./2vnnvwad.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2vnnvwad.sc.entry.js",
		"common",
		10
	],
	"./4j0bvo7f.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4j0bvo7f.entry.js",
		"common",
		113
	],
	"./4j0bvo7f.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4j0bvo7f.sc.entry.js",
		"common",
		114
	],
	"./5c6i2c9u.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5c6i2c9u.entry.js",
		"common",
		59
	],
	"./5c6i2c9u.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5c6i2c9u.sc.entry.js",
		"common",
		60
	],
	"./5dcephfe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5dcephfe.entry.js",
		"common",
		11
	],
	"./5dcephfe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5dcephfe.sc.entry.js",
		"common",
		12
	],
	"./5wsmecfc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5wsmecfc.entry.js",
		0,
		"common",
		131
	],
	"./5wsmecfc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5wsmecfc.sc.entry.js",
		0,
		"common",
		132
	],
	"./6zvyjie1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zvyjie1.entry.js",
		0,
		"common",
		133
	],
	"./6zvyjie1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zvyjie1.sc.entry.js",
		0,
		"common",
		134
	],
	"./6zze4vuo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zze4vuo.entry.js",
		"common",
		13
	],
	"./6zze4vuo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zze4vuo.sc.entry.js",
		"common",
		14
	],
	"./7alfy39y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7alfy39y.entry.js",
		"common",
		15
	],
	"./7alfy39y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7alfy39y.sc.entry.js",
		"common",
		16
	],
	"./7fcfpjrn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7fcfpjrn.entry.js",
		"common",
		61
	],
	"./7fcfpjrn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7fcfpjrn.sc.entry.js",
		"common",
		62
	],
	"./9wrrczcy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9wrrczcy.entry.js",
		0,
		"common",
		135
	],
	"./9wrrczcy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9wrrczcy.sc.entry.js",
		0,
		"common",
		136
	],
	"./a9lbspgr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a9lbspgr.entry.js",
		"common",
		17
	],
	"./a9lbspgr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a9lbspgr.sc.entry.js",
		"common",
		18
	],
	"./ansnwlsp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ansnwlsp.entry.js",
		"common",
		19
	],
	"./ansnwlsp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ansnwlsp.sc.entry.js",
		"common",
		20
	],
	"./bibcp1y9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bibcp1y9.entry.js",
		"common",
		63
	],
	"./bibcp1y9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bibcp1y9.sc.entry.js",
		"common",
		64
	],
	"./bme372jv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bme372jv.entry.js",
		"common",
		65
	],
	"./bme372jv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bme372jv.sc.entry.js",
		"common",
		66
	],
	"./bryrct1s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bryrct1s.entry.js",
		"common",
		21
	],
	"./bryrct1s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bryrct1s.sc.entry.js",
		"common",
		22
	],
	"./byl9czyj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/byl9czyj.entry.js",
		"common",
		67
	],
	"./byl9czyj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/byl9czyj.sc.entry.js",
		"common",
		68
	],
	"./cageonqo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cageonqo.entry.js",
		"common",
		23
	],
	"./cageonqo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cageonqo.sc.entry.js",
		"common",
		24
	],
	"./cbqf6ftj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cbqf6ftj.entry.js",
		"common",
		69
	],
	"./cbqf6ftj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cbqf6ftj.sc.entry.js",
		"common",
		70
	],
	"./chp2j6cq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/chp2j6cq.entry.js",
		"common",
		25
	],
	"./chp2j6cq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/chp2j6cq.sc.entry.js",
		"common",
		26
	],
	"./coiwaa5h.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coiwaa5h.entry.js",
		0,
		"common",
		139
	],
	"./coiwaa5h.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coiwaa5h.sc.entry.js",
		0,
		"common",
		140
	],
	"./cvpeu494.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cvpeu494.entry.js",
		"common",
		27
	],
	"./cvpeu494.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cvpeu494.sc.entry.js",
		"common",
		28
	],
	"./dyxhizh4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dyxhizh4.entry.js",
		"common",
		29
	],
	"./dyxhizh4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dyxhizh4.sc.entry.js",
		"common",
		30
	],
	"./eblkb2xe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eblkb2xe.entry.js",
		0,
		"common",
		141
	],
	"./eblkb2xe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eblkb2xe.sc.entry.js",
		0,
		"common",
		142
	],
	"./efupgb3t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/efupgb3t.entry.js",
		"common",
		31
	],
	"./efupgb3t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/efupgb3t.sc.entry.js",
		"common",
		32
	],
	"./ek70mjfu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek70mjfu.entry.js",
		"common",
		33
	],
	"./ek70mjfu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek70mjfu.sc.entry.js",
		"common",
		34
	],
	"./ezzlijza.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ezzlijza.entry.js",
		"common",
		35
	],
	"./ezzlijza.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ezzlijza.sc.entry.js",
		"common",
		36
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		123
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		124
	],
	"./fiqi6app.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.entry.js",
		143
	],
	"./fiqi6app.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.sc.entry.js",
		144
	],
	"./g2to5rnb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g2to5rnb.entry.js",
		"common",
		37
	],
	"./g2to5rnb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g2to5rnb.sc.entry.js",
		"common",
		38
	],
	"./g6bzrzzd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g6bzrzzd.entry.js",
		"common",
		39
	],
	"./g6bzrzzd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g6bzrzzd.sc.entry.js",
		"common",
		40
	],
	"./gaj64apv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gaj64apv.entry.js",
		"common",
		75
	],
	"./gaj64apv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gaj64apv.sc.entry.js",
		"common",
		76
	],
	"./gksnkxfi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gksnkxfi.entry.js",
		"common",
		77
	],
	"./gksnkxfi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gksnkxfi.sc.entry.js",
		"common",
		78
	],
	"./he9083ts.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/he9083ts.entry.js",
		"common",
		125
	],
	"./he9083ts.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/he9083ts.sc.entry.js",
		"common",
		126
	],
	"./hm0yjz6v.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hm0yjz6v.entry.js",
		"common",
		71
	],
	"./hm0yjz6v.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hm0yjz6v.sc.entry.js",
		"common",
		72
	],
	"./hndgwhpb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hndgwhpb.entry.js",
		"common",
		127
	],
	"./hndgwhpb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hndgwhpb.sc.entry.js",
		"common",
		128
	],
	"./huoflabb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/huoflabb.entry.js",
		"common",
		79
	],
	"./huoflabb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/huoflabb.sc.entry.js",
		"common",
		80
	],
	"./i0gpae8e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i0gpae8e.entry.js",
		2,
		"common",
		145
	],
	"./i0gpae8e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i0gpae8e.sc.entry.js",
		2,
		"common",
		146
	],
	"./i1rfoh5j.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i1rfoh5j.entry.js",
		0,
		"common",
		147
	],
	"./i1rfoh5j.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i1rfoh5j.sc.entry.js",
		0,
		"common",
		148
	],
	"./ic12lvbr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ic12lvbr.entry.js",
		"common",
		81
	],
	"./ic12lvbr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ic12lvbr.sc.entry.js",
		"common",
		82
	],
	"./iq5jslpb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iq5jslpb.entry.js",
		0,
		"common",
		149
	],
	"./iq5jslpb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iq5jslpb.sc.entry.js",
		0,
		"common",
		150
	],
	"./iqiyzedq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqiyzedq.entry.js",
		"common",
		83
	],
	"./iqiyzedq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqiyzedq.sc.entry.js",
		"common",
		84
	],
	"./kzgfycox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kzgfycox.entry.js",
		0,
		"common",
		151
	],
	"./kzgfycox.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kzgfycox.sc.entry.js",
		0,
		"common",
		152
	],
	"./lbr5dtex.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lbr5dtex.entry.js",
		"common",
		85
	],
	"./lbr5dtex.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lbr5dtex.sc.entry.js",
		"common",
		86
	],
	"./louxpirp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/louxpirp.entry.js",
		"common",
		87
	],
	"./louxpirp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/louxpirp.sc.entry.js",
		"common",
		88
	],
	"./lqsyrhxc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqsyrhxc.entry.js",
		0,
		"common",
		115
	],
	"./lqsyrhxc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqsyrhxc.sc.entry.js",
		0,
		"common",
		116
	],
	"./mazigaom.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mazigaom.entry.js",
		"common",
		89
	],
	"./mazigaom.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mazigaom.sc.entry.js",
		"common",
		90
	],
	"./mvmkvb0v.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mvmkvb0v.entry.js",
		"common",
		91
	],
	"./mvmkvb0v.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mvmkvb0v.sc.entry.js",
		"common",
		92
	],
	"./npjviern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/npjviern.entry.js",
		"common",
		41
	],
	"./npjviern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/npjviern.sc.entry.js",
		"common",
		42
	],
	"./o6wfoo8y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6wfoo8y.entry.js",
		153
	],
	"./o6wfoo8y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6wfoo8y.sc.entry.js",
		154
	],
	"./oekkqbcc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oekkqbcc.entry.js",
		0,
		"common",
		155
	],
	"./oekkqbcc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oekkqbcc.sc.entry.js",
		0,
		"common",
		156
	],
	"./pj94v4tn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pj94v4tn.entry.js",
		"common",
		43
	],
	"./pj94v4tn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pj94v4tn.sc.entry.js",
		"common",
		44
	],
	"./poqqlq92.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/poqqlq92.entry.js",
		0,
		"common",
		157
	],
	"./poqqlq92.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/poqqlq92.sc.entry.js",
		0,
		"common",
		158
	],
	"./ps95c88c.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ps95c88c.entry.js",
		2,
		"common",
		159
	],
	"./ps95c88c.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ps95c88c.sc.entry.js",
		2,
		"common",
		160
	],
	"./pwf4b0ct.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pwf4b0ct.entry.js",
		"common",
		45
	],
	"./pwf4b0ct.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pwf4b0ct.sc.entry.js",
		"common",
		46
	],
	"./qvwswew4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.entry.js",
		"common",
		117
	],
	"./qvwswew4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.sc.entry.js",
		"common",
		118
	],
	"./rjuj7fe1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rjuj7fe1.entry.js",
		"common",
		47
	],
	"./rjuj7fe1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rjuj7fe1.sc.entry.js",
		"common",
		48
	],
	"./rwsekq0d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rwsekq0d.entry.js",
		"common",
		93
	],
	"./rwsekq0d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rwsekq0d.sc.entry.js",
		"common",
		94
	],
	"./rzti7vhz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rzti7vhz.entry.js",
		"common",
		95
	],
	"./rzti7vhz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rzti7vhz.sc.entry.js",
		"common",
		96
	],
	"./s1oi7icr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s1oi7icr.entry.js",
		0,
		"common",
		161
	],
	"./s1oi7icr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s1oi7icr.sc.entry.js",
		0,
		"common",
		162
	],
	"./srmtwcfh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/srmtwcfh.entry.js",
		"common",
		97
	],
	"./srmtwcfh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/srmtwcfh.sc.entry.js",
		"common",
		98
	],
	"./ssac3xh9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ssac3xh9.entry.js",
		"common",
		49
	],
	"./ssac3xh9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ssac3xh9.sc.entry.js",
		"common",
		50
	],
	"./t547wlk7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.entry.js",
		"common",
		119
	],
	"./t547wlk7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.sc.entry.js",
		"common",
		120
	],
	"./tix2rxyu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tix2rxyu.entry.js",
		"common",
		99
	],
	"./tix2rxyu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tix2rxyu.sc.entry.js",
		"common",
		100
	],
	"./vf5uvhxb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vf5uvhxb.entry.js",
		"common",
		101
	],
	"./vf5uvhxb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vf5uvhxb.sc.entry.js",
		"common",
		102
	],
	"./voah5ut7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/voah5ut7.entry.js",
		"common",
		103
	],
	"./voah5ut7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/voah5ut7.sc.entry.js",
		"common",
		104
	],
	"./wmec5hay.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wmec5hay.entry.js",
		"common",
		105
	],
	"./wmec5hay.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wmec5hay.sc.entry.js",
		"common",
		106
	],
	"./xjhsjpg5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xjhsjpg5.entry.js",
		0,
		"common",
		163
	],
	"./xjhsjpg5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xjhsjpg5.sc.entry.js",
		0,
		"common",
		164
	],
	"./xphsuoxm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xphsuoxm.entry.js",
		"common",
		73
	],
	"./xphsuoxm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xphsuoxm.sc.entry.js",
		"common",
		74
	],
	"./xqpitku0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xqpitku0.entry.js",
		"common",
		51
	],
	"./xqpitku0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xqpitku0.sc.entry.js",
		"common",
		52
	],
	"./yf92ghnn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yf92ghnn.entry.js",
		0,
		"common",
		121
	],
	"./yf92ghnn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yf92ghnn.sc.entry.js",
		0,
		"common",
		122
	],
	"./z9nt6ntd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.entry.js",
		"common",
		129
	],
	"./z9nt6ntd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.sc.entry.js",
		"common",
		130
	],
	"./zbmjxgef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zbmjxgef.entry.js",
		"common",
		53
	],
	"./zbmjxgef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zbmjxgef.sc.entry.js",
		"common",
		54
	],
	"./zejxbv2g.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zejxbv2g.entry.js",
		"common",
		107
	],
	"./zejxbv2g.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zejxbv2g.sc.entry.js",
		"common",
		108
	],
	"./zfesn3pp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfesn3pp.entry.js",
		"common",
		109
	],
	"./zfesn3pp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfesn3pp.sc.entry.js",
		"common",
		110
	],
	"./zsvoinsq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zsvoinsq.entry.js",
		"common",
		55
	],
	"./zsvoinsq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zsvoinsq.sc.entry.js",
		"common",
		56
	],
	"./zy1y1btp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zy1y1btp.entry.js",
		"common",
		111
	],
	"./zy1y1btp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zy1y1btp.sc.entry.js",
		"common",
		112
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./about/about.module": [
		"./src/app/about/about.module.ts",
		"about-about-module"
	],
	"./add-product/add-product.module": [
		"./src/app/add-product/add-product.module.ts",
		"add-product-add-product-module"
	],
	"./administration/administration.module": [
		"./src/app/administration/administration.module.ts",
		"administration-administration-module"
	],
	"./blog/blog.module": [
		"./src/app/blog/blog.module.ts",
		"blog-blog-module"
	],
	"./categories/categories.module": [
		"./src/app/categories/categories.module.ts",
		"categories-categories-module"
	],
	"./checkout/checkout.module": [
		"./src/app/checkout/checkout.module.ts",
		"checkout-checkout-module"
	],
	"./designer/designer.module": [
		"./src/app/designer/designer.module.ts",
		"designer-designer-module"
	],
	"./detail/detail.module": [
		"./src/app/detail/detail.module.ts",
		"detail-detail-module"
	],
	"./favorites/favorites.module": [
		"./src/app/favorites/favorites.module.ts",
		"favorites-favorites-module"
	],
	"./forgot/forgot.module": [
		"./src/app/forgot/forgot.module.ts",
		"common",
		"forgot-forgot-module"
	],
	"./home-client/home-client.module": [
		"./src/app/home-client/home-client.module.ts",
		"home-client-home-client-module"
	],
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./list/list.module": [
		"./src/app/list/list.module.ts",
		"list-list-module"
	],
	"./login/login.module": [
		"./src/app/login/login.module.ts",
		"common",
		"login-login-module"
	],
	"./mycart/mycart.module": [
		"./src/app/mycart/mycart.module.ts",
		"mycart-mycart-module"
	],
	"./myorder/myorder.module": [
		"./src/app/myorder/myorder.module.ts",
		"myorder-myorder-module"
	],
	"./offer/offer.module": [
		"./src/app/offer/offer.module.ts",
		"offer-offer-module"
	],
	"./post/post.module": [
		"./src/app/post/post.module.ts",
		"post-post-module"
	],
	"./profile/profile.module": [
		"./src/app/profile/profile.module.ts",
		"profile-profile-module"
	],
	"./search/search.module": [
		"./src/app/search/search.module.ts",
		"search-search-module"
	],
	"./setting/setting.module": [
		"./src/app/setting/setting.module.ts",
		"setting-setting-module"
	],
	"./shop/shop.module": [
		"./src/app/shop/shop.module.ts",
		"shop-shop-module"
	],
	"./signup/signup.module": [
		"./src/app/signup/signup.module.ts",
		"common",
		"signup-signup-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__.t(id, 7);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', loadChildren: './home/home.module#HomePageModule' },
    { path: 'list', loadChildren: './list/list.module#ListPageModule' },
    // { path: 'list/:cat', loadChildren: './list/list.module#ListPageModule' },
    { path: 'about', loadChildren: './about/about.module#AboutPageModule' },
    { path: 'blog', loadChildren: './blog/blog.module#BlogPageModule' },
    { path: 'checkout', loadChildren: './checkout/checkout.module#CheckoutPageModule' },
    // { path: 'checkout/:pay', loadChildren: './checkout/checkout.module#CheckoutPageModule' },
    { path: 'detail', loadChildren: './detail/detail.module#DetailPageModule' },
    // { path: 'detail/:obj', loadChildren: './detail/detail.module#DetailPageModule' },
    { path: 'favorites', loadChildren: './favorites/favorites.module#FavoritesPageModule' },
    { path: 'forgot', loadChildren: './forgot/forgot.module#ForgotPageModule' },
    { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
    { path: 'mycart', loadChildren: './mycart/mycart.module#MycartPageModule' },
    { path: 'myorder', loadChildren: './myorder/myorder.module#MyorderPageModule' },
    { path: 'offer', loadChildren: './offer/offer.module#OfferPageModule' },
    { path: 'post', loadChildren: './post/post.module#PostPageModule' },
    // { path: 'post/:obj', loadChildren: './post/post.module#PostPageModule' },
    { path: 'profile', loadChildren: './profile/profile.module#ProfilePageModule' },
    { path: 'search', loadChildren: './search/search.module#SearchPageModule' },
    { path: 'setting', loadChildren: './setting/setting.module#SettingPageModule' },
    { path: 'shop', loadChildren: './shop/shop.module#ShopPageModule' },
    { path: 'signup', loadChildren: './signup/signup.module#SignupPageModule' },
    { path: 'home-client', loadChildren: './home-client/home-client.module#HomeClientPageModule' },
    { path: 'administration', loadChildren: './administration/administration.module#AdministrationPageModule' },
    { path: 'designer', loadChildren: './designer/designer.module#DesignerPageModule' },
    { path: 'categories', loadChildren: './categories/categories.module#CategoriesPageModule' },
    { path: 'add-product', loadChildren: './add-product/add-product.module#AddProductPageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.RouterModule.forRoot(routes)],
            exports: [router_1.RouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;


/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app color=\"primary\">\n  <ion-split-pane color=\"primary\">\n    <ion-menu> \n     \n      <ion-content color=\"primary\">\n\n        <br>\n        <br>\n\n        <div class=\"profile-menu-wrap\" text-center *ngIf=\"user || user != null\">\n          <div class=\"wrap-top\">\n            <h2 class=\"spacing-1 mgb-15 fs-20 capitalize txt-dark fw-600\">{{user.username}}</h2>\n            <div class=\"avt-thumb\">\n              <img src=\"{{(user.avt != '' && user.avt != null)? user.avt : 'assets/imgs/no-avt.png' }}\">\n            </div>\n            <div text-center class=\"act\">\n              <ion-menu-toggle auto-hide=\"false\">\n                <ion-button size=\"small\" shpae=\"round\" color=\"dark\" class=\"btn-logout ovfl-hidden bdra-30 fs-12 mgl-10 mgb--10 shadow-2\" (click)=\"logout()\">\n                  <ion-icon name=\"md-log-out\"></ion-icon>\n                </ion-button>\n              </ion-menu-toggle>\n            </div>\n          </div>\n          <div class=\"info\">\n            <p class=\"mgt-20 txt-b2 fw-500 spaing-1 mgb-0 txt-dark\">{{user.email}}</p>\n            <p class=\"fs-12 txt-b4 spacing-1 mgt-5 txt-dark\">\n              <ion-icon name=\"pin\"></ion-icon>\n              {{(user.address && user.address != null && user.address != '')? user.address : 'Need to add address'}}\n            </p>\n\n            <br>\n          \n          </div>\n        </div>\n\n\n        <div color=\"primary\">\n          \n          <br>\n          \n          <ion-list class=\"primary\">\n            <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of menu\">\n              <ion-item color=\"primary\" [routerDirection]=\"'root'\" [routerLink]=\"[p.path]\">\n                <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n                <ion-label color=\"dark\">{{p.name}}</ion-label>\n              </ion-item>\n            </ion-menu-toggle>\n          </ion-list>\n\n          <br>\n          <br>\n        \n        </div>\n\n        <img class=\"logo-in-menu\" src=\"assets/imgs/knitting.png\">\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet main></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
var ngx_2 = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var environment_1 = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
// import * as firebase from 'firebase';
var currencies_1 = __webpack_require__(/*! ../providers/currencies */ "./src/providers/currencies.ts");
var users_1 = __webpack_require__(/*! ../providers/users */ "./src/providers/users.ts");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
// import { AdMobFree, AdMobFreeBannerConfig } from '@ionic-native/admob-free/ngx';
var AppComponent = /** @class */ (function () {
    function AppComponent(currenciesProv, toastCtrl, menuCtrl, events, storage, usersProv, router, platform, splashScreen, statusBar) {
        var _this = this;
        this.currenciesProv = currenciesProv;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.events = events;
        this.storage = storage;
        this.usersProv = usersProv;
        this.router = router;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.menu = [];
        this.menu = environment_1.environment.menu;
        // const bannerConfig: AdMobFreeBannerConfig = {
        //   id: 'ca-app-pub-3940256099942544/6300978111',
        //   isTesting: true,
        //   autoShow: true
        // };
        // this.admobFree.banner.config(bannerConfig);
        // this.admobFree.banner.prepare().then(() => {}).catch(e => console.log(e));
        this.events.subscribe('user: change', function (user) {
            if (user || user != null) {
                console.log('userchange');
                console.log(user);
                _this.user = user;
                // this.router.navigateByUrl('home-client');
                _this.menuCtrl.enable(true);
            }
            else {
                _this.router.navigateByUrl('login');
                _this.menuCtrl.enable(false);
            }
        });
        this.storage.ready().then(function () {
            _this.storage.get('user').then(function (val) {
                console.log(val);
                if (val != null) {
                    _this.user = val;
                    // this.router.navigateByUrl('home-client');
                    _this.menuCtrl.enable(true);
                }
                else {
                    _this.router.navigateByUrl('login');
                    _this.menuCtrl.enable(false);
                }
            });
        });
        // firebase.auth().onAuthStateChanged((user) => {
        //   if(!user){
        //     console.log("not login");
        //     this.menuCtrl.enable(false);
        //     this.router.navigateByUrl('login');
        //   }else{
        //     console.log("login");
        //     storage.ready().then(() => {
        //       storage.get('user').then((val) => {
        //         console.log(val);
        //         this.user = val;
        //         this.menuCtrl.enable(true);
        //         this.router.navigateByUrl('home');
        //       });
        //     })
        //   }
        // });
        this.initializeApp();
    }
    AppComponent.prototype.ionViewWillEnter = function () {
    };
    AppComponent.prototype.presentToast = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: msg.body,
                            duration: 3000,
                            position: 'top'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent.prototype.logout = function () {
        var _this = this;
        this.usersProv.logoutUser().then(function () {
            _this.storage.remove('user');
            _this.user = null;
            _this.storage.remove('cart_list');
            _this.router.navigateByUrl('/login');
            _this.menuCtrl.enable(false);
        });
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [currencies_1.CurrenciesProvider,
            angular_1.ToastController,
            angular_1.MenuController,
            angular_1.Events,
            storage_1.Storage,
            users_1.UsersProvider,
            router_1.Router,
            angular_1.Platform,
            ngx_1.SplashScreen,
            ngx_2.StatusBar])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var platform_browser_1 = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
var ngx_2 = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var app_component_1 = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
var app_routing_module_1 = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
var angularfire2_1 = __webpack_require__(/*! angularfire2 */ "./node_modules/angularfire2/index.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var environment_1 = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
var about_1 = __webpack_require__(/*! ../providers/about */ "./src/providers/about.ts");
var categories_1 = __webpack_require__(/*! ../providers/categories */ "./src/providers/categories.ts");
var posts_1 = __webpack_require__(/*! ../providers/posts */ "./src/providers/posts.ts");
var products_1 = __webpack_require__(/*! ../providers/products */ "./src/providers/products.ts");
var users_1 = __webpack_require__(/*! ../providers/users */ "./src/providers/users.ts");
var orders_1 = __webpack_require__(/*! ../providers/orders */ "./src/providers/orders.ts");
var contacts_1 = __webpack_require__(/*! ../providers/contacts */ "./src/providers/contacts.ts");
var settings_1 = __webpack_require__(/*! ../providers/settings */ "./src/providers/settings.ts");
var currencies_1 = __webpack_require__(/*! ../providers/currencies */ "./src/providers/currencies.ts");
var upload_1 = __webpack_require__(/*! ../providers/upload */ "./src/providers/upload.ts");
var fcm_1 = __webpack_require__(/*! ../providers/fcm */ "./src/providers/fcm.ts");
var favorites_1 = __webpack_require__(/*! ../providers/favorites */ "./src/providers/favorites.ts");
var theme_1 = __webpack_require__(/*! ../providers/theme */ "./src/providers/theme.ts");
var ngx_3 = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
var ngx_4 = __webpack_require__(/*! @ionic-native/paypal/ngx */ "./node_modules/@ionic-native/paypal/ngx/index.js");
var ngx_5 = __webpack_require__(/*! @ionic-native/stripe/ngx */ "./node_modules/@ionic-native/stripe/ngx/index.js");
var ngx_6 = __webpack_require__(/*! @ionic-native/call-number/ngx */ "./node_modules/@ionic-native/call-number/ngx/index.js");
var ngx_7 = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
var ngx_8 = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/ngx/index.js");
var ngx_9 = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
var ngx_10 = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
var ngx_11 = __webpack_require__(/*! @ionic-native/admob-free/ngx */ "./node_modules/@ionic-native/admob-free/ngx/index.js");
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            declarations: [app_component_1.AppComponent],
            entryComponents: [],
            imports: [
                platform_browser_1.BrowserModule,
                angular_1.IonicModule.forRoot(),
                app_routing_module_1.AppRoutingModule,
                angularfire2_1.AngularFireModule.initializeApp(environment_1.environment.firebase),
                firestore_1.AngularFirestoreModule,
                storage_1.IonicStorageModule.forRoot()
            ],
            providers: [
                ngx_2.StatusBar,
                ngx_1.SplashScreen,
                about_1.AboutProvider,
                categories_1.CategoriesProvider,
                posts_1.PostsProvider,
                products_1.ProductsProvider,
                users_1.UsersProvider,
                orders_1.OrdersProvider,
                contacts_1.ContactsProvider,
                settings_1.SettingsProvider,
                currencies_1.CurrenciesProvider,
                upload_1.UploadProvider,
                fcm_1.FcmProvider,
                favorites_1.FavoritesProvider,
                theme_1.ThemeProvider,
                ngx_3.Facebook,
                ngx_5.Stripe,
                ngx_6.CallNumber,
                ngx_7.SocialSharing,
                ngx_4.PayPal,
                ngx_8.InAppBrowser,
                ngx_9.Camera,
                ngx_11.AdMobFree,
                ngx_10.File,
                { provide: router_1.RouteReuseStrategy, useClass: angular_1.IonicRouteStrategy }
            ],
            bootstrap: [app_component_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = {
    production: false,
    AdMobFreeBannerConfig: {
        isTesting: true,
        autoShow: true
    },
    firebase: {
        apiKey: 'AIzaSyAU0_A_m4kqjKQ3zcPwzs0uJgkF7zThbZE',
        authDomain: 'proyectodegraduacion-3a260.firebaseapp.com',
        databaseURL: 'https://proyectodegraduacion-3a260.firebaseio.com',
        projectId: 'proyectodegraduacion-3a260',
        storageBucket: 'proyectodegraduacion-3a260.appspot.com',
        messagingSenderId: '416186548795',
        appId: '1:416186548795:web:aeceec77bb54be2f'
    },
    stripe_publish_key: 'pk_test_nqykHcHCdCnWPJCD6pguqShK',
    google_project_number: '762391382612',
    fb_app: 571610369618746,
    fb_v: "v3.2",
    paypal_sandbox_client_id: "Ac-QK_Lkar46qQDWcp1kega6aPk13SxXv3dkCVX7A2Nlw7BViP3JyDUQQg-6W386yjgaeEHTuaO9BxGx",
    paypal_live_client_id: "",
    languages: {
        'en': 'English',
        'vi': 'Vietnamese'
    },
    menu: [{
            name: 'Inicio',
            path: '/home-client',
            component: 'HomeClientPage',
            icon: 'ios-home',
        },
        // {
        // 	name: 'Shop',
        // 	path: '/shop',
        // 	component: 'ShopPage',
        // 	icon: 'ios-shirt',
        // },
        // {
        // 	name: 'Acerca de',
        // 	path: '/about',
        // 	component: 'AboutPage',
        // 	icon: 'ios-albums',
        // },
        // {
        // 	name: 'Blog',
        // 	path: '/blog',
        // 	component: 'BlogPage',
        // 	icon: 'md-paper',
        // },
        {
            name: 'Mis favoritos',
            path: '/favorites',
            component: 'FavoritesPage',
            icon: 'md-heart-empty',
        }, {
            name: 'Carrito de compras',
            path: '/mycart',
            component: 'MycartPage',
            icon: 'md-basket',
        }, {
            name: 'Mis pedidos',
            path: '/myorder',
            component: 'MyorderPage',
            icon: 'md-clipboard',
        }, {
            name: 'Ofertas',
            path: '/offer',
            component: 'OfferPage',
            icon: 'md-gift',
        }, {
            name: 'Perfil',
            path: '/profile',
            component: 'ProfilePage',
            icon: 'ios-contact',
        },
    ],
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var platform_browser_dynamic_1 = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
var app_module_1 = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
var environment_1 = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
if (environment_1.environment.production) {
    core_1.enableProdMode();
}
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(app_module_1.AppModule)
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ "./src/providers/about.ts":
/*!********************************!*\
  !*** ./src/providers/about.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var AboutProvider = /** @class */ (function () {
    function AboutProvider(afs) {
        this.afs = afs;
    }
    AboutProvider.prototype.createNewDesignOrder = function (designOrder) {
        return this.afs.collection('design_orders').add(designOrder);
    };
    AboutProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], AboutProvider);
    return AboutProvider;
}());
exports.AboutProvider = AboutProvider;


/***/ }),

/***/ "./src/providers/categories.ts":
/*!*************************************!*\
  !*** ./src/providers/categories.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var CategoriesProvider = /** @class */ (function () {
    function CategoriesProvider(afs) {
        this.afs = afs;
    }
    CategoriesProvider.prototype.getCat = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('categories').snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    CategoriesProvider.prototype.getCatParent = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('categories', function (ref) { return ref.where('id_parent', '==', ''); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    CategoriesProvider.prototype.getCatChild = function (id_parent) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('categories', function (ref) { return ref.where('id_parent', '==', id_parent); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    CategoriesProvider.prototype.updateCat = function (value, key) {
        var _this = this;
        if (key === void 0) { key = null; }
        return new Promise(function (resolve, reject) {
            if (key == null) {
                value.active = true;
                value.created = Date();
                _this.snapshotChangesSubscription = _this.afs.collection('categories').add(value).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
            else {
                value.updated = Date();
                _this.snapshotChangesSubscription = _this.afs.collection('categories').doc(key).update(value).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
        });
    };
    CategoriesProvider.prototype.activeCat = function (val, key, where) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.afs.collection('categories').doc(key).update({
                active: val,
                created: Date()
            }).then(function (res) {
                _this.afs.collection('categories', function (ref) { return ref.where('name', '==', where); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            }, function (err) { return reject(err); });
        });
    };
    CategoriesProvider.prototype.deleteCat = function (key) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('categories').doc(key).delete()
                .then(function (res) { return resolve(res); }, function (err) { return reject(err); });
        });
    };
    CategoriesProvider.prototype.getCatSpec = function (active, name, id_parent, start, jump, order) {
        var _this = this;
        if (active === void 0) { active = null; }
        if (name === void 0) { name = null; }
        if (id_parent === void 0) { id_parent = null; }
        if (start === void 0) { start = null; }
        if (jump === void 0) { jump = null; }
        if (order === void 0) { order = null; }
        return new Promise(function (resolve, reject) {
            var query = function (ref) {
                if (jump != null) {
                    ref = ref.limit(jump);
                }
                if (active != null) {
                    ref = ref.where('active', '==', active);
                }
                if (name != null) {
                    ref = ref.where('name', '==', name);
                }
                if (id_parent != null) {
                    ref = ref.where('id_parent', '==', id_parent);
                }
                if (start != null) {
                    ref = ref.startAt(start);
                }
                if (order) {
                    ref = ref.orderBy(order);
                }
                return ref;
            };
            _this.snapshotChangesSubscription = _this.afs.collection('categories', query).snapshotChanges().subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    CategoriesProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], CategoriesProvider);
    return CategoriesProvider;
}());
exports.CategoriesProvider = CategoriesProvider;


/***/ }),

/***/ "./src/providers/contacts.ts":
/*!***********************************!*\
  !*** ./src/providers/contacts.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
// import { Observable } from 'rxjs-compat/Observable';
// import { AngularFirestore } from 'angularfire2/firestore';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var ContactsProvider = /** @class */ (function () {
    function ContactsProvider(afs) {
        this.afs = afs;
    }
    ContactsProvider.prototype.getContacts = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs
                .collection("orders")
                .snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    ContactsProvider.prototype.getContactsSpec = function (active, fullname, start, jump, order) {
        var _this = this;
        if (active === void 0) { active = null; }
        if (fullname === void 0) { fullname = null; }
        if (start === void 0) { start = null; }
        if (jump === void 0) { jump = null; }
        if (order === void 0) { order = null; }
        return new Promise(function (resolve, reject) {
            var query = function (ref) {
                if (jump != null) {
                    ref = ref.limit(jump);
                }
                if (active != null) {
                    ref = ref.where("active", "==", active);
                }
                if (fullname != null) {
                    ref = ref.where("fullname", "==", fullname);
                }
                if (start != null) {
                    ref = ref.startAt(start);
                }
                if (order) {
                    ref = ref.orderBy(order);
                }
                return ref;
            };
            _this.snapshotChangesSubscription = _this.afs
                .collection("contacts", query)
                .snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    ContactsProvider.prototype.activeContact = function (val, key, where) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.afs
                .collection("contacts")
                .doc(key)
                .update({
                active: val,
                created: Date()
            })
                .then(function (res) {
                _this.afs
                    .collection("contacts", function (ref) { return ref.where("fullname", "==", where); })
                    .snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            }, function (err) { return reject(err); });
        });
    };
    ContactsProvider.prototype.deleteContact = function (key) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs
                .collection("contacts")
                .doc(key)
                .delete()
                .then(function (res) { return resolve(res); }, function (err) { return reject(err); });
        });
    };
    ContactsProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], ContactsProvider);
    return ContactsProvider;
}());
exports.ContactsProvider = ContactsProvider;


/***/ }),

/***/ "./src/providers/currencies.ts":
/*!*************************************!*\
  !*** ./src/providers/currencies.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/*
Generated class for the HelpersProvider provider.

See https://angular.io/guide/dependency-injection for more info on providers
and Angular DI.
*/
var CurrenciesProvider = /** @class */ (function () {
    function CurrenciesProvider(storage, afs) {
        var _this = this;
        this.storage = storage;
        this.afs = afs;
        this.setting = null;
        if (this.setting == null) {
            new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('settings').valueChanges()
                    .subscribe(function (snapshots) {
                    _this.setting = snapshots[0];
                    _this.storage.set('setting', snapshots[0]);
                    console.log(_this.setting);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    }
    CurrenciesProvider.prototype.formatMoney = function (money) {
        var formatter = Intl.NumberFormat(this.setting.currency_language_code + '-' + this.setting.currency_iso_alpha2, {
            style: 'currency',
            currency: this.setting.currency_code
        });
        return formatter.format(money);
    };
    CurrenciesProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [storage_1.Storage, firestore_1.AngularFirestore])
    ], CurrenciesProvider);
    return CurrenciesProvider;
}());
exports.CurrenciesProvider = CurrenciesProvider;


/***/ }),

/***/ "./src/providers/favorites.ts":
/*!************************************!*\
  !*** ./src/providers/favorites.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var FavoritesProvider = /** @class */ (function () {
    function FavoritesProvider(afs) {
        this.afs = afs;
    }
    FavoritesProvider.prototype.getFavorites = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('favorites').snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    FavoritesProvider.prototype.getFavoByIdPd = function (id_product) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('id_pd', '==', id_product); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    FavoritesProvider.prototype.getByUserId = function (uid) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('favorites', function (ref) { return ref.where('id_user', '==', uid); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    FavoritesProvider.prototype.favoritesAdd = function (id_product, id_user, key) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            if (key) {
                _this.snapshotChangesSubscription = _this.afs.collection('favorites').doc(key).update({
                    id_product: id_product,
                    created: Date()
                }).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
            else {
                _this.snapshotChangesSubscription = _this.afs.collection('favorites').add({
                    id_product: id_product,
                    id_user: id_user,
                    created: Date()
                }).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
        });
    };
    FavoritesProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], FavoritesProvider);
    return FavoritesProvider;
}());
exports.FavoritesProvider = FavoritesProvider;


/***/ }),

/***/ "./src/providers/fcm.ts":
/*!******************************!*\
  !*** ./src/providers/fcm.ts ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/firebase/ngx */ "./node_modules/@ionic-native/firebase/ngx/index.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
/*
Generated class for the FcmProvider provider.

See https://angular.io/guide/dependency-injection for more info on providers
and Angular DI.
*/
var FcmProvider = /** @class */ (function () {
    function FcmProvider(firebaseNative, afs, platform) {
        this.firebaseNative = firebaseNative;
        this.afs = afs;
        this.platform = platform;
        console.log('Hello FcmProvider Provider');
    }
    FcmProvider.prototype.getToken = function () {
        return __awaiter(this, void 0, void 0, function () {
            var token;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.platform.is('android')) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.firebaseNative.getToken()];
                    case 1:
                        token = _a.sent();
                        _a.label = 2;
                    case 2:
                        if (!this.platform.is('ios')) return [3 /*break*/, 5];
                        return [4 /*yield*/, this.firebaseNative.getToken()];
                    case 3:
                        token = _a.sent();
                        return [4 /*yield*/, this.firebaseNative.grantPermission()];
                    case 4:
                        _a.sent();
                        _a.label = 5;
                    case 5: return [2 /*return*/, this.saveTokenToFirestore(token)];
                }
            });
        });
    };
    // Save the token to firestore
    FcmProvider.prototype.saveTokenToFirestore = function (token) {
        if (!token)
            return;
        var devicesRef = this.afs.collection('devices');
        var docData = {
            token: token,
            userId: 'testUser',
        };
        return devicesRef.doc(token).set(docData);
    };
    // Listen to incoming FCM messages
    FcmProvider.prototype.listenToNotifications = function () {
        return this.firebaseNative.onNotificationOpen();
    };
    FcmProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [ngx_1.Firebase, firestore_1.AngularFirestore, angular_1.Platform])
    ], FcmProvider);
    return FcmProvider;
}());
exports.FcmProvider = FcmProvider;


/***/ }),

/***/ "./src/providers/orders.ts":
/*!*********************************!*\
  !*** ./src/providers/orders.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
// import { Observable } from 'rxjs-compat/Observable';
// import { AngularFirestore } from 'angularfire2/firestore';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var OrdersProvider = /** @class */ (function () {
    function OrdersProvider(afs) {
        this.afs = afs;
    }
    OrdersProvider.prototype.getOrders = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('orders').snapshotChanges().subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    OrdersProvider.prototype.getOrdersPending = function (id_user) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('orders', function (ref) { return ref.where('id_user', '==', id_user).where('active', '==', true); }).snapshotChanges().subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    OrdersProvider.prototype.getOrdersSuccess = function (id_user, limit) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('orders', function (ref) { return ref.where('id_user', '==', id_user).where('active', '==', false).limit(limit); }).snapshotChanges().subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    OrdersProvider.prototype.addOrders = function (data) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            data.active = true;
            data.created = Date();
            _this.snapshotChangesSubscription = _this.afs.collection('orders').add(data).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
        });
    };
    OrdersProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], OrdersProvider);
    return OrdersProvider;
}());
exports.OrdersProvider = OrdersProvider;


/***/ }),

/***/ "./src/providers/posts.ts":
/*!********************************!*\
  !*** ./src/providers/posts.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var PostsProvider = /** @class */ (function () {
    function PostsProvider(afs) {
        this.afs = afs;
    }
    PostsProvider.prototype.getPost = function (start, jump) {
        var _this = this;
        if (start !== null) {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('posts', function (ref) { return ref.orderBy('name').startAfter(start).limit(jump); }).valueChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
        else {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('posts', function (ref) { return ref.orderBy('name').limit(jump); }).valueChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    };
    PostsProvider.prototype.getPostByStar = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('posts', function (ref) { return ref.where('highlight', '==', true); }).valueChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    PostsProvider.prototype.getPostByNew = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('posts', function (ref) { return ref.orderBy('created', 'desc').limit(4); }).valueChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    PostsProvider.prototype.getPostByRelated = function (tag, name) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('posts', function (ref) { return ref.orderBy('name').limit(10); }).valueChanges()
                .subscribe(function (snapshots) {
                var arr = new Array();
                snapshots.forEach(function (val) {
                    var temp = val['tag'];
                    if (temp.startsWith(tag) && val['name'] != name) {
                        arr = arr.concat(val);
                    }
                });
                resolve(arr);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    PostsProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], PostsProvider);
    return PostsProvider;
}());
exports.PostsProvider = PostsProvider;


/***/ }),

/***/ "./src/providers/products.ts":
/*!***********************************!*\
  !*** ./src/providers/products.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var ProductsProvider = /** @class */ (function () {
    function ProductsProvider(afs) {
        this.afs = afs;
        var settings = { timestampsInSnapshots: true };
        afs.firestore.settings(settings);
    }
    ProductsProvider.prototype.createNewProduct = function (product) {
        return this.afs.collection('products').add(product);
    };
    ProductsProvider.prototype.updateProduct = function (productId, product) {
        return this.afs.doc('products/' + productId).update(product);
    };
    ProductsProvider.prototype.getProduct = function (start, jump) {
        var _this = this;
        if (start !== null) {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.orderBy('name').startAfter(start).limit(jump); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
        else {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.orderBy('name').limit(jump); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    };
    ProductsProvider.prototype.getProductById = function (id_product) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('id_pd', '==', id_product); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    ProductsProvider.prototype.getProductByCat = function (start, jump, id_cat) {
        var _this = this;
        if (start !== null) {
            return new Promise(function (resolve, reject) {
                console.log(start);
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('id_cat', '<', id_cat).orderBy('id_cat').startAfter(start); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    console.log(snapshots);
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
        else {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('id_cat', '==', id_cat).limit(jump); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    };
    ProductsProvider.prototype.getProductByOffer = function (start, jump) {
        var _this = this;
        if (start !== null) {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('discount', '>', 0).orderBy('discount').startAfter(start).limit(jump); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
        else {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('discount', '>', 0).limit(jump); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    };
    ProductsProvider.prototype.getProductByName = function (start, jump, name_str) {
        var _this = this;
        if (start !== null) {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.orderBy('name').startAfter(start); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    var arr = new Array();
                    snapshots.forEach(function (val) {
                        var temp = val.payload.doc.data()['name'];
                        if (temp.startsWith(name_str)) {
                            arr = arr.concat(val);
                        }
                    });
                    resolve(arr);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
        else {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.orderBy('name'); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    var arr = new Array();
                    snapshots.forEach(function (val) {
                        var temp = val.payload.doc.data()['name'];
                        if (temp.startsWith(name_str)) {
                            arr = arr.concat(val);
                        }
                    });
                    resolve(arr);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    };
    ProductsProvider.prototype.getProductBySlide = function (limit, cat) {
        var _this = this;
        if (cat === void 0) { cat = null; }
        if (cat != null) {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('id_cat', '==', cat).where('type', '==', 1).limit(limit); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
        else {
            return new Promise(function (resolve, reject) {
                _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('type', '==', 1).limit(limit); }).snapshotChanges()
                    .subscribe(function (snapshots) {
                    resolve(snapshots);
                    _this.snapshotChangesSubscription.unsubscribe();
                });
            });
        }
    };
    ProductsProvider.prototype.getProductByCreated = function (limit) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.orderBy('created').limit(limit); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    ProductsProvider.prototype.getProductByRelated = function (tag) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('products', function (ref) { return ref.where('tag', '==', tag).limit(5); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    ProductsProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], ProductsProvider);
    return ProductsProvider;
}());
exports.ProductsProvider = ProductsProvider;


/***/ }),

/***/ "./src/providers/settings.ts":
/*!***********************************!*\
  !*** ./src/providers/settings.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
// import { Observable } from 'rxjs-compat/Observable';
// import { AngularFirestore } from 'angularfire2/firestore';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var SettingsProvider = /** @class */ (function () {
    function SettingsProvider(afs) {
        this.afs = afs;
    }
    SettingsProvider.prototype.getCurrency = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('currencies').snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    SettingsProvider.prototype.getGeneralSettings = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('settings').snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    SettingsProvider.prototype.getAboutSettings = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('about').snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    SettingsProvider.prototype.updateGeneral = function (value, key) {
        var _this = this;
        if (key === void 0) { key = null; }
        return new Promise(function (resolve, reject) {
            if (key == null) {
                value.created = Date();
                _this.snapshotChangesSubscription = _this.afs.collection('settings').add(value).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
            else {
                value.updated = Date();
                _this.snapshotChangesSubscription = _this.afs.collection('settings').doc(key).update(value).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
        });
    };
    SettingsProvider.prototype.updateAbout = function (value, key) {
        var _this = this;
        if (key === void 0) { key = null; }
        return new Promise(function (resolve, reject) {
            if (key == null) {
                value.created = Date();
                _this.snapshotChangesSubscription = _this.afs.collection('about').add(value).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
            else {
                value.updated = Date();
                _this.snapshotChangesSubscription = _this.afs.collection('about').doc(key).update(value).then(function (res) { return resolve(res); }, function (err) { return reject(err); });
            }
        });
    };
    SettingsProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore])
    ], SettingsProvider);
    return SettingsProvider;
}());
exports.SettingsProvider = SettingsProvider;


/***/ }),

/***/ "./src/providers/theme.ts":
/*!********************************!*\
  !*** ./src/providers/theme.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var Color = __webpack_require__(/*! color */ "./node_modules/color/index.js");
var storage_1 = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
var defaults = {
    primary: '#3880ff',
    secondary: '#0cd1e8',
    tertiary: '#7044ff',
    info: '#03a9f4',
    success: '#C0E89D',
    warning: '#F9EE72',
    danger: '#F97070',
    dark: '#222428',
    medium: '#989aa2',
    light: '#f4f5f8'
};
function CSSTextGenerator(colors) {
    colors = __assign({}, defaults, colors);
    var primary = colors.primary, secondary = colors.secondary, tertiary = colors.tertiary, info = colors.info, success = colors.success, warning = colors.warning, danger = colors.danger, dark = colors.dark, medium = colors.medium, light = colors.light;
    var shadeRatio = 0.1;
    var tintRatio = 0.1;
    var shadowRatio = 0.5;
    return "\n    --ion-color-base: " + primary + ";\n\n    --ion-color-contrast: " + dark + ";\n    \n\n    --ion-text-color: " + dark + ";\n    --ion-text-color-lv2: " + Color(dark).lighten(1.7) + ";\n    --ion-text-color-lv3: " + Color(dark).lighten(3) + ";\n    --ion-text-color-lv4: " + Color(dark).lighten(5) + ";\n    --ion-text-color-lv5: " + Color(dark).lighten(7) + ";\n\n\n    --ion-item-text-color: " + contrast(dark, 0.3) + ";\n    --ion-item-background-color: " + Color(light).lighten(0.1) + ";\n    \n\n    --ion-tabbar-text-color-active: " + primary + ";\n    --ion-tabbar-background-color: " + Color(light).lighten(0.05) + ";\n\n\n    --ion-toolbar-text-color: " + contrast(dark, 0.1) + ";\n    --ion-toolbar-background-color: " + light + ";\n    --background: " + Color(light).lighten(0.1) + ";\n\n\n    --ion-background-color: " + Color(light).lighten(0.1) + ";\n\n\n    --color-selected: " + dark + ";\n\n\n    --ion-color-primary: " + primary + ";\n    --ion-color-primary-rgb: 56,128,255;\n    --ion-color-primary-contrast: " + contrast(primary) + ";\n    --ion-color-primary-contrast-rgb: 255,255,255;\n    --ion-color-primary-shade:  " + Color(primary).darken(shadeRatio) + ";\n    --ion-color-primary-tint:  " + Color(primary).lighten(tintRatio) + ";\n    --ion-color-primary-shadow:  " + Color(primary).lighten(shadeRatio) + ";\n\n    --ion-color-secondary: " + secondary + ";\n    --ion-color-secondary-rgb: 12,209,232;\n    --ion-color-secondary-contrast: " + Color(secondary).lighten(10) + ";\n    --ion-color-secondary-contrast-rgb: 255,255,255;\n    --ion-color-secondary-shade:  " + Color(secondary).darken(shadeRatio) + ";\n    --ion-color-secondary-tint: " + Color(secondary).lighten(tintRatio) + ";\n    --ion-color-secondary-shadow: " + Color(secondary).lighten(shadeRatio) + ";\n\n    --ion-color-tertiary:  " + tertiary + ";\n    --ion-color-tertiary-rgb: 112,68,255;\n    --ion-color-tertiary-contrast: " + contrast(tertiary) + ";\n    --ion-color-tertiary-contrast-rgb: 255,255,255;\n    --ion-color-tertiary-shade: " + Color(tertiary).darken(shadeRatio) + ";\n    --ion-color-tertiary-tint:  " + Color(tertiary).lighten(tintRatio) + ";\n    --ion-color-tertiary-shadow:  " + Color(tertiary).lighten(shadowRatio) + ";\n\n    --ion-color-info: " + info + ";\n    --ion-color-info-rgb: 16,220,96;\n    --ion-color-info-contrast: " + Color(info).lighten(10) + ";\n    --ion-color-info-contrast-rgb: 255,255,255;\n    --ion-color-info-shade: " + Color(info).darken(shadeRatio) + ";\n    --ion-color-info-tint: " + Color(info).lighten(tintRatio) + ";\n    --ion-color-info-shadow: " + Color(info).lighten(shadowRatio) + ";\n    \n    --ion-color-success: " + success + ";\n    --ion-color-success-rgb: 16,220,96;\n    --ion-color-success-contrast: " + contrast(success) + ";\n    --ion-color-success-contrast-rgb: 255,255,255;\n    --ion-color-success-shade: " + Color(success).darken(shadeRatio) + ";\n    --ion-color-success-tint: " + Color(success).lighten(tintRatio) + ";\n    --ion-color-success-shadow: " + Color(success).lighten(shadowRatio) + ";\n\n    --ion-color-warning: " + warning + ";\n    --ion-color-warning-rgb: 255,206,0;\n    --ion-color-warning-contrast: " + contrast(warning) + ";\n    --ion-color-warning-contrast-rgb: 255,255,255;\n    --ion-color-warning-shade: " + Color(warning).darken(shadeRatio) + ";\n    --ion-color-warning-tint: " + Color(warning).lighten(tintRatio) + ";\n    --ion-color-warning-shadow: " + Color(warning).lighten(shadowRatio) + ";\n\n    --ion-color-danger: " + danger + ";\n    --ion-color-danger-rgb: 245,61,61;\n    --ion-color-danger-contrast: " + Color(danger).lighten(10) + ";\n    --ion-color-danger-contrast-rgb: 255,255,255;\n    --ion-color-danger-shade: " + Color(danger).darken(shadeRatio) + ";\n    --ion-color-danger-tint: " + Color(danger).lighten(tintRatio) + ";\n    --ion-color-danger-shadow: " + Color(danger).lighten(0.2) + ";\n\n    --ion-color-dark: " + dark + ";\n    --ion-color-dark-rgb: 34,34,34;\n    --ion-color-dark-contrast: " + Color(dark).lighten(10) + ";\n    --ion-color-dark-contrast-rgb: 255,255,255;\n    --ion-color-dark-shade: " + Color(dark).darken(shadeRatio) + ";\n    --ion-color-dark-tint: " + Color(dark).lighten(tintRatio) + ";\n    --ion-color-dark-shadow: " + Color(dark).lighten(shadowRatio) + ";\n\n    --ion-color-medium: " + medium + ";\n    --ion-color-medium-rgb: 152,154,162;\n    --ion-color-medium-contrast: " + contrast(medium) + ";\n    --ion-color-medium-contrast-rgb: 255,255,255;\n    --ion-color-medium-shade: " + Color(medium).darken(shadeRatio) + ";\n    --ion-color-medium-tint: " + Color(medium).lighten(tintRatio) + ";\n    --ion-color-medium-shadow: " + Color(medium).lighten(shadowRatio) + ";\n\n    --ion-color-light: " + light + ";\n    --ion-color-light-rgb: 244,244,244;\n    --ion-color-light-contrast: " + contrast(light) + ";\n    --ion-color-light-contrast-rgb: 0,0,0;\n    --ion-color-light-shade: " + Color(light).darken(shadeRatio) + ";\n    --ion-color-light-tint: " + Color(light).lighten(tintRatio) + ";\n    --ion-color-light-shadow: " + Color(light).lighten(shadowRatio) + ";";
}
function contrast(color, ratio) {
    if (ratio === void 0) { ratio = 0.8; }
    color = Color(color);
    return color.isDark() ? color.lighten(ratio) : color.darken(ratio);
}
var ThemeProvider = /** @class */ (function () {
    function ThemeProvider(storage, document) {
        var _this = this;
        this.storage = storage;
        this.document = document;
        storage.get('theme').then(function (cssText) {
            _this.setGlobalCSS(cssText);
        });
    }
    // Override all global variables with a new theme
    ThemeProvider.prototype.setTheme = function (theme) {
        var cssText = CSSTextGenerator(theme);
        this.setGlobalCSS(cssText);
        this.storage.set('theme', cssText);
    };
    // Define a single CSS variable
    ThemeProvider.prototype.setGlobalCSS = function (css) {
        this.document.documentElement.style.cssText = css;
    };
    Object.defineProperty(ThemeProvider.prototype, "storedTheme", {
        get: function () {
            return this.storage.get('theme');
        },
        enumerable: true,
        configurable: true
    });
    ThemeProvider = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __param(1, core_1.Inject(common_1.DOCUMENT)),
        __metadata("design:paramtypes", [storage_1.Storage,
            Document])
    ], ThemeProvider);
    return ThemeProvider;
}());
exports.ThemeProvider = ThemeProvider;


/***/ }),

/***/ "./src/providers/upload.ts":
/*!*********************************!*\
  !*** ./src/providers/upload.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var storage_1 = __webpack_require__(/*! angularfire2/storage */ "./node_modules/angularfire2/storage/index.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var firebase = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
var UploadProvider = /** @class */ (function () {
    function UploadProvider(afStorage, db) {
        this.afStorage = afStorage;
        this.db = db;
    }
    UploadProvider.prototype.upload = function (file, folderName) {
        var _this = this;
        var randomId = Math.random().toString(36).substring(2);
        var storageRef = firebase.storage().ref();
        var uploadTask = storageRef.child('/' + folderName + '/' + randomId).put(file);
        return new Promise(function (resolve, reject) {
            uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED, function (snapshot) { }, function (error) { }, function () {
                uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                    _this.downloadURL = downloadURL;
                    console.log('File available at', downloadURL);
                    resolve(_this.downloadURL);
                });
            });
        });
    };
    UploadProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [storage_1.AngularFireStorage, firestore_1.AngularFirestore])
    ], UploadProvider);
    return UploadProvider;
}());
exports.UploadProvider = UploadProvider;


/***/ }),

/***/ "./src/providers/users.ts":
/*!********************************!*\
  !*** ./src/providers/users.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

//import * as Constants from '../../config/constants';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var firebase = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
var firestore_1 = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
var ngx_1 = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
var UsersProvider = /** @class */ (function () {
    function UsersProvider(afs, facebook, alertCtrl) {
        this.afs = afs;
        this.facebook = facebook;
        this.alertCtrl = alertCtrl;
    }
    UsersProvider.prototype.uploadAvt = function (file) {
        var _this = this;
        var randomId = Math.random().toString(36).substring(2);
        var storageRef = firebase.storage().ref();
        var uploadTask = storageRef.child('/users/' + randomId).put(file);
        return new Promise(function (resolve, reject) {
            uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED, function (snapshot) { }, function (error) { }, function () {
                uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                    _this.downloadURL = downloadURL;
                    console.log('File available at', downloadURL);
                    resolve(_this.downloadURL);
                });
            });
        });
    };
    UsersProvider.prototype.loginUser = function (email, password) {
        return firebase.auth().signInWithEmailAndPassword(email, password);
    };
    UsersProvider.prototype.signupUser = function (email, password, fullname, phone, address) {
        var _this = this;
        if (phone === void 0) { phone = null; }
        if (address === void 0) { address = null; }
        return new Promise(function (resolve, reject) {
            firebase.auth().createUserWithEmailAndPassword(email, password).then(function (newUser) {
                console.log(JSON.stringify(newUser));
                resolve(newUser);
                var tempIndex = email.indexOf('@');
                _this.snapshotChangesSubscription = _this.afs.collection('users').add({
                    username: email.slice(0, tempIndex),
                    fullname: fullname,
                    email: email,
                    phone: (phone != null) ? phone : '',
                    address: (address != null) ? address : '',
                    avt: '',
                    id_auth: newUser.user.uid
                });
            }, function (error) {
                _this.presentAlertErr(error);
            });
        });
    };
    UsersProvider.prototype.facebookLogin = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.facebook.login(['email']).then(function (response) {
                var facebookCredential = firebase.auth.FacebookAuthProvider.credential(response.authResponse.accessToken);
                firebase.auth().signInWithCredential(facebookCredential).then(function (success) {
                    console.log("Firebase success: " + JSON.stringify(success));
                    resolve(success);
                    _this.afs.collection('users', function (ref) { return ref.where('id_auth', '==', success.uid); }).snapshotChanges().subscribe(function (snapshots) {
                        if (snapshots.length <= 0) {
                            var tempIndex = success.email.indexOf('@');
                            _this.snapshotChangesSubscription = _this.afs.collection('users').add({
                                created: Date(),
                                active: true,
                                username: success.email.slice(0, tempIndex),
                                fullname: success.displayName,
                                email: success.email,
                                phone: (success.phoneNumber != null) ? success.phoneNumber : '',
                                address: '',
                                avt: success.photoURL,
                                id_auth: success.uid
                            });
                        }
                        _this.snapshotChangesSubscription.unsubscribe();
                    });
                });
            });
        }).catch(function (error) { console.log(error); });
    };
    UsersProvider.prototype.getUserInfo = function () {
        return this.afs.collection('users').snapshotChanges();
    };
    UsersProvider.prototype.getUser = function (uid) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('users', function (ref) { return ref.where('id_auth', '==', uid); }).snapshotChanges()
                .subscribe(function (snapshots) {
                resolve(snapshots);
                _this.snapshotChangesSubscription.unsubscribe();
            });
        });
    };
    UsersProvider.prototype.updateUser = function (id_user, val) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.snapshotChangesSubscription = _this.afs.collection('users').doc(id_user).update(val)
                .then(function (res) { return resolve(res); }, function (err) { return reject(err); });
        });
    };
    UsersProvider.prototype.resetPassword = function (email) {
        return firebase.auth().sendPasswordResetEmail(email);
    };
    UsersProvider.prototype.logoutUser = function () {
        return firebase.auth().signOut();
    };
    UsersProvider.prototype.presentAlertErr = function (err) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            message: err,
                            buttons: [{
                                    text: "Ok",
                                    role: 'cancel'
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    UsersProvider = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [firestore_1.AngularFirestore, ngx_1.Facebook, angular_1.AlertController])
    ], UsersProvider);
    return UsersProvider;
}());
exports.UsersProvider = UsersProvider;


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\dchinchilla\Desktop\Entregable\proyectoDelmanChinchilla\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map