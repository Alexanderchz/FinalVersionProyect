(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["designer-designer-module"],{

/***/ "./src/app/designer/designer.module.ts":
/*!*********************************************!*\
  !*** ./src/app/designer/designer.module.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var common_1 = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var forms_1 = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var router_1 = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var angular_1 = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var designer_page_1 = __webpack_require__(/*! ./designer.page */ "./src/app/designer/designer.page.ts");
var tabs_page_1 = __webpack_require__(/*! ../tabs/tabs/tabs.page */ "./src/app/tabs/tabs/tabs.page.ts");
var routes = [
    {
        path: '',
        component: designer_page_1.DesignerPage
    }
];
var DesignerPageModule = /** @class */ (function () {
    function DesignerPageModule() {
    }
    DesignerPageModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                angular_1.IonicModule,
                router_1.RouterModule.forChild(routes)
            ],
            declarations: [designer_page_1.DesignerPage, tabs_page_1.TabsPage]
        })
    ], DesignerPageModule);
    return DesignerPageModule;
}());
exports.DesignerPageModule = DesignerPageModule;


/***/ }),

/***/ "./src/app/designer/designer.page.html":
/*!*********************************************!*\
  !*** ./src/app/designer/designer.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\t<ion-toolbar class=\"toolbar\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button color=\"light\" text=\"\" icon=\"ios-arrow-round-back\"></ion-back-button>\n\t\t\t\n\t\t\t\t<ion-back-button class=\"mgb-5  txt-light\" defaultHref=\"/home-client\"></ion-back-button>\n\t\t\n\t\t</ion-buttons>\n\n\t\n\n\t\t<ion-title color=\"light\">Diseñador</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n    \n<ion-content>\n\t\n\t<div class=\"wrapp-pst\" padding>\n\t\t<div padding class=\"mgt-50\">\n\t\t\t<h1 class=\"uppercase fw-900 fs-30 spacing-3 mgb-0\">Apparel Designer</h1>\n\t\t\t<h3 class=\"uppercase fw-600 fs-20 spacing-2 mgl-20 pdt-0\">Envianos una imagen</h3>\n\t\t\t<p class=\"pdl-20 fs-12\">De la camisa que desees mandar a confeccionar.</p>\n\t\t\t<p class=\"pdl-20 fs-12\">y genera tu orden!</p>\n\t\t</div>\n\n\t\t<br>\n\t\t<img class=\"logo-in-menu\" src=\"assets/imgs/knitting.png\">\n\t\t<br><br>\n\t\t \n\t\t<ion-label>Ingresa tu nombre completo</ion-label>\n\t\t<ion-item>\n\t\t\t<ion-input placeholder=\"\" value=\"\" type=\"text\" [(ngModel)]=\"fullName\"></ion-input>\n\t\t  </ion-item>\n\t\t  <br>\n\t\t  <ion-label>Ingresa tu numero de telefono</ion-label>\n\n\t\t  <ion-item>\n\t\t\t<ion-input placeholder=\"\"  type=\"number\" [(ngModel)]=\"phoneNumber\"></ion-input>\n\t\t  </ion-item>\n\t\t  <br>\n\t\t  <ion-label>Ingresa tu correo electronico </ion-label>\n\n\t\t  <ion-item >\n\t\t\t \n\t\t\t<ion-input placeholder=\"\"  type=\"text\" [(ngModel)]=\"email\">{{currentUser.email}}</ion-input>\n\t\t  </ion-item>\n\t\t\n\t\t  <br>\n\t\t  <ion-label>Ingresa una descripcion detallada de lo que esperas </ion-label>\n\t\t  <ion-item>\n\t\t\t\t  <ion-input placeholder=\"\" type=\"text\" [(ngModel)]=\"description\"></ion-input>\n\t\t\t\t</ion-item>\n\n\t\t\t\t<br>\n\t\t                  <ion-label>Ingresa la imagen de la camisa a confeccionar</ion-label>\n\t\t\t\t\t\t\t<div *ngIf=\"downloadURL != null\">\n\t\t\t\t\t\t\t  <img src=\"{{downloadURL}}\">\n\t\t\t\t\t\t  \n\t\t\t\t\t\t  </div>\n\t\t\t\t\t\t   <ion-item>\n\t\t\t\t\t  \n\t\t\t\t\t\t <input type=\"file\" name=\"select Image\" [(ngModel)]=\"downloadURL\" (change)=\"onChange($event)\" >\n\t\t\t\t\t</ion-item>\n\t\t\t\t  \n\t  <br>\n\t  <br>            \n\t\t                <ion-label>Ingresa un logo si deseas serigrafearlo</ion-label>\n\t\t\t\t\t\t\t<div *ngIf=\"logo != null\">\n\t\t\t\t\t\t\t  <img src=\"{{logo}}\">\n\t\t\t\t\t\t  \n\t\t\t\t\t\t  </div>\n\t\t\t\t\t\t   <ion-item>\n\t\t\t\t\t  \n\t\t\t\t\t\t <input class=\"file\" type=\"file\" name=\"\" [(ngModel)]=\"logo\" (change)=\"onChangeLogo($event)\" >\n\t\t\t\t\t</ion-item>\n\t\t\t\t  \n\t  <br>\n\t  <ion-list>\n\t\t  <ion-list-header>Seleccione el lugar de confeccion</ion-list-header>\n\t\t\n\t\t  <ion-item>\n\t\t\t<ion-label>Tienda</ion-label>\n\t\t\t<ion-select [(ngModel)]=\"vendor\" >\n\t\t\t  <ion-select-option value=\"Industrias Delman\">Industrias Delman</ion-select-option>\n\t\t\t  <ion-select-option value=\"Confecciones Marrog\">Confecciones Marrog</ion-select-option>\n\t\t\t</ion-select>\n\t\t  </ion-item>\n\t\t\n\t\t \n\t\t\n\t\t\n\t\t</ion-list>\n\n\t\t<ion-button color=\"primary\" (click)=\"createDesignOrder()\" slot=\"center\">Generar orden de diseño</ion-button>\n\t\t\n\t</div>\n</ion-content>"

/***/ }),

/***/ "./src/app/designer/designer.page.scss":
/*!*********************************************!*\
  !*** ./src/app/designer/designer.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n.file {\n  --background: linear-gradient(135deg, var(--ion-color-dark), var(--ion-color-primary)); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWduZXIvQzpcXFVzZXJzXFxkY2hpbmNoaWxsYVxcRGVza3RvcFxcRW50cmVnYWJsZVxccHJveWVjdG9EZWxtYW5DaGluY2hpbGxhL3NyY1xcYXBwXFxkZXNpZ25lclxcZGVzaWduZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksc0ZBQWEsRUFBQTs7QUFNZjtFQUNFLHNGQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9kZXNpZ25lci9kZXNpZ25lci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhciB7XHJcbiAgIFxyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XHJcbiAgICAgICAgXHJcbiAgfVxyXG5cclxuXHJcblxyXG4gIC5maWxle1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCB2YXIoLS1pb24tY29sb3ItZGFyayksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSk7XHJcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/designer/designer.page.ts":
/*!*******************************************!*\
  !*** ./src/app/designer/designer.page.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var firebase = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
var about_1 = __webpack_require__(/*! src/providers/about */ "./src/providers/about.ts");
var DesignerPage = /** @class */ (function () {
    function DesignerPage(designOrderService) {
        this.designOrderService = designOrderService;
        this.success = false;
        this.disableSubmit = false;
        this.form = {};
        this.currentUser = firebase.auth().currentUser;
        console.log(this.currentUser);
    }
    DesignerPage.prototype.ngOnInit = function () {
    };
    DesignerPage.prototype.createDesignOrder = function () {
        var _this = this;
        var designOrder = {};
        designOrder['fullName'] = this.fullName;
        designOrder['phoneNumber'] = this.phoneNumber;
        designOrder['email'] = this.email;
        designOrder['description'] = this.description;
        designOrder['thumb'] = this.downloadURL;
        designOrder['vendor'] = this.vendor;
        designOrder['logo'] = this.logo;
        this.designOrderService.createNewDesignOrder(designOrder).then(function (res) {
            _this.fullName = "";
            _this.phoneNumber = 0;
            _this.email = "";
            _this.description = "";
            _this.thumb = "";
            _this.vendor = "";
            _this.logo = "";
            console.log(res);
        }).catch(function (error) {
            console.log(error);
        });
    };
    DesignerPage.prototype.onChange = function (event) {
        this.selectedFile = event.target.files[0];
        this.disableSubmit = true;
        this.upLoad();
    };
    DesignerPage.prototype.onChangeLogo = function (event) {
        this.selectedFile = event.target.files[0];
        this.disableSubmit = true;
        this.upLoadLogo();
    };
    DesignerPage.prototype.upLoad = function () {
        var _this = this;
        var fileName = this.selectedFile.name;
        var storageRef = firebase.storage().ref('products products/' + fileName);
        var metadata = { contentType: 'image/jpeg' };
        var uploadTask = storageRef.put(this.selectedFile, metadata);
        uploadTask.on('state_changed', function (snapshot) {
            console.log(snapshot);
            var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100;
            console.log('upload' + progress + '% done');
            switch (uploadTask.snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or Paused
                    console.log('upLoad is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // OR Running
                    console.log('upload is running');
                    break;
            }
        }, function (error) {
            console.log(error);
        }, function () {
            _this.disableSubmit = false;
            storageRef.getDownloadURL().then(function (ref) {
                console.log(ref);
                _this.downloadURL = ref;
            });
            console.log(_this.downloadURL);
            console.log('success');
            _this.success = true;
        });
    };
    DesignerPage.prototype.upLoadLogo = function () {
        var _this = this;
        var fileName = this.selectedFile.name;
        var storageRef = firebase.storage().ref('products products/' + fileName);
        var metadata = { contentType: 'image/jpeg' };
        var uploadTask = storageRef.put(this.selectedFile, metadata);
        uploadTask.on('state_changed', function (snapshot) {
            console.log(snapshot);
            var progress = (uploadTask.snapshot.bytesTransferred / uploadTask.snapshot.totalBytes) * 100;
            console.log('upload' + progress + '% done');
            switch (uploadTask.snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or Paused
                    console.log('upLoad is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // OR Running
                    console.log('upload is running');
                    break;
            }
        }, function (error) {
            console.log(error);
        }, function () {
            _this.disableSubmit = false;
            storageRef.getDownloadURL().then(function (ref) {
                console.log(ref);
                _this.logo = ref;
            });
            console.log(_this.logo);
            console.log('success');
            _this.success = true;
        });
    };
    DesignerPage = __decorate([
        core_1.Component({
            selector: 'app-designer',
            template: __webpack_require__(/*! ./designer.page.html */ "./src/app/designer/designer.page.html"),
            styles: [__webpack_require__(/*! ./designer.page.scss */ "./src/app/designer/designer.page.scss")]
        }),
        __metadata("design:paramtypes", [about_1.AboutProvider])
    ], DesignerPage);
    return DesignerPage;
}());
exports.DesignerPage = DesignerPage;


/***/ }),

/***/ "./src/app/tabs/tabs/tabs.page.html":
/*!******************************************!*\
  !*** ./src/app/tabs/tabs/tabs.page.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-tabs>\n\n    <ion-tab-bar slot=\"bottom\">\n      <ion-tab-button tab=\"tab1\">\n        <ion-icon name=\"shirt\"></ion-icon>\n        <ion-label>Plantilla</ion-label>\n      </ion-tab-button>\n  \n      <ion-tab-button tab=\"tab2\">\n        <ion-icon name=\"apps\"></ion-icon>\n        <ion-label>Cuello</ion-label>\n      </ion-tab-button>\n  \n      <ion-tab-button tab=\"tab3\">\n        <ion-icon name=\"send\"></ion-icon>\n        <ion-label>Terminacion</ion-label>\n      </ion-tab-button>\n    </ion-tab-bar>\n  \n  </ion-tabs>\n  "

/***/ }),

/***/ "./src/app/tabs/tabs/tabs.page.scss":
/*!******************************************!*\
  !*** ./src/app/tabs/tabs/tabs.page.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYnMvdGFicy90YWJzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/tabs/tabs/tabs.page.ts":
/*!****************************************!*\
  !*** ./src/app/tabs/tabs/tabs.page.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var TabsPage = /** @class */ (function () {
    function TabsPage() {
    }
    TabsPage.prototype.ngOnInit = function () {
    };
    TabsPage = __decorate([
        core_1.Component({
            selector: 'app-tabs',
            template: __webpack_require__(/*! ./tabs.page.html */ "./src/app/tabs/tabs/tabs.page.html"),
            styles: [__webpack_require__(/*! ./tabs.page.scss */ "./src/app/tabs/tabs/tabs.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], TabsPage);
    return TabsPage;
}());
exports.TabsPage = TabsPage;


/***/ })

}]);
//# sourceMappingURL=designer-designer-module.js.map